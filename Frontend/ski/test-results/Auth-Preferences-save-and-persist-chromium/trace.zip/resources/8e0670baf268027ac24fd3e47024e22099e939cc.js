import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/App.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=36ac7ba8"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/App.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=36ac7ba8"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import { useAuth0 } from "/node_modules/.vite/deps/@auth0_auth0-react.js?v=36ac7ba8";
import { Preferences } from "/src/components/prefs/Preferences.tsx";
import { ResortsList } from "/src/components/resorts/ResortsList.tsx";
import { Search } from "/src/components/search/Search.tsx";
import { Sort } from "/src/components/sort/Sort.tsx";
import LoginButton from "/src/components/auth/LoginButton.tsx";
import Profile from "/src/components/auth/Profile.tsx";
import "/src/styles/App.css";
import "/src/styles/main.css";
import { savePreferencesToLocalStorage, loadPreferencesFromLocalStorage } from "/src/components/utils/PreferenceUtils.ts";
import { getMockStartResorts, getStartResorts } from "/src/components/resorts/ResortClass.tsx";
function App() {
  _s();
  const [resortList, setResortList] = useState(getStartResorts);
  const {
    isAuthenticated,
    user
  } = useAuth0();
  const [preferences, setPreferences] = useState(null);
  useEffect(() => {
    if (isAuthenticated && user?.sub) {
      const loadedPreferences = loadPreferencesFromLocalStorage(user.sub);
      setPreferences(loadedPreferences);
    }
  }, [isAuthenticated, user?.sub]);
  const handleSavePreferences = (newPreferences) => {
    if (user?.sub) {
      savePreferencesToLocalStorage(user.sub, newPreferences);
      setPreferences(newPreferences);
    }
  };
  const [mockMode, setMockMode] = useState(false);
  const [mockString, setMockString] = useState("Mock Mode: Off");
  const [mockID, setMockID] = useState("mockOffButton");
  function handleMockButton() {
    if (mockMode) {
      setMockMode(false);
      setMockString("Mock Mode: Off");
      setMockID("mockOffButton");
      setResortList(getStartResorts);
    } else {
      setMockMode(true);
      setMockString("Mock Mode: On");
      setMockID("mockOnButton");
      setResortList(getMockStartResorts);
    }
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "App", children: [
    /* @__PURE__ */ jsxDEV("header", { className: "App-header", children: /* @__PURE__ */ jsxDEV("h1", { children: "Alpine Advisor" }, void 0, false, {
      fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/App.tsx",
      lineNumber: 85,
      columnNumber: 5
    }, this) }, void 0, false, {
      fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/App.tsx",
      lineNumber: 84,
      columnNumber: 4
    }, this),
    /* @__PURE__ */ jsxDEV("button", { className: "search-button", id: mockID, onClick: () => handleMockButton(), "aria-label": mockMode ? "Disable mock mode" : "Enable mock mode", children: mockString }, void 0, false, {
      fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/App.tsx",
      lineNumber: 87,
      columnNumber: 4
    }, this),
    /* @__PURE__ */ jsxDEV("main", { children: [
      /* @__PURE__ */ jsxDEV("section", { className: "user-panel", children: isAuthenticated ? /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV(Profile, { className: "profile-container", "aria-label": "User profile" }, void 0, false, {
        fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/App.tsx",
        lineNumber: 93,
        columnNumber: 8
      }, this) }, void 0, false, {
        fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/App.tsx",
        lineNumber: 92,
        columnNumber: 25
      }, this) : /* @__PURE__ */ jsxDEV(LoginButton, { className: "login-button", "aria-label": "Login button" }, void 0, false, {
        fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/App.tsx",
        lineNumber: 94,
        columnNumber: 13
      }, this) }, void 0, false, {
        fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/App.tsx",
        lineNumber: 91,
        columnNumber: 5
      }, this),
      /* @__PURE__ */ jsxDEV("section", { className: "content-panel", children: /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV(Preferences, { preferences, onSavePreferences: handleSavePreferences, resortList, setResortList, mockMode }, void 0, false, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/App.tsx",
          lineNumber: 98,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "search-sort-resorts", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "search-sort", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "sort", children: /* @__PURE__ */ jsxDEV(Sort, { resortList, setResortList, mockMode }, void 0, false, {
              fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/App.tsx",
              lineNumber: 102,
              columnNumber: 10
            }, this) }, void 0, false, {
              fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/App.tsx",
              lineNumber: 101,
              columnNumber: 9
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "search", children: /* @__PURE__ */ jsxDEV(Search, { resortList, setResortList, mockMode }, void 0, false, {
              fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/App.tsx",
              lineNumber: 105,
              columnNumber: 10
            }, this) }, void 0, false, {
              fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/App.tsx",
              lineNumber: 104,
              columnNumber: 9
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/App.tsx",
            lineNumber: 100,
            columnNumber: 8
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "resorts", children: /* @__PURE__ */ jsxDEV(ResortsList, { resortList, "aria-label": "List of resorts" }, void 0, false, {
            fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/App.tsx",
            lineNumber: 109,
            columnNumber: 9
          }, this) }, void 0, false, {
            fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/App.tsx",
            lineNumber: 108,
            columnNumber: 8
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/App.tsx",
          lineNumber: 99,
          columnNumber: 7
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/App.tsx",
        lineNumber: 97,
        columnNumber: 6
      }, this) }, void 0, false, {
        fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/App.tsx",
        lineNumber: 96,
        columnNumber: 5
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/App.tsx",
      lineNumber: 90,
      columnNumber: 4
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/App.tsx",
    lineNumber: 83,
    columnNumber: 10
  }, this);
}
_s(App, "8VqDvrm7BPy5JTLbqR9L2D2X1zo=", false, function() {
  return [useAuth0];
});
_c = App;
export default App;
var _c;
$RefreshReg$(_c, "App");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/App.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUZJLFNBYUUsVUFiRjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFqRkosU0FBU0EsVUFBVUMsaUJBQWlCO0FBQ3BDLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLGNBQWM7QUFDdkIsU0FBU0MsWUFBWTtBQUNyQixPQUFPQyxpQkFBaUI7QUFDeEIsT0FBT0MsYUFBYTtBQUNwQixPQUFPO0FBQ1AsT0FBTztBQUVQLFNBQVNDLCtCQUErQkMsdUNBQXVDO0FBQy9FLFNBQVNDLHFCQUFxQkMsdUJBQTRDO0FBUTFFLFNBQVNDLE1BQU07QUFBQUMsS0FBQTtBQUVkLFFBQU0sQ0FBQ0MsWUFBWUMsYUFBYSxJQUFJaEIsU0FBbUJZLGVBQWU7QUFHdEUsUUFBTTtBQUFBLElBQUVLO0FBQUFBLElBQWlCQztBQUFBQSxFQUFLLElBQUloQixTQUFTO0FBRzNDLFFBQU0sQ0FBQ2lCLGFBQWFDLGNBQWMsSUFBSXBCLFNBQWlDLElBQUk7QUFPM0VDLFlBQVUsTUFBTTtBQUNmLFFBQUlnQixtQkFBbUJDLE1BQU1HLEtBQUs7QUFDakMsWUFBTUMsb0JBQW9CWixnQ0FBZ0NRLEtBQUtHLEdBQUc7QUFDbEVELHFCQUFlRSxpQkFBaUI7QUFBQSxJQUNqQztBQUFBLEVBQ0QsR0FBRyxDQUFDTCxpQkFBaUJDLE1BQU1HLEdBQUcsQ0FBQztBQU0vQixRQUFNRSx3QkFBd0JBLENBQUNDLG1CQUFvQztBQUNsRSxRQUFJTixNQUFNRyxLQUFLO0FBQ2RaLG9DQUE4QlMsS0FBS0csS0FBS0csY0FBYztBQUN0REoscUJBQWVJLGNBQWM7QUFBQSxJQUM5QjtBQUFBLEVBQ0Q7QUFHQSxRQUFNLENBQUNDLFVBQVVDLFdBQVcsSUFBSTFCLFNBQWtCLEtBQUs7QUFFdkQsUUFBTSxDQUFDMkIsWUFBWUMsYUFBYSxJQUFJNUIsU0FBaUIsZ0JBQWdCO0FBRXJFLFFBQU0sQ0FBQzZCLFFBQVFDLFNBQVMsSUFBSTlCLFNBQWlCLGVBQWU7QUFNNUQsV0FBUytCLG1CQUFtQjtBQUMzQixRQUFJTixVQUFVO0FBQ2JDLGtCQUFZLEtBQUs7QUFDakJFLG9CQUFjLGdCQUFnQjtBQUM5QkUsZ0JBQVUsZUFBZTtBQUN6QmQsb0JBQWNKLGVBQWU7QUFBQSxJQUM5QixPQUFPO0FBQ05jLGtCQUFZLElBQUk7QUFDaEJFLG9CQUFjLGVBQWU7QUFDN0JFLGdCQUFVLGNBQWM7QUFDeEJkLG9CQUFjTCxtQkFBbUI7QUFBQSxJQUNsQztBQUFBLEVBQ0Q7QUFFQSxTQUNDLHVCQUFDLFNBQUksV0FBVSxPQUNkO0FBQUEsMkJBQUMsWUFBTyxXQUFVLGNBQ2pCLGlDQUFDLFFBQUcsOEJBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFrQixLQURuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUNBLHVCQUFDLFlBQ0EsV0FBVSxpQkFDVixJQUFJa0IsUUFDSixTQUFTLE1BQU1FLGlCQUFpQixHQUNoQyxjQUFZTixXQUFXLHNCQUFzQixvQkFFNUNFLHdCQU5GO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FPQTtBQUFBLElBQ0EsdUJBQUMsVUFDQTtBQUFBLDZCQUFDLGFBQVEsV0FBVSxjQUNqQlYsNEJBQ0EsbUNBQ0MsaUNBQUMsV0FBUSxXQUFVLHFCQUFvQixjQUFXLGtCQUFsRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWdFLEtBRGpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFQSxJQUVBLHVCQUFDLGVBQVksV0FBVSxnQkFBZSxjQUFXLGtCQUFqRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQStELEtBTmpFO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFRQTtBQUFBLE1BQ0EsdUJBQUMsYUFBUSxXQUFVLGlCQUNsQixpQ0FBQyxTQUNBO0FBQUEsK0JBQUMsZUFDQSxhQUNBLG1CQUFtQk0sdUJBQ25CLFlBQ0EsZUFDQSxZQUxEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFLb0I7QUFBQSxRQUVwQix1QkFBQyxTQUFJLFdBQVUsdUJBQ2Q7QUFBQSxpQ0FBQyxTQUFJLFdBQVUsZUFDZDtBQUFBLG1DQUFDLFNBQUksV0FBVSxRQUNkLGlDQUFDLFFBQUssWUFBd0IsZUFBOEIsWUFBNUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFBK0UsS0FEaEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxtQkFFQTtBQUFBLFlBQ0EsdUJBQUMsU0FBSSxXQUFVLFVBQ2QsaUNBQUMsVUFBTyxZQUF3QixlQUE4QixZQUE5RDtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUFpRixLQURsRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUVBO0FBQUEsZUFORDtBQUFBO0FBQUE7QUFBQTtBQUFBLGlCQU9BO0FBQUEsVUFDQSx1QkFBQyxTQUFJLFdBQVUsV0FDZCxpQ0FBQyxlQUFZLFlBQXdCLGNBQVcscUJBQWhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBQWlFLEtBRGxFO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRUE7QUFBQSxhQVhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFZQTtBQUFBLFdBcEJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFxQkEsS0F0QkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXVCQTtBQUFBLFNBakNEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FrQ0E7QUFBQSxPQTlDRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBK0NBO0FBRUY7QUFBQ1QsR0E1R1FELEtBQUc7QUFBQSxVQUt1QlgsUUFBUTtBQUFBO0FBQUE4QixLQUxsQ25CO0FBOEdULGVBQWVBO0FBQUksSUFBQW1CO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsInVzZUVmZmVjdCIsInVzZUF1dGgwIiwiUHJlZmVyZW5jZXMiLCJSZXNvcnRzTGlzdCIsIlNlYXJjaCIsIlNvcnQiLCJMb2dpbkJ1dHRvbiIsIlByb2ZpbGUiLCJzYXZlUHJlZmVyZW5jZXNUb0xvY2FsU3RvcmFnZSIsImxvYWRQcmVmZXJlbmNlc0Zyb21Mb2NhbFN0b3JhZ2UiLCJnZXRNb2NrU3RhcnRSZXNvcnRzIiwiZ2V0U3RhcnRSZXNvcnRzIiwiQXBwIiwiX3MiLCJyZXNvcnRMaXN0Iiwic2V0UmVzb3J0TGlzdCIsImlzQXV0aGVudGljYXRlZCIsInVzZXIiLCJwcmVmZXJlbmNlcyIsInNldFByZWZlcmVuY2VzIiwic3ViIiwibG9hZGVkUHJlZmVyZW5jZXMiLCJoYW5kbGVTYXZlUHJlZmVyZW5jZXMiLCJuZXdQcmVmZXJlbmNlcyIsIm1vY2tNb2RlIiwic2V0TW9ja01vZGUiLCJtb2NrU3RyaW5nIiwic2V0TW9ja1N0cmluZyIsIm1vY2tJRCIsInNldE1vY2tJRCIsImhhbmRsZU1vY2tCdXR0b24iLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkFwcC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUsIHVzZUVmZmVjdCB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgdXNlQXV0aDAgfSBmcm9tIFwiQGF1dGgwL2F1dGgwLXJlYWN0XCI7XG5pbXBvcnQgeyBQcmVmZXJlbmNlcyB9IGZyb20gXCIuL3ByZWZzL1ByZWZlcmVuY2VzXCI7XG5pbXBvcnQgeyBSZXNvcnRzTGlzdCB9IGZyb20gXCIuL3Jlc29ydHMvUmVzb3J0c0xpc3RcIjtcbmltcG9ydCB7IFNlYXJjaCB9IGZyb20gXCIuL3NlYXJjaC9TZWFyY2hcIjtcbmltcG9ydCB7IFNvcnQgfSBmcm9tIFwiLi9zb3J0L1NvcnRcIjtcbmltcG9ydCBMb2dpbkJ1dHRvbiBmcm9tIFwiLi9hdXRoL0xvZ2luQnV0dG9uXCI7XG5pbXBvcnQgUHJvZmlsZSBmcm9tIFwiLi9hdXRoL1Byb2ZpbGVcIjtcbmltcG9ydCBcIi4uL3N0eWxlcy9BcHAuY3NzXCI7XG5pbXBvcnQgXCIuLi9zdHlsZXMvbWFpbi5jc3NcIjtcbmltcG9ydCB7IFVzZXJQcmVmZXJlbmNlcyB9IGZyb20gXCIuL3ByZWZzL1ByZWZlcmVuY2VzXCI7XG5pbXBvcnQgeyBzYXZlUHJlZmVyZW5jZXNUb0xvY2FsU3RvcmFnZSwgbG9hZFByZWZlcmVuY2VzRnJvbUxvY2FsU3RvcmFnZSB9IGZyb20gXCIuL3V0aWxzL1ByZWZlcmVuY2VVdGlsc1wiO1xuaW1wb3J0IHsgZ2V0TW9ja1N0YXJ0UmVzb3J0cywgZ2V0U3RhcnRSZXNvcnRzLCBtb2NrUmVzb3J0cywgUmVzb3J0IH0gZnJvbSBcIi4vcmVzb3J0cy9SZXNvcnRDbGFzc1wiO1xuXG4vKipcbiAqIFRoZSBgQXBwYCBjb21wb25lbnQgc2VydmVzIGFzIHRoZSBtYWluIGNvbnRhaW5lciBmb3IgdGhlIEFscGluZSBBZHZpc29yIGFwcGxpY2F0aW9uLlxuICogSXQgdXNlcyBBdXRoMCBmb3IgYXV0aGVudGljYXRpb24sIG1hbmFnZXMgc3RhdGUgZm9yIHJlc29ydCBkYXRhIGFuZCBtb2NrIG1vZGUsIGFuZFxuICogcmVuZGVycyB2YXJpb3VzIGNvbXBvbmVudHMgc3VjaCBhcyBgUHJlZmVyZW5jZXNgLCBgU2VhcmNoYCwgYFNvcnRgLCBgUmVzb3J0c0xpc3RgLFxuICogYExvZ2luQnV0dG9uYCwgYW5kIGBQcm9maWxlYC5cbiAqL1xuZnVuY3Rpb24gQXBwKCkge1xuXHQvLyBNYW5hZ2VzIHN0YXRlIGZvciB0aGUgcmVzb3J0IGxpc3Rcblx0Y29uc3QgW3Jlc29ydExpc3QsIHNldFJlc29ydExpc3RdID0gdXNlU3RhdGU8UmVzb3J0W10+KGdldFN0YXJ0UmVzb3J0cyk7XG5cblx0Ly8gR2V0cyBhdXRoZW50aWNhdGlvbiBzdGF0dXMgYW5kIHVzZXIgaW5mbyBmcm9tIEF1dGgwXG5cdGNvbnN0IHsgaXNBdXRoZW50aWNhdGVkLCB1c2VyIH0gPSB1c2VBdXRoMCgpO1xuXG5cdC8vIE1hbmFnZXMgc3RhdGUgZm9yIHVzZXIgcHJlZmVyZW5jZXNcblx0Y29uc3QgW3ByZWZlcmVuY2VzLCBzZXRQcmVmZXJlbmNlc10gPSB1c2VTdGF0ZTxVc2VyUHJlZmVyZW5jZXMgfCBudWxsPihudWxsKTtcblxuXHQvKipcblx0ICogdXNlRWZmZWN0IGhvb2sgdG8gbG9hZCB1c2VyIHByZWZlcmVuY2VzIGZyb20gbG9jYWwgc3RvcmFnZSB3aGVuIHRoZSB1c2VyIGxvZ3MgaW4uXG5cdCAqIEl0IGNoZWNrcyBpZiB0aGUgdXNlciBpcyBhdXRoZW50aWNhdGVkIGFuZCBpZiBzbywgaXQgbG9hZHMgcHJlZmVyZW5jZXMgYXNzb2NpYXRlZFxuXHQgKiB3aXRoIHRoYXQgdXNlciBhbmQgc2V0cyB0aGVtIGluIHN0YXRlLlxuXHQgKi9cblx0dXNlRWZmZWN0KCgpID0+IHtcblx0XHRpZiAoaXNBdXRoZW50aWNhdGVkICYmIHVzZXI/LnN1Yikge1xuXHRcdFx0Y29uc3QgbG9hZGVkUHJlZmVyZW5jZXMgPSBsb2FkUHJlZmVyZW5jZXNGcm9tTG9jYWxTdG9yYWdlKHVzZXIuc3ViKTtcblx0XHRcdHNldFByZWZlcmVuY2VzKGxvYWRlZFByZWZlcmVuY2VzKTtcblx0XHR9XG5cdH0sIFtpc0F1dGhlbnRpY2F0ZWQsIHVzZXI/LnN1Yl0pO1xuXG5cdC8qKlxuXHQgKiBTYXZlcyBuZXcgdXNlciBwcmVmZXJlbmNlcy4gRmlyc3QgY2hlY2tzIGlmIHRoZSB1c2VyIGlzIGF1dGhlbnRpY2F0ZWQgYW5kXG5cdCAqIGlmIHNvLCBzYXZlcyB0aGUgbmV3IHByZWZlcmVuY2VzIHRvIGxvY2FsIHN0b3JhZ2UgYW5kIHVwZGF0ZXMgdGhlIHN0YXRlLlxuXHQgKi9cblx0Y29uc3QgaGFuZGxlU2F2ZVByZWZlcmVuY2VzID0gKG5ld1ByZWZlcmVuY2VzOiBVc2VyUHJlZmVyZW5jZXMpID0+IHtcblx0XHRpZiAodXNlcj8uc3ViKSB7XG5cdFx0XHRzYXZlUHJlZmVyZW5jZXNUb0xvY2FsU3RvcmFnZSh1c2VyLnN1YiwgbmV3UHJlZmVyZW5jZXMpO1xuXHRcdFx0c2V0UHJlZmVyZW5jZXMobmV3UHJlZmVyZW5jZXMpO1xuXHRcdH1cblx0fTtcblxuXHQvLyBNYW5hZ2VzIHN0YXRlIGZvciBtb2NrIG1vZGVcblx0Y29uc3QgW21vY2tNb2RlLCBzZXRNb2NrTW9kZV0gPSB1c2VTdGF0ZTxib29sZWFuPihmYWxzZSk7XG5cdC8vIE1hbmFnZXMgc3RhdGUgZm9yIHRoZSBtb2NrIGluZGljYXRvclxuXHRjb25zdCBbbW9ja1N0cmluZywgc2V0TW9ja1N0cmluZ10gPSB1c2VTdGF0ZTxzdHJpbmc+KFwiTW9jayBNb2RlOiBPZmZcIik7XG5cdC8vIE1hbmFnZXMgc3RhdGUgZm9yIHRoZSBtb2NrIElEXG5cdGNvbnN0IFttb2NrSUQsIHNldE1vY2tJRF0gPSB1c2VTdGF0ZTxzdHJpbmc+KFwibW9ja09mZkJ1dHRvblwiKTtcblxuXHQvKipcblx0ICogVG9nZ2xlcyB0aGUgbW9jayBtb2RlIHN0YXRlIGFuZCB1cGRhdGVzIHRoZSByZXNvcnQgbGlzdCBhY2NvcmRpbmdseS5cblx0ICogU3dpdGNoZXMgYmV0d2VlbiByZWFsIGFuZCBtb2NrIGRhdGEgZm9yIHJlc29ydHMuXG5cdCAqL1xuXHRmdW5jdGlvbiBoYW5kbGVNb2NrQnV0dG9uKCkge1xuXHRcdGlmIChtb2NrTW9kZSkge1xuXHRcdFx0c2V0TW9ja01vZGUoZmFsc2UpO1xuXHRcdFx0c2V0TW9ja1N0cmluZyhcIk1vY2sgTW9kZTogT2ZmXCIpO1xuXHRcdFx0c2V0TW9ja0lEKFwibW9ja09mZkJ1dHRvblwiKTtcblx0XHRcdHNldFJlc29ydExpc3QoZ2V0U3RhcnRSZXNvcnRzKTtcblx0XHR9IGVsc2Uge1xuXHRcdFx0c2V0TW9ja01vZGUodHJ1ZSk7XG5cdFx0XHRzZXRNb2NrU3RyaW5nKFwiTW9jayBNb2RlOiBPblwiKTtcblx0XHRcdHNldE1vY2tJRChcIm1vY2tPbkJ1dHRvblwiKTtcblx0XHRcdHNldFJlc29ydExpc3QoZ2V0TW9ja1N0YXJ0UmVzb3J0cyk7XG5cdFx0fVxuXHR9XG5cblx0cmV0dXJuIChcblx0XHQ8ZGl2IGNsYXNzTmFtZT1cIkFwcFwiPlxuXHRcdFx0PGhlYWRlciBjbGFzc05hbWU9XCJBcHAtaGVhZGVyXCI+XG5cdFx0XHRcdDxoMT5BbHBpbmUgQWR2aXNvcjwvaDE+XG5cdFx0XHQ8L2hlYWRlcj5cblx0XHRcdDxidXR0b25cblx0XHRcdFx0Y2xhc3NOYW1lPVwic2VhcmNoLWJ1dHRvblwiXG5cdFx0XHRcdGlkPXttb2NrSUR9XG5cdFx0XHRcdG9uQ2xpY2s9eygpID0+IGhhbmRsZU1vY2tCdXR0b24oKX1cblx0XHRcdFx0YXJpYS1sYWJlbD17bW9ja01vZGUgPyBcIkRpc2FibGUgbW9jayBtb2RlXCIgOiBcIkVuYWJsZSBtb2NrIG1vZGVcIn1cblx0XHRcdD5cblx0XHRcdFx0e21vY2tTdHJpbmd9XG5cdFx0XHQ8L2J1dHRvbj5cblx0XHRcdDxtYWluPlxuXHRcdFx0XHQ8c2VjdGlvbiBjbGFzc05hbWU9XCJ1c2VyLXBhbmVsXCI+XG5cdFx0XHRcdFx0e2lzQXV0aGVudGljYXRlZCA/IChcblx0XHRcdFx0XHRcdDw+XG5cdFx0XHRcdFx0XHRcdDxQcm9maWxlIGNsYXNzTmFtZT1cInByb2ZpbGUtY29udGFpbmVyXCIgYXJpYS1sYWJlbD1cIlVzZXIgcHJvZmlsZVwiIC8+XG5cdFx0XHRcdFx0XHQ8Lz5cblx0XHRcdFx0XHQpIDogKFxuXHRcdFx0XHRcdFx0PExvZ2luQnV0dG9uIGNsYXNzTmFtZT1cImxvZ2luLWJ1dHRvblwiIGFyaWEtbGFiZWw9XCJMb2dpbiBidXR0b25cIiAvPlxuXHRcdFx0XHRcdCl9XG5cdFx0XHRcdDwvc2VjdGlvbj5cblx0XHRcdFx0PHNlY3Rpb24gY2xhc3NOYW1lPVwiY29udGVudC1wYW5lbFwiPlxuXHRcdFx0XHRcdDxkaXY+XG5cdFx0XHRcdFx0XHQ8UHJlZmVyZW5jZXNcblx0XHRcdFx0XHRcdFx0cHJlZmVyZW5jZXM9e3ByZWZlcmVuY2VzfVxuXHRcdFx0XHRcdFx0XHRvblNhdmVQcmVmZXJlbmNlcz17aGFuZGxlU2F2ZVByZWZlcmVuY2VzfVxuXHRcdFx0XHRcdFx0XHRyZXNvcnRMaXN0PXtyZXNvcnRMaXN0fVxuXHRcdFx0XHRcdFx0XHRzZXRSZXNvcnRMaXN0PXtzZXRSZXNvcnRMaXN0fVxuXHRcdFx0XHRcdFx0XHRtb2NrTW9kZT17bW9ja01vZGV9XG5cdFx0XHRcdFx0XHQvPlxuXHRcdFx0XHRcdFx0PGRpdiBjbGFzc05hbWU9XCJzZWFyY2gtc29ydC1yZXNvcnRzXCI+XG5cdFx0XHRcdFx0XHRcdDxkaXYgY2xhc3NOYW1lPVwic2VhcmNoLXNvcnRcIj5cblx0XHRcdFx0XHRcdFx0XHQ8ZGl2IGNsYXNzTmFtZT1cInNvcnRcIj5cblx0XHRcdFx0XHRcdFx0XHRcdDxTb3J0IHJlc29ydExpc3Q9e3Jlc29ydExpc3R9IHNldFJlc29ydExpc3Q9e3NldFJlc29ydExpc3R9IG1vY2tNb2RlPXttb2NrTW9kZX0gLz5cblx0XHRcdFx0XHRcdFx0XHQ8L2Rpdj5cblx0XHRcdFx0XHRcdFx0XHQ8ZGl2IGNsYXNzTmFtZT1cInNlYXJjaFwiPlxuXHRcdFx0XHRcdFx0XHRcdFx0PFNlYXJjaCByZXNvcnRMaXN0PXtyZXNvcnRMaXN0fSBzZXRSZXNvcnRMaXN0PXtzZXRSZXNvcnRMaXN0fSBtb2NrTW9kZT17bW9ja01vZGV9IC8+XG5cdFx0XHRcdFx0XHRcdFx0PC9kaXY+XG5cdFx0XHRcdFx0XHRcdDwvZGl2PlxuXHRcdFx0XHRcdFx0XHQ8ZGl2IGNsYXNzTmFtZT1cInJlc29ydHNcIj5cblx0XHRcdFx0XHRcdFx0XHQ8UmVzb3J0c0xpc3QgcmVzb3J0TGlzdD17cmVzb3J0TGlzdH0gYXJpYS1sYWJlbD1cIkxpc3Qgb2YgcmVzb3J0c1wiIC8+XG5cdFx0XHRcdFx0XHRcdDwvZGl2PlxuXHRcdFx0XHRcdFx0PC9kaXY+XG5cdFx0XHRcdFx0PC9kaXY+XG5cdFx0XHRcdDwvc2VjdGlvbj5cblx0XHRcdDwvbWFpbj5cblx0XHQ8L2Rpdj5cblx0KTtcbn1cblxuZXhwb3J0IGRlZmF1bHQgQXBwO1xuIl0sImZpbGUiOiIvVXNlcnMvYXVzdGlud2lsbGlhbXMvRG9jdW1lbnRzL1NjaG9vbC90aGlyZFNlbWVzdGVyL0NTMzIvdGVybS1wcm9qZWN0LXRiemhhby10cGV6emEtc21zY2h1Y2gtYndpbGxpNDgvRnJvbnRlbmQvc2tpL3NyYy9jb21wb25lbnRzL0FwcC50c3gifQ==