import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/sort/Sort.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=36ac7ba8"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/sort/Sort.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import "/src/styles/main.css";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=36ac7ba8"; const useState = __vite__cjsImport4_react["useState"];
import { SortDropdown } from "/src/components/sort/SortDropdown.tsx";
import { getMockSortedResorts, getSortedResorts } from "/src/components/resorts/ResortClass.tsx";
export function Sort(props) {
  _s();
  const [showDropDown, setShowDropDown] = useState(false);
  const [selectSort, setSelectSort] = useState("");
  const sortOptions = () => {
    return ["Snowfall Amount", "Last Snowfall", "Base-depth", "Price", "Lifts Open", "Summit Elevation", "Temperature", "Windspeed"];
  };
  const toggleDropDown = () => {
    setShowDropDown(!showDropDown);
  };
  const dismissHandler = (event) => {
    if (event.currentTarget === event.target) {
      setShowDropDown(false);
    }
  };
  const sortOptionsSelection = (sortOption) => {
    setSelectSort(sortOption);
  };
  function handleSort() {
    if (selectSort === "") {
    } else {
      if (props.mockMode) {
        props.setResortList(getMockSortedResorts(selectSort));
      } else {
        props.setResortList(getSortedResorts(selectSort));
      }
    }
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "sort-container", "aria-label": "Sort resorts section", children: [
    /* @__PURE__ */ jsxDEV("h3", { className: "sort-title", children: "Select a sort method:" }, void 0, false, {
      fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/sort/Sort.tsx",
      lineNumber: 66,
      columnNumber: 4
    }, this),
    /* @__PURE__ */ jsxDEV("button", { id: "sortDropdown", className: `sort-dropdown ${showDropDown ? "active" : ""}`, onClick: () => toggleDropDown(), onBlur: dismissHandler, "aria-label": "Sort methods dropdown", children: [
      selectSort ? `Sort by: ${selectSort}` : "See methods...",
      showDropDown && /* @__PURE__ */ jsxDEV(SortDropdown, { sortOptions: sortOptions(), showDropDown: false, toggleDropDown, sortOptionsSelection }, void 0, false, {
        fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/sort/Sort.tsx",
        lineNumber: 69,
        columnNumber: 22
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/sort/Sort.tsx",
      lineNumber: 67,
      columnNumber: 4
    }, this),
    /* @__PURE__ */ jsxDEV("button", { id: "sortButton", className: "sort-button", onClick: handleSort, "aria-label": selectSort ? `Sort resorts by ${selectSort}` : "Sort resorts by selected method", children: "Sort" }, void 0, false, {
      fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/sort/Sort.tsx",
      lineNumber: 71,
      columnNumber: 4
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/sort/Sort.tsx",
    lineNumber: 65,
    columnNumber: 10
  }, this);
}
_s(Sort, "/Dy4gOoJle/jUjwiNo/V/4Q0NAk=");
_c = Sort;
var _c;
$RefreshReg$(_c, "Sort");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/sort/Sort.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBMkVHOzs7Ozs7Ozs7Ozs7Ozs7OztBQTNFSCxPQUFPO0FBQ1AsU0FBbUNBLGdCQUFnQjtBQUNuRCxTQUFTQyxvQkFBb0I7QUFDN0IsU0FBU0Msc0JBQXNCQyx3QkFBaUQ7QUFhekUsZ0JBQVNDLEtBQUtDLE9BQWtCO0FBQUFDLEtBQUE7QUFFdEMsUUFBTSxDQUFDQyxjQUFjQyxlQUFlLElBQUlSLFNBQWtCLEtBQUs7QUFHL0QsUUFBTSxDQUFDUyxZQUFZQyxhQUFhLElBQUlWLFNBQWlCLEVBQUU7QUFHdkQsUUFBTVcsY0FBY0EsTUFBTTtBQUN6QixXQUFPLENBQ04sbUJBQ0EsaUJBQ0EsY0FDQSxTQUNBLGNBQ0Esb0JBQ0EsZUFDQSxXQUFXO0FBQUEsRUFFYjtBQUdBLFFBQU1DLGlCQUFpQkEsTUFBTTtBQUM1Qkosb0JBQWdCLENBQUNELFlBQVk7QUFBQSxFQUM5QjtBQUtBLFFBQU1NLGlCQUFpQkEsQ0FBQ0MsVUFBcUQ7QUFDNUUsUUFBSUEsTUFBTUMsa0JBQWtCRCxNQUFNRSxRQUFRO0FBQ3pDUixzQkFBZ0IsS0FBSztBQUFBLElBQ3RCO0FBQUEsRUFDRDtBQU1BLFFBQU1TLHVCQUF1QkEsQ0FBQ0MsZUFBNkI7QUFDMURSLGtCQUFjUSxVQUFVO0FBQUEsRUFDekI7QUFLQSxXQUFTQyxhQUFhO0FBQ3JCLFFBQUlWLGVBQWUsSUFBSTtBQUFBLElBQ3ZCLE9BQU87QUFDTixVQUFJSixNQUFNZSxVQUFVO0FBQ25CZixjQUFNZ0IsY0FBY25CLHFCQUFxQk8sVUFBVSxDQUFDO0FBQUEsTUFDckQsT0FBTztBQUNOSixjQUFNZ0IsY0FBY2xCLGlCQUFpQk0sVUFBVSxDQUFDO0FBQUEsTUFDakQ7QUFBQSxJQUNEO0FBQUEsRUFDRDtBQUVBLFNBQ0MsdUJBQUMsU0FBSSxXQUFVLGtCQUFpQixjQUFXLHdCQUMxQztBQUFBLDJCQUFDLFFBQUcsV0FBVSxjQUFhLHFDQUEzQjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWdEO0FBQUEsSUFDaEQsdUJBQUMsWUFDQSxJQUFHLGdCQUNILFdBQVksaUJBQWdCRixlQUFlLFdBQVcsRUFBRyxJQUN6RCxTQUFTLE1BQU1LLGVBQWUsR0FDOUIsUUFBUUMsZ0JBQ1IsY0FBVyx5QkFFVko7QUFBQUEsbUJBQWMsWUFBV0EsVUFBVyxLQUFJO0FBQUEsTUFDeENGLGdCQUNBLHVCQUFDLGdCQUNBLGFBQWFJLFlBQVksR0FDekIsY0FBYyxPQUNkLGdCQUNBLHdCQUpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFJNEM7QUFBQSxTQWI5QztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBZ0JBO0FBQUEsSUFDQSx1QkFBQyxZQUNBLElBQUcsY0FDSCxXQUFVLGVBQ1YsU0FBU1EsWUFDVCxjQUFZVixhQUFjLG1CQUFrQkEsVUFBVyxLQUFJLG1DQUFrQyxvQkFKOUY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU9BO0FBQUEsT0ExQkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTJCQTtBQUVGO0FBQUNILEdBdkZlRixNQUFJO0FBQUFrQixLQUFKbEI7QUFBSSxJQUFBa0I7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwiU29ydERyb3Bkb3duIiwiZ2V0TW9ja1NvcnRlZFJlc29ydHMiLCJnZXRTb3J0ZWRSZXNvcnRzIiwiU29ydCIsInByb3BzIiwiX3MiLCJzaG93RHJvcERvd24iLCJzZXRTaG93RHJvcERvd24iLCJzZWxlY3RTb3J0Iiwic2V0U2VsZWN0U29ydCIsInNvcnRPcHRpb25zIiwidG9nZ2xlRHJvcERvd24iLCJkaXNtaXNzSGFuZGxlciIsImV2ZW50IiwiY3VycmVudFRhcmdldCIsInRhcmdldCIsInNvcnRPcHRpb25zU2VsZWN0aW9uIiwic29ydE9wdGlvbiIsImhhbmRsZVNvcnQiLCJtb2NrTW9kZSIsInNldFJlc29ydExpc3QiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlNvcnQudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBcIi4uLy4uL3N0eWxlcy9tYWluLmNzc1wiO1xuaW1wb3J0IHsgRGlzcGF0Y2gsIFNldFN0YXRlQWN0aW9uLCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgU29ydERyb3Bkb3duIH0gZnJvbSBcIi4vU29ydERyb3Bkb3duXCI7XG5pbXBvcnQgeyBnZXRNb2NrU29ydGVkUmVzb3J0cywgZ2V0U29ydGVkUmVzb3J0cywgbW9ja1Jlc29ydHNTb3J0LCBSZXNvcnQgfSBmcm9tIFwiLi4vcmVzb3J0cy9SZXNvcnRDbGFzc1wiO1xuXG4vLyBQcm9wZXJ0aWVzIGZvciB0aGUgU29ydCBjb21wb25lbnQuXG5pbnRlcmZhY2UgU29ydFByb3BzIHtcblx0cmVzb3J0TGlzdDogUmVzb3J0W107XG5cdHNldFJlc29ydExpc3Q6IERpc3BhdGNoPFNldFN0YXRlQWN0aW9uPFJlc29ydFtdPj47XG5cdG1vY2tNb2RlOiBib29sZWFuO1xufVxuXG4vKipcbiAqIEFsbG93cyB1c2VycyB0byBzZWxlY3QgYSBzb3J0aW5nIG1ldGhvZCBmb3IgdGhlIGxpc3Qgb2YgcmVzb3J0cy4gSGFuZGxlcyB0aGUgZGlzcGxheVxuICogb2Ygc29ydGluZyBvcHRpb25zIHZpYSBhIGRyb3Bkb3duIG1lbnUgYW5kIGFwcGxpZXMgdGhlIHNlbGVjdGVkIHNvcnQgbWV0aG9kLlxuICovXG5leHBvcnQgZnVuY3Rpb24gU29ydChwcm9wczogU29ydFByb3BzKSB7XG5cdC8vIFN0YXRlIGZvciB3aGV0aGVyIHRvIHNob3cgdGhlIGRyb3Bkb3duIG1lbnUuXG5cdGNvbnN0IFtzaG93RHJvcERvd24sIHNldFNob3dEcm9wRG93bl0gPSB1c2VTdGF0ZTxib29sZWFuPihmYWxzZSk7XG5cblx0Ly8gU3RhdGUgZm9yIHRoZSB0ZXh0IGluIHRoZSBzZWxlY3QgYm94LlxuXHRjb25zdCBbc2VsZWN0U29ydCwgc2V0U2VsZWN0U29ydF0gPSB1c2VTdGF0ZTxzdHJpbmc+KFwiXCIpO1xuXG5cdC8vIFRoZSBvcHRpb25zIHRoYXQgdXNlcnMgY2FuIHNvcnQgYnkuXG5cdGNvbnN0IHNvcnRPcHRpb25zID0gKCkgPT4ge1xuXHRcdHJldHVybiBbXG5cdFx0XHRcIlNub3dmYWxsIEFtb3VudFwiLFxuXHRcdFx0XCJMYXN0IFNub3dmYWxsXCIsXG5cdFx0XHRcIkJhc2UtZGVwdGhcIixcblx0XHRcdFwiUHJpY2VcIixcblx0XHRcdFwiTGlmdHMgT3BlblwiLFxuXHRcdFx0XCJTdW1taXQgRWxldmF0aW9uXCIsXG5cdFx0XHRcIlRlbXBlcmF0dXJlXCIsXG5cdFx0XHRcIldpbmRzcGVlZFwiLFxuXHRcdF07XG5cdH07XG5cblx0Ly8gVG9nZ2xlcyB0aGUgdmlzaWJpbGl0eSBvZiB0aGUgZHJvcGRvd24gbWVudS5cblx0Y29uc3QgdG9nZ2xlRHJvcERvd24gPSAoKSA9PiB7XG5cdFx0c2V0U2hvd0Ryb3BEb3duKCFzaG93RHJvcERvd24pO1xuXHR9O1xuXG5cdC8qKlxuXHQgKiBIYW5kbGVyIHRoYXQgaGlkZXMgdGhlIGRyb3Bkb3duIG1lbnUgaWYgYSBjbGljayBvY2N1cnMgb3V0c2lkZSBvZiB0aGUgZHJvcGRvd24gZWxlbWVudC5cblx0ICovXG5cdGNvbnN0IGRpc21pc3NIYW5kbGVyID0gKGV2ZW50OiBSZWFjdC5Gb2N1c0V2ZW50PEhUTUxCdXR0b25FbGVtZW50Pik6IHZvaWQgPT4ge1xuXHRcdGlmIChldmVudC5jdXJyZW50VGFyZ2V0ID09PSBldmVudC50YXJnZXQpIHtcblx0XHRcdHNldFNob3dEcm9wRG93bihmYWxzZSk7XG5cdFx0fVxuXHR9O1xuXG5cdC8qKlxuXHQgKiBTZXRzIHRoZSBjdXJyZW50bHkgc2VsZWN0ZWQgc29ydCBvcHRpb24uXG5cdCAqIEBwYXJhbSBzb3J0T3B0aW9uIFRoZSBzZWxlY3RlZCBvcHRpb25zXG5cdCAqL1xuXHRjb25zdCBzb3J0T3B0aW9uc1NlbGVjdGlvbiA9IChzb3J0T3B0aW9uOiBzdHJpbmcpOiB2b2lkID0+IHtcblx0XHRzZXRTZWxlY3RTb3J0KHNvcnRPcHRpb24pO1xuXHR9O1xuXG5cdC8qKlxuXHQgKiBVcGRhdGVzIHRoZSByZXNvcnQgbGlzdCBiYXNlZCBvbiB0aGUgc2VsZWN0ZWQgc29ydCBtZXRob2QuXG5cdCAqL1xuXHRmdW5jdGlvbiBoYW5kbGVTb3J0KCkge1xuXHRcdGlmIChzZWxlY3RTb3J0ID09PSBcIlwiKSB7XG5cdFx0fSBlbHNlIHtcblx0XHRcdGlmIChwcm9wcy5tb2NrTW9kZSkge1xuXHRcdFx0XHRwcm9wcy5zZXRSZXNvcnRMaXN0KGdldE1vY2tTb3J0ZWRSZXNvcnRzKHNlbGVjdFNvcnQpKTtcblx0XHRcdH0gZWxzZSB7XG5cdFx0XHRcdHByb3BzLnNldFJlc29ydExpc3QoZ2V0U29ydGVkUmVzb3J0cyhzZWxlY3RTb3J0KSk7XG5cdFx0XHR9XG5cdFx0fVxuXHR9XG5cblx0cmV0dXJuIChcblx0XHQ8ZGl2IGNsYXNzTmFtZT1cInNvcnQtY29udGFpbmVyXCIgYXJpYS1sYWJlbD1cIlNvcnQgcmVzb3J0cyBzZWN0aW9uXCI+XG5cdFx0XHQ8aDMgY2xhc3NOYW1lPVwic29ydC10aXRsZVwiPlNlbGVjdCBhIHNvcnQgbWV0aG9kOjwvaDM+XG5cdFx0XHQ8YnV0dG9uXG5cdFx0XHRcdGlkPVwic29ydERyb3Bkb3duXCJcblx0XHRcdFx0Y2xhc3NOYW1lPXtgc29ydC1kcm9wZG93biAke3Nob3dEcm9wRG93biA/IFwiYWN0aXZlXCIgOiBcIlwifWB9XG5cdFx0XHRcdG9uQ2xpY2s9eygpID0+IHRvZ2dsZURyb3BEb3duKCl9XG5cdFx0XHRcdG9uQmx1cj17ZGlzbWlzc0hhbmRsZXJ9XG5cdFx0XHRcdGFyaWEtbGFiZWw9XCJTb3J0IG1ldGhvZHMgZHJvcGRvd25cIlxuXHRcdFx0PlxuXHRcdFx0XHR7c2VsZWN0U29ydCA/IGBTb3J0IGJ5OiAke3NlbGVjdFNvcnR9YCA6IFwiU2VlIG1ldGhvZHMuLi5cIn1cblx0XHRcdFx0e3Nob3dEcm9wRG93biAmJiAoXG5cdFx0XHRcdFx0PFNvcnREcm9wZG93blxuXHRcdFx0XHRcdFx0c29ydE9wdGlvbnM9e3NvcnRPcHRpb25zKCl9XG5cdFx0XHRcdFx0XHRzaG93RHJvcERvd249e2ZhbHNlfVxuXHRcdFx0XHRcdFx0dG9nZ2xlRHJvcERvd249e3RvZ2dsZURyb3BEb3dufVxuXHRcdFx0XHRcdFx0c29ydE9wdGlvbnNTZWxlY3Rpb249e3NvcnRPcHRpb25zU2VsZWN0aW9ufVxuXHRcdFx0XHRcdC8+XG5cdFx0XHRcdCl9XG5cdFx0XHQ8L2J1dHRvbj5cblx0XHRcdDxidXR0b25cblx0XHRcdFx0aWQ9XCJzb3J0QnV0dG9uXCJcblx0XHRcdFx0Y2xhc3NOYW1lPVwic29ydC1idXR0b25cIlxuXHRcdFx0XHRvbkNsaWNrPXtoYW5kbGVTb3J0fVxuXHRcdFx0XHRhcmlhLWxhYmVsPXtzZWxlY3RTb3J0ID8gYFNvcnQgcmVzb3J0cyBieSAke3NlbGVjdFNvcnR9YCA6IFwiU29ydCByZXNvcnRzIGJ5IHNlbGVjdGVkIG1ldGhvZFwifVxuXHRcdFx0PlxuXHRcdFx0XHRTb3J0XG5cdFx0XHQ8L2J1dHRvbj5cblx0XHQ8L2Rpdj5cblx0KTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2F1c3RpbndpbGxpYW1zL0RvY3VtZW50cy9TY2hvb2wvdGhpcmRTZW1lc3Rlci9DUzMyL3Rlcm0tcHJvamVjdC10YnpoYW8tdHBlenphLXNtc2NodWNoLWJ3aWxsaTQ4L0Zyb250ZW5kL3NraS9zcmMvY29tcG9uZW50cy9zb3J0L1NvcnQudHN4In0=