import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/auth/LogoutButton.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=36ac7ba8"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/auth/LogoutButton.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useAuth0 } from "/node_modules/.vite/deps/@auth0_auth0-react.js?v=36ac7ba8";
const LogoutButton = () => {
  _s();
  const {
    logout
  } = useAuth0();
  return /* @__PURE__ */ jsxDEV("button", { onClick: () => logout({
    logoutParams: {
      returnTo: window.location.origin
    }
  }), "aria-label": "Log out", children: "Log Out" }, void 0, false, {
    fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/auth/LogoutButton.tsx",
    lineNumber: 12,
    columnNumber: 10
  }, this);
};
_s(LogoutButton, "N9yVWTNKvxYzvSt3qgy74ngXZRQ=", false, function() {
  return [useAuth0];
});
_c = LogoutButton;
export default LogoutButton;
var _c;
$RefreshReg$(_c, "LogoutButton");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/auth/LogoutButton.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBU0U7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBVEYsU0FBU0EsZ0JBQWdCO0FBS3pCLE1BQU1DLGVBQWVBLE1BQU07QUFBQUMsS0FBQTtBQUMxQixRQUFNO0FBQUEsSUFBRUM7QUFBQUEsRUFBTyxJQUFJSCxTQUFTO0FBRTVCLFNBQ0MsdUJBQUMsWUFBTyxTQUFTLE1BQU1HLE9BQU87QUFBQSxJQUFFQyxjQUFjO0FBQUEsTUFBRUMsVUFBVUMsT0FBT0MsU0FBU0M7QUFBQUEsSUFBTztBQUFBLEVBQUUsQ0FBQyxHQUFHLGNBQVcsV0FBUyx1QkFBM0c7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUVBO0FBRUY7QUFBRU4sR0FSSUQsY0FBWTtBQUFBLFVBQ0VELFFBQVE7QUFBQTtBQUFBUyxLQUR0QlI7QUFVTixlQUFlQTtBQUFhLElBQUFRO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VBdXRoMCIsIkxvZ291dEJ1dHRvbiIsIl9zIiwibG9nb3V0IiwibG9nb3V0UGFyYW1zIiwicmV0dXJuVG8iLCJ3aW5kb3ciLCJsb2NhdGlvbiIsIm9yaWdpbiIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiTG9nb3V0QnV0dG9uLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyB1c2VBdXRoMCB9IGZyb20gXCJAYXV0aDAvYXV0aDAtcmVhY3RcIjtcblxuLyoqXG4gKiBSZW5kZXJzIGEgYnV0dG9uIGZvciBsb2dnaW5nIG91dCB0aGUgdXNlci5cbiAqL1xuY29uc3QgTG9nb3V0QnV0dG9uID0gKCkgPT4ge1xuXHRjb25zdCB7IGxvZ291dCB9ID0gdXNlQXV0aDAoKTtcblxuXHRyZXR1cm4gKFxuXHRcdDxidXR0b24gb25DbGljaz17KCkgPT4gbG9nb3V0KHsgbG9nb3V0UGFyYW1zOiB7IHJldHVyblRvOiB3aW5kb3cubG9jYXRpb24ub3JpZ2luIH0gfSl9IGFyaWEtbGFiZWw9XCJMb2cgb3V0XCI+XG5cdFx0XHRMb2cgT3V0XG5cdFx0PC9idXR0b24+XG5cdCk7XG59O1xuXG5leHBvcnQgZGVmYXVsdCBMb2dvdXRCdXR0b247XG4iXSwiZmlsZSI6Ii9Vc2Vycy9hdXN0aW53aWxsaWFtcy9Eb2N1bWVudHMvU2Nob29sL3RoaXJkU2VtZXN0ZXIvQ1MzMi90ZXJtLXByb2plY3QtdGJ6aGFvLXRwZXp6YS1zbXNjaHVjaC1id2lsbGk0OC9Gcm9udGVuZC9za2kvc3JjL2NvbXBvbmVudHMvYXV0aC9Mb2dvdXRCdXR0b24udHN4In0=