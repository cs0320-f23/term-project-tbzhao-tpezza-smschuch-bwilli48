import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/prefs/Preferences.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=36ac7ba8"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=36ac7ba8"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import { PreferenceTicker } from "/src/components/prefs/PreferenceTicker.tsx";
import { getMockRankedResorts, getRankedResorts } from "/src/components/resorts/ResortClass.tsx";
import "/src/styles/main.css";
export class PreferenceAndValue {
  constructor(weight, value) {
    this.weight = weight;
    this.value = value;
  }
  upWeight() {
    this.weight += 1;
  }
  downWeight() {
    this.weight -= 1;
  }
  upValue() {
    this.value += 1;
  }
  downValue() {
    this.value -= 1;
  }
}
export function Preferences(props) {
  _s();
  var initialPrefs = /* @__PURE__ */ new Map([["Snowfall Amount", new PreferenceAndValue(5, 5)], ["Last Snowfall", new PreferenceAndValue(5, 5)], ["Base-depth", new PreferenceAndValue(5, 5)], ["Price", new PreferenceAndValue(5, 5)], ["Lifts Open", new PreferenceAndValue(5, 5)], ["Summit Elevation", new PreferenceAndValue(5, 5)], ["Temperature", new PreferenceAndValue(5, 5)], ["Windspeed", new PreferenceAndValue(5, 5)]]);
  const convertUserPrefsToMap = (userPrefs) => {
    const map = /* @__PURE__ */ new Map();
    if (userPrefs) {
      userPrefs.forEach((prefItem, key) => {
        map.set(key, new PreferenceAndValue(prefItem.weight, prefItem.value));
      });
    } else {
      initialPrefs.forEach((value, key) => {
        map.set(key, new PreferenceAndValue(value.weight, value.value));
      });
    }
    return map;
  };
  const [preferenceMap, setPreferenceMap] = useState(() => convertUserPrefsToMap(props.preferences));
  const [reset, setReset] = useState(0);
  function handlePrefSearch() {
    if (props.mockMode) {
      props.setResortList(getMockRankedResorts(preferenceMap));
    } else {
      props.setResortList(getRankedResorts(preferenceMap));
    }
  }
  const handleSaveClick = () => {
    const updatedPreferences = new Map(preferenceMap);
    props.onSavePreferences(updatedPreferences);
  };
  useEffect(() => {
    if (props.preferences !== null) {
      setPreferenceMap(convertUserPrefsToMap(props.preferences));
    }
  }, [props.preferences]);
  return /* @__PURE__ */ jsxDEV("div", { className: "preferences-container", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "preferences-header", children: [
      /* @__PURE__ */ jsxDEV("h2", { children: "Preferences" }, void 0, false, {
        fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
        lineNumber: 110,
        columnNumber: 5
      }, this),
      /* @__PURE__ */ jsxDEV("button", { id: "savePreferencesButton", onClick: handleSaveClick, "aria-label": "Save preferences to your account", children: "Save to Account" }, void 0, false, {
        fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
        lineNumber: 111,
        columnNumber: 5
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
      lineNumber: 109,
      columnNumber: 4
    }, this),
    /* @__PURE__ */ jsxDEV("table", { id: "prefTable", children: [
      /* @__PURE__ */ jsxDEV("tr", { children: [
        /* @__PURE__ */ jsxDEV("td", { children: /* @__PURE__ */ jsxDEV("h4", { children: "Snowfall Amount" }, void 0, false, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
          lineNumber: 118,
          columnNumber: 7
        }, this) }, void 0, false, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
          lineNumber: 117,
          columnNumber: 6
        }, this),
        /* @__PURE__ */ jsxDEV("td", { children: /* @__PURE__ */ jsxDEV(PreferenceTicker, { preferenceMap, setPreferenceMap, preference: "Snowfall Amount", setReset }, void 0, false, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
          lineNumber: 121,
          columnNumber: 7
        }, this) }, void 0, false, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
          lineNumber: 120,
          columnNumber: 6
        }, this),
        /* @__PURE__ */ jsxDEV("td", { className: "spacerDatum" }, void 0, false, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
          lineNumber: 123,
          columnNumber: 6
        }, this),
        /* @__PURE__ */ jsxDEV("td", { children: /* @__PURE__ */ jsxDEV("h4", { children: "Last Snowfall" }, void 0, false, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
          lineNumber: 125,
          columnNumber: 7
        }, this) }, void 0, false, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
          lineNumber: 124,
          columnNumber: 6
        }, this),
        /* @__PURE__ */ jsxDEV("td", { children: /* @__PURE__ */ jsxDEV(PreferenceTicker, { preferenceMap, setPreferenceMap, preference: "Last Snowfall", setReset }, void 0, false, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
          lineNumber: 128,
          columnNumber: 7
        }, this) }, void 0, false, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
          lineNumber: 127,
          columnNumber: 6
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
        lineNumber: 116,
        columnNumber: 5
      }, this),
      /* @__PURE__ */ jsxDEV("tr", { children: [
        /* @__PURE__ */ jsxDEV("td", { children: /* @__PURE__ */ jsxDEV("h4", { children: "Base-depth" }, void 0, false, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
          lineNumber: 133,
          columnNumber: 7
        }, this) }, void 0, false, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
          lineNumber: 132,
          columnNumber: 6
        }, this),
        /* @__PURE__ */ jsxDEV("td", { children: /* @__PURE__ */ jsxDEV(PreferenceTicker, { preferenceMap, setPreferenceMap, preference: "Base-depth", setReset }, void 0, false, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
          lineNumber: 136,
          columnNumber: 7
        }, this) }, void 0, false, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
          lineNumber: 135,
          columnNumber: 6
        }, this),
        /* @__PURE__ */ jsxDEV("td", { className: "spacerDatum" }, void 0, false, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
          lineNumber: 138,
          columnNumber: 6
        }, this),
        /* @__PURE__ */ jsxDEV("td", { children: /* @__PURE__ */ jsxDEV("h4", { children: "Price" }, void 0, false, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
          lineNumber: 140,
          columnNumber: 7
        }, this) }, void 0, false, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
          lineNumber: 139,
          columnNumber: 6
        }, this),
        /* @__PURE__ */ jsxDEV("td", { children: /* @__PURE__ */ jsxDEV(PreferenceTicker, { preferenceMap, setPreferenceMap, preference: "Price", setReset }, void 0, false, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
          lineNumber: 143,
          columnNumber: 7
        }, this) }, void 0, false, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
          lineNumber: 142,
          columnNumber: 6
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
        lineNumber: 131,
        columnNumber: 5
      }, this),
      /* @__PURE__ */ jsxDEV("tr", { children: [
        /* @__PURE__ */ jsxDEV("td", { children: /* @__PURE__ */ jsxDEV("h4", { children: "Lifts Open" }, void 0, false, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
          lineNumber: 148,
          columnNumber: 7
        }, this) }, void 0, false, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
          lineNumber: 147,
          columnNumber: 6
        }, this),
        /* @__PURE__ */ jsxDEV("td", { children: /* @__PURE__ */ jsxDEV(PreferenceTicker, { preferenceMap, setPreferenceMap, preference: "Lifts Open", setReset }, void 0, false, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
          lineNumber: 151,
          columnNumber: 7
        }, this) }, void 0, false, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
          lineNumber: 150,
          columnNumber: 6
        }, this),
        /* @__PURE__ */ jsxDEV("td", { className: "spacerDatum" }, void 0, false, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
          lineNumber: 153,
          columnNumber: 6
        }, this),
        /* @__PURE__ */ jsxDEV("td", { children: /* @__PURE__ */ jsxDEV("h4", { children: "Summit Elevation" }, void 0, false, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
          lineNumber: 155,
          columnNumber: 7
        }, this) }, void 0, false, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
          lineNumber: 154,
          columnNumber: 6
        }, this),
        /* @__PURE__ */ jsxDEV("td", { children: /* @__PURE__ */ jsxDEV(PreferenceTicker, { preferenceMap, setPreferenceMap, preference: "Summit Elevation", setReset }, void 0, false, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
          lineNumber: 158,
          columnNumber: 7
        }, this) }, void 0, false, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
          lineNumber: 157,
          columnNumber: 6
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
        lineNumber: 146,
        columnNumber: 5
      }, this),
      /* @__PURE__ */ jsxDEV("tr", { children: [
        /* @__PURE__ */ jsxDEV("td", { children: /* @__PURE__ */ jsxDEV("h4", { children: "Temperature" }, void 0, false, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
          lineNumber: 163,
          columnNumber: 7
        }, this) }, void 0, false, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
          lineNumber: 162,
          columnNumber: 6
        }, this),
        /* @__PURE__ */ jsxDEV("td", { children: /* @__PURE__ */ jsxDEV(PreferenceTicker, { preferenceMap, setPreferenceMap, preference: "Temperature", setReset }, void 0, false, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
          lineNumber: 166,
          columnNumber: 7
        }, this) }, void 0, false, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
          lineNumber: 165,
          columnNumber: 6
        }, this),
        /* @__PURE__ */ jsxDEV("td", { className: "spacerDatum" }, void 0, false, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
          lineNumber: 168,
          columnNumber: 6
        }, this),
        /* @__PURE__ */ jsxDEV("td", { children: /* @__PURE__ */ jsxDEV("h4", { children: "Windspeed" }, void 0, false, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
          lineNumber: 170,
          columnNumber: 7
        }, this) }, void 0, false, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
          lineNumber: 169,
          columnNumber: 6
        }, this),
        /* @__PURE__ */ jsxDEV("td", { children: /* @__PURE__ */ jsxDEV(PreferenceTicker, { preferenceMap, setPreferenceMap, preference: "Windspeed", setReset }, void 0, false, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
          lineNumber: 173,
          columnNumber: 7
        }, this) }, void 0, false, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
          lineNumber: 172,
          columnNumber: 6
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
        lineNumber: 161,
        columnNumber: 5
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
      lineNumber: 115,
      columnNumber: 4
    }, this),
    /* @__PURE__ */ jsxDEV("button", { id: "preferenceButton", onClick: () => handlePrefSearch(), "aria-label": "Search resorts based on preferences", children: "Search By Preferences" }, void 0, false, {
      fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
      lineNumber: 177,
      columnNumber: 4
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
    lineNumber: 108,
    columnNumber: 10
  }, this);
}
_s(Preferences, "jx/GU6a9+tMitNtY92pgY75uRcs=");
_c = Preferences;
var _c;
$RefreshReg$(_c, "Preferences");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBeUhJOzs7Ozs7Ozs7Ozs7Ozs7OztBQXpISixTQUFtQ0EsVUFBVUMsaUJBQWlCO0FBQzlELFNBQVNDLHdCQUF3QjtBQUNqQyxTQUFTQyxzQkFBc0JDLHdCQUFnQztBQUMvRCxPQUFPO0FBbUJBLGFBQU1DLG1CQUFtQjtBQUFBLEVBSS9CQyxZQUFZQyxRQUFnQkMsT0FBZTtBQUMxQyxTQUFLRCxTQUFTQTtBQUNkLFNBQUtDLFFBQVFBO0FBQUFBLEVBQ2Q7QUFBQSxFQUNBQyxXQUFXO0FBQ1YsU0FBS0YsVUFBVTtBQUFBLEVBQ2hCO0FBQUEsRUFDQUcsYUFBYTtBQUNaLFNBQUtILFVBQVU7QUFBQSxFQUNoQjtBQUFBLEVBQ0FJLFVBQVU7QUFDVCxTQUFLSCxTQUFTO0FBQUEsRUFDZjtBQUFBLEVBQ0FJLFlBQVk7QUFDWCxTQUFLSixTQUFTO0FBQUEsRUFDZjtBQUNEO0FBTU8sZ0JBQVNLLFlBQVlDLE9BQXlCO0FBQUFDLEtBQUE7QUFFcEQsTUFBSUMsZUFBZSxvQkFBSUMsSUFBZ0MsQ0FDdEQsQ0FBQyxtQkFBbUIsSUFBSVosbUJBQW1CLEdBQUcsQ0FBQyxDQUFDLEdBQ2hELENBQUMsaUJBQWlCLElBQUlBLG1CQUFtQixHQUFHLENBQUMsQ0FBQyxHQUM5QyxDQUFDLGNBQWMsSUFBSUEsbUJBQW1CLEdBQUcsQ0FBQyxDQUFDLEdBQzNDLENBQUMsU0FBUyxJQUFJQSxtQkFBbUIsR0FBRyxDQUFDLENBQUMsR0FDdEMsQ0FBQyxjQUFjLElBQUlBLG1CQUFtQixHQUFHLENBQUMsQ0FBQyxHQUMzQyxDQUFDLG9CQUFvQixJQUFJQSxtQkFBbUIsR0FBRyxDQUFDLENBQUMsR0FDakQsQ0FBQyxlQUFlLElBQUlBLG1CQUFtQixHQUFHLENBQUMsQ0FBQyxHQUM1QyxDQUFDLGFBQWEsSUFBSUEsbUJBQW1CLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FDM0M7QUFPRCxRQUFNYSx3QkFBd0JBLENBQUNDLGNBQXVFO0FBQ3JHLFVBQU1DLE1BQU0sb0JBQUlILElBQWdDO0FBQ2hELFFBQUlFLFdBQVc7QUFDZEEsZ0JBQVVFLFFBQVEsQ0FBQ0MsVUFBVUMsUUFBUTtBQUNwQ0gsWUFBSUksSUFBSUQsS0FBSyxJQUFJbEIsbUJBQW1CaUIsU0FBU2YsUUFBUWUsU0FBU2QsS0FBSyxDQUFDO0FBQUEsTUFDckUsQ0FBQztBQUFBLElBQ0YsT0FBTztBQUVOUSxtQkFBYUssUUFBUSxDQUFDYixPQUFPZSxRQUFRO0FBQ3BDSCxZQUFJSSxJQUFJRCxLQUFLLElBQUlsQixtQkFBbUJHLE1BQU1ELFFBQVFDLE1BQU1BLEtBQUssQ0FBQztBQUFBLE1BQy9ELENBQUM7QUFBQSxJQUNGO0FBQ0EsV0FBT1k7QUFBQUEsRUFDUjtBQUdBLFFBQU0sQ0FBQ0ssZUFBZUMsZ0JBQWdCLElBQUkxQixTQUEwQyxNQUNuRmtCLHNCQUFzQkosTUFBTWEsV0FBVyxDQUN4QztBQUdBLFFBQU0sQ0FBQ0MsT0FBT0MsUUFBUSxJQUFJN0IsU0FBaUIsQ0FBQztBQUs1QyxXQUFTOEIsbUJBQW1CO0FBQzNCLFFBQUloQixNQUFNaUIsVUFBVTtBQUNuQmpCLFlBQU1rQixjQUFjN0IscUJBQXFCc0IsYUFBYSxDQUFDO0FBQUEsSUFDeEQsT0FBTztBQUNOWCxZQUFNa0IsY0FBYzVCLGlCQUFpQnFCLGFBQWEsQ0FBQztBQUFBLElBQ3BEO0FBQUEsRUFDRDtBQU1BLFFBQU1RLGtCQUFrQkEsTUFBTTtBQUM3QixVQUFNQyxxQkFBc0MsSUFBSWpCLElBQUlRLGFBQWE7QUFDakVYLFVBQU1xQixrQkFBa0JELGtCQUFrQjtBQUFBLEVBQzNDO0FBS0FqQyxZQUFVLE1BQU07QUFDZixRQUFJYSxNQUFNYSxnQkFBZ0IsTUFBTTtBQUMvQkQsdUJBQWlCUixzQkFBc0JKLE1BQU1hLFdBQVcsQ0FBQztBQUFBLElBQzFEO0FBQUEsRUFDRCxHQUFHLENBQUNiLE1BQU1hLFdBQVcsQ0FBQztBQUV0QixTQUNDLHVCQUFDLFNBQUksV0FBVSx5QkFDZDtBQUFBLDJCQUFDLFNBQUksV0FBVSxzQkFDZDtBQUFBLDZCQUFDLFFBQUcsMkJBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFlO0FBQUEsTUFDZix1QkFBQyxZQUFPLElBQUcseUJBQXdCLFNBQVNNLGlCQUFpQixjQUFXLG9DQUFrQywrQkFBMUc7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBO0FBQUEsU0FKRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBS0E7QUFBQSxJQUNBLHVCQUFDLFdBQU0sSUFBRyxhQUNUO0FBQUEsNkJBQUMsUUFDQTtBQUFBLCtCQUFDLFFBQ0EsaUNBQUMsUUFBRywrQkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW1CLEtBRHBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsUUFDQSxpQ0FBQyxvQkFDQSxlQUNBLGtCQUNBLFlBQVksbUJBQ1osWUFKRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBSW9CLEtBTHJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPQTtBQUFBLFFBQ0EsdUJBQUMsUUFBRyxXQUFVLGlCQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNEI7QUFBQSxRQUM1Qix1QkFBQyxRQUNBLGlDQUFDLFFBQUcsNkJBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpQixLQURsQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLFFBQ0EsaUNBQUMsb0JBQ0EsZUFDQSxrQkFDQSxZQUFZLGlCQUNaLFlBSkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUlvQixLQUxyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBT0E7QUFBQSxXQXZCRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBd0JBO0FBQUEsTUFDQSx1QkFBQyxRQUNBO0FBQUEsK0JBQUMsUUFDQSxpQ0FBQyxRQUFHLDBCQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBYyxLQURmO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsUUFDQSxpQ0FBQyxvQkFDQSxlQUNBLGtCQUNBLFlBQVksY0FDWixZQUpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFJb0IsS0FMckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU9BO0FBQUEsUUFDQSx1QkFBQyxRQUFHLFdBQVUsaUJBQWQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE0QjtBQUFBLFFBQzVCLHVCQUFDLFFBQ0EsaUNBQUMsUUFBRyxxQkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQVMsS0FEVjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLFFBQ0EsaUNBQUMsb0JBQ0EsZUFDQSxrQkFDQSxZQUFZLFNBQ1osWUFKRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBSW9CLEtBTHJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFPQTtBQUFBLFdBdkJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUF3QkE7QUFBQSxNQUNBLHVCQUFDLFFBQ0E7QUFBQSwrQkFBQyxRQUNBLGlDQUFDLFFBQUcsMEJBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFjLEtBRGY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxRQUNBLGlDQUFDLG9CQUNBLGVBQ0Esa0JBQ0EsWUFBWSxjQUNaLFlBSkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUlvQixLQUxyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBT0E7QUFBQSxRQUNBLHVCQUFDLFFBQUcsV0FBVSxpQkFBZDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTRCO0FBQUEsUUFDNUIsdUJBQUMsUUFDQSxpQ0FBQyxRQUFHLGdDQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBb0IsS0FEckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxRQUNBLGlDQUFDLG9CQUNBLGVBQ0Esa0JBQ0EsWUFBWSxvQkFDWixZQUpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFJb0IsS0FMckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU9BO0FBQUEsV0F2QkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXdCQTtBQUFBLE1BQ0EsdUJBQUMsUUFDQTtBQUFBLCtCQUFDLFFBQ0EsaUNBQUMsUUFBRywyQkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWUsS0FEaEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxRQUNBLGlDQUFDLG9CQUNBLGVBQ0Esa0JBQ0EsWUFBWSxlQUNaLFlBSkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUlvQixLQUxyQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBT0E7QUFBQSxRQUNBLHVCQUFDLFFBQUcsV0FBVSxpQkFBZDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTRCO0FBQUEsUUFDNUIsdUJBQUMsUUFDQSxpQ0FBQyxRQUFHLHlCQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBYSxLQURkO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsUUFDQSxpQ0FBQyxvQkFDQSxlQUNBLGtCQUNBLFlBQVksYUFDWixZQUpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFJb0IsS0FMckI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQU9BO0FBQUEsV0F2QkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQXdCQTtBQUFBLFNBcEdEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FxR0E7QUFBQSxJQUNBLHVCQUFDLFlBQU8sSUFBRyxvQkFBbUIsU0FBUyxNQUFNSCxpQkFBaUIsR0FBRyxjQUFXLHVDQUFxQyxxQ0FBakg7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsT0EvR0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWdIQTtBQUVGO0FBQUNmLEdBekxlRixhQUFXO0FBQUF1QixLQUFYdkI7QUFBVyxJQUFBdUI7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlRWZmZWN0IiwiUHJlZmVyZW5jZVRpY2tlciIsImdldE1vY2tSYW5rZWRSZXNvcnRzIiwiZ2V0UmFua2VkUmVzb3J0cyIsIlByZWZlcmVuY2VBbmRWYWx1ZSIsImNvbnN0cnVjdG9yIiwid2VpZ2h0IiwidmFsdWUiLCJ1cFdlaWdodCIsImRvd25XZWlnaHQiLCJ1cFZhbHVlIiwiZG93blZhbHVlIiwiUHJlZmVyZW5jZXMiLCJwcm9wcyIsIl9zIiwiaW5pdGlhbFByZWZzIiwiTWFwIiwiY29udmVydFVzZXJQcmVmc1RvTWFwIiwidXNlclByZWZzIiwibWFwIiwiZm9yRWFjaCIsInByZWZJdGVtIiwia2V5Iiwic2V0IiwicHJlZmVyZW5jZU1hcCIsInNldFByZWZlcmVuY2VNYXAiLCJwcmVmZXJlbmNlcyIsInJlc2V0Iiwic2V0UmVzZXQiLCJoYW5kbGVQcmVmU2VhcmNoIiwibW9ja01vZGUiLCJzZXRSZXNvcnRMaXN0IiwiaGFuZGxlU2F2ZUNsaWNrIiwidXBkYXRlZFByZWZlcmVuY2VzIiwib25TYXZlUHJlZmVyZW5jZXMiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlByZWZlcmVuY2VzLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBEaXNwYXRjaCwgU2V0U3RhdGVBY3Rpb24sIHVzZVN0YXRlLCB1c2VFZmZlY3QgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IFByZWZlcmVuY2VUaWNrZXIgfSBmcm9tIFwiLi9QcmVmZXJlbmNlVGlja2VyXCI7XG5pbXBvcnQgeyBnZXRNb2NrUmFua2VkUmVzb3J0cywgZ2V0UmFua2VkUmVzb3J0cywgUmVzb3J0IH0gZnJvbSBcIi4uL3Jlc29ydHMvUmVzb3J0Q2xhc3NcIjtcbmltcG9ydCBcIi4uLy4uL3N0eWxlcy9tYWluLmNzc1wiO1xuXG4vLyBQcm9wZXJ0aWVzIGZvciB0aGUgUHJlZmVyZW5jZXMgY29tcG9uZW50LlxuaW50ZXJmYWNlIFByZWZlcmVuY2VzUHJvcHMge1xuXHRyZXNvcnRMaXN0OiBSZXNvcnRbXTtcblx0c2V0UmVzb3J0TGlzdDogRGlzcGF0Y2g8U2V0U3RhdGVBY3Rpb248UmVzb3J0W10+Pjtcblx0cHJlZmVyZW5jZXM6IFVzZXJQcmVmZXJlbmNlcyB8IG51bGw7XG5cdG9uU2F2ZVByZWZlcmVuY2VzOiAobmV3UHJlZmVyZW5jZXM6IFVzZXJQcmVmZXJlbmNlcykgPT4gdm9pZDtcblx0bW9ja01vZGU6IGJvb2xlYW47XG59XG5cbi8vIFR5cGVzIHVzZWQgZm9yIGFjY291bnQgcHJlZmVyZW5jZSBzYXZpbmcuXG5leHBvcnQgdHlwZSBVc2VyUHJlZmVyZW5jZXMgPSBNYXA8c3RyaW5nLCBQcmVmZXJlbmNlSXRlbT47XG5leHBvcnQgdHlwZSBQcmVmZXJlbmNlSXRlbSA9IHtcblx0d2VpZ2h0OiBudW1iZXI7XG5cdHZhbHVlOiBudW1iZXI7XG59O1xuXG4vLyBDbGFzcyByZXByZXNlbnRpbmcgYSB3ZWlnaHQtdmFsdWUgcGFpciBmb3IgYSBwcmVmZXJlbmNlLlxuZXhwb3J0IGNsYXNzIFByZWZlcmVuY2VBbmRWYWx1ZSB7XG5cdHdlaWdodDogbnVtYmVyO1xuXHR2YWx1ZTogbnVtYmVyO1xuXG5cdGNvbnN0cnVjdG9yKHdlaWdodDogbnVtYmVyLCB2YWx1ZTogbnVtYmVyKSB7XG5cdFx0dGhpcy53ZWlnaHQgPSB3ZWlnaHQ7XG5cdFx0dGhpcy52YWx1ZSA9IHZhbHVlO1xuXHR9XG5cdHVwV2VpZ2h0KCkge1xuXHRcdHRoaXMud2VpZ2h0ICs9IDE7XG5cdH1cblx0ZG93bldlaWdodCgpIHtcblx0XHR0aGlzLndlaWdodCAtPSAxO1xuXHR9XG5cdHVwVmFsdWUoKSB7XG5cdFx0dGhpcy52YWx1ZSArPSAxO1xuXHR9XG5cdGRvd25WYWx1ZSgpIHtcblx0XHR0aGlzLnZhbHVlIC09IDE7XG5cdH1cbn1cblxuLyoqXG4gKiBSZW5kZXJzIGEgdGFibGUgb2YgdXNlciBwcmVmZXJlbmNlcyByZWdhcmRpbmcgcmVzb3J0IGNvbmRpdGlvbnMuIFVzZXJzIGNhbiBhZGp1c3QgdGhlXG4gKiB3ZWlnaHQgYW5kIHZhbHVlIG9mIGVhY2ggcHJlZmVyZW5jZSwgd2hpY2ggaXMgdXNlZCB0byBzb3J0IHRoZSBsaXN0IG9mIHJlc29ydHMuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBQcmVmZXJlbmNlcyhwcm9wczogUHJlZmVyZW5jZXNQcm9wcykge1xuXHQvLyBJbml0aWFsIHByZWZlcmVuY2VzIHRoYXQgYXJlIHNldCBmb3IgYSBuZXcgdXNlci5cblx0dmFyIGluaXRpYWxQcmVmcyA9IG5ldyBNYXA8c3RyaW5nLCBQcmVmZXJlbmNlQW5kVmFsdWU+KFtcblx0XHRbXCJTbm93ZmFsbCBBbW91bnRcIiwgbmV3IFByZWZlcmVuY2VBbmRWYWx1ZSg1LCA1KV0sXG5cdFx0W1wiTGFzdCBTbm93ZmFsbFwiLCBuZXcgUHJlZmVyZW5jZUFuZFZhbHVlKDUsIDUpXSxcblx0XHRbXCJCYXNlLWRlcHRoXCIsIG5ldyBQcmVmZXJlbmNlQW5kVmFsdWUoNSwgNSldLFxuXHRcdFtcIlByaWNlXCIsIG5ldyBQcmVmZXJlbmNlQW5kVmFsdWUoNSwgNSldLFxuXHRcdFtcIkxpZnRzIE9wZW5cIiwgbmV3IFByZWZlcmVuY2VBbmRWYWx1ZSg1LCA1KV0sXG5cdFx0W1wiU3VtbWl0IEVsZXZhdGlvblwiLCBuZXcgUHJlZmVyZW5jZUFuZFZhbHVlKDUsIDUpXSxcblx0XHRbXCJUZW1wZXJhdHVyZVwiLCBuZXcgUHJlZmVyZW5jZUFuZFZhbHVlKDUsIDUpXSxcblx0XHRbXCJXaW5kc3BlZWRcIiwgbmV3IFByZWZlcmVuY2VBbmRWYWx1ZSg1LCA1KV0sXG5cdF0pO1xuXG5cdC8qKlxuXHQgKiBDb252ZXJ0cyB0aGUgVXNlclByZWZlcmVuY2VzIG9iamVjdCB0byBhIG1hcCBvZiBzdHJpbmcgdG8gUHJlZmVyZW5jZUFuZFZhbHVlLlxuXHQgKiBAcGFyYW0gdXNlclByZWZzIFRoZSBVc2VyUHJlZmVyZW5jZXMgb2JqZWN0IHRvIGNvbnZlcnQuXG5cdCAqIEByZXR1cm5zIG1hcCByZXByZXNlbnRpbmcgdGhlIHVzZXIgcHJlZmVyZW5jZXMuXG5cdCAqL1xuXHRjb25zdCBjb252ZXJ0VXNlclByZWZzVG9NYXAgPSAodXNlclByZWZzOiBVc2VyUHJlZmVyZW5jZXMgfCBudWxsKTogTWFwPHN0cmluZywgUHJlZmVyZW5jZUFuZFZhbHVlPiA9PiB7XG5cdFx0Y29uc3QgbWFwID0gbmV3IE1hcDxzdHJpbmcsIFByZWZlcmVuY2VBbmRWYWx1ZT4oKTtcblx0XHRpZiAodXNlclByZWZzKSB7XG5cdFx0XHR1c2VyUHJlZnMuZm9yRWFjaCgocHJlZkl0ZW0sIGtleSkgPT4ge1xuXHRcdFx0XHRtYXAuc2V0KGtleSwgbmV3IFByZWZlcmVuY2VBbmRWYWx1ZShwcmVmSXRlbS53ZWlnaHQsIHByZWZJdGVtLnZhbHVlKSk7XG5cdFx0XHR9KTtcblx0XHR9IGVsc2Uge1xuXHRcdFx0Ly8gUG9wdWxhdGUgbWFwIHdpdGggaW5pdGlhbCBwcmVmZXJlbmNlcyBpZiB1c2VyUHJlZnMgaXMgbnVsbFxuXHRcdFx0aW5pdGlhbFByZWZzLmZvckVhY2goKHZhbHVlLCBrZXkpID0+IHtcblx0XHRcdFx0bWFwLnNldChrZXksIG5ldyBQcmVmZXJlbmNlQW5kVmFsdWUodmFsdWUud2VpZ2h0LCB2YWx1ZS52YWx1ZSkpO1xuXHRcdFx0fSk7XG5cdFx0fVxuXHRcdHJldHVybiBtYXA7XG5cdH07XG5cblx0Ly8gU3RhdGUgZm9yIHRoZSBwcmVmZXJlbmNlIG1hcC5cblx0Y29uc3QgW3ByZWZlcmVuY2VNYXAsIHNldFByZWZlcmVuY2VNYXBdID0gdXNlU3RhdGU8TWFwPHN0cmluZywgUHJlZmVyZW5jZUFuZFZhbHVlPj4oKCkgPT5cblx0XHRjb252ZXJ0VXNlclByZWZzVG9NYXAocHJvcHMucHJlZmVyZW5jZXMpXG5cdCk7XG5cblx0Ly8gU3RhdGUgZm9yIHRoZSByZXNldCBvYmplY3QuXG5cdGNvbnN0IFtyZXNldCwgc2V0UmVzZXRdID0gdXNlU3RhdGU8bnVtYmVyPigwKTtcblxuXHQvKipcblx0ICogVXBkYXRlcyB0aGUgcmVzb3J0IGxpc3QgYmFzZWQgb24gYSB1c2VyJ3MgY3VzdG9tIHByZWZlcmVuY2VzLlxuXHQgKi9cblx0ZnVuY3Rpb24gaGFuZGxlUHJlZlNlYXJjaCgpIHtcblx0XHRpZiAocHJvcHMubW9ja01vZGUpIHtcblx0XHRcdHByb3BzLnNldFJlc29ydExpc3QoZ2V0TW9ja1JhbmtlZFJlc29ydHMocHJlZmVyZW5jZU1hcCkpO1xuXHRcdH0gZWxzZSB7XG5cdFx0XHRwcm9wcy5zZXRSZXNvcnRMaXN0KGdldFJhbmtlZFJlc29ydHMocHJlZmVyZW5jZU1hcCkpO1xuXHRcdH1cblx0fVxuXG5cdC8qKlxuXHQgKiBIYW5kbGVzIHNhdmluZyB0aGUgY3VycmVudCBzdGF0ZSBvZiB1c2VyIHByZWZlcmVuY2VzLiBUcmlnZ2VyZWQgd2hlbiB0aGVcblx0ICogJ1NhdmUgdG8gQWNjb3VudCcgYnV0dG9uIGlzIGNsaWNrZWQuXG5cdCAqL1xuXHRjb25zdCBoYW5kbGVTYXZlQ2xpY2sgPSAoKSA9PiB7XG5cdFx0Y29uc3QgdXBkYXRlZFByZWZlcmVuY2VzOiBVc2VyUHJlZmVyZW5jZXMgPSBuZXcgTWFwKHByZWZlcmVuY2VNYXApO1xuXHRcdHByb3BzLm9uU2F2ZVByZWZlcmVuY2VzKHVwZGF0ZWRQcmVmZXJlbmNlcyk7XG5cdH07XG5cblx0LyoqXG5cdCAqIHVzZUVmZmVjdCBob29rIHRvIHVwZGF0ZSB0aGUgcHJlZmVyZW5jZU1hcCBzdGF0ZSB3aGVuZXZlciB0aGUgcHJvcHMucHJlZmVyZW5jZXMgY2hhbmdlcy5cblx0ICovXG5cdHVzZUVmZmVjdCgoKSA9PiB7XG5cdFx0aWYgKHByb3BzLnByZWZlcmVuY2VzICE9PSBudWxsKSB7XG5cdFx0XHRzZXRQcmVmZXJlbmNlTWFwKGNvbnZlcnRVc2VyUHJlZnNUb01hcChwcm9wcy5wcmVmZXJlbmNlcykpO1xuXHRcdH1cblx0fSwgW3Byb3BzLnByZWZlcmVuY2VzXSk7XG5cblx0cmV0dXJuIChcblx0XHQ8ZGl2IGNsYXNzTmFtZT1cInByZWZlcmVuY2VzLWNvbnRhaW5lclwiPlxuXHRcdFx0PGRpdiBjbGFzc05hbWU9XCJwcmVmZXJlbmNlcy1oZWFkZXJcIj5cblx0XHRcdFx0PGgyPlByZWZlcmVuY2VzPC9oMj5cblx0XHRcdFx0PGJ1dHRvbiBpZD1cInNhdmVQcmVmZXJlbmNlc0J1dHRvblwiIG9uQ2xpY2s9e2hhbmRsZVNhdmVDbGlja30gYXJpYS1sYWJlbD1cIlNhdmUgcHJlZmVyZW5jZXMgdG8geW91ciBhY2NvdW50XCI+XG5cdFx0XHRcdFx0U2F2ZSB0byBBY2NvdW50XG5cdFx0XHRcdDwvYnV0dG9uPlxuXHRcdFx0PC9kaXY+XG5cdFx0XHQ8dGFibGUgaWQ9XCJwcmVmVGFibGVcIj5cblx0XHRcdFx0PHRyPlxuXHRcdFx0XHRcdDx0ZD5cblx0XHRcdFx0XHRcdDxoND5Tbm93ZmFsbCBBbW91bnQ8L2g0PlxuXHRcdFx0XHRcdDwvdGQ+XG5cdFx0XHRcdFx0PHRkPlxuXHRcdFx0XHRcdFx0PFByZWZlcmVuY2VUaWNrZXJcblx0XHRcdFx0XHRcdFx0cHJlZmVyZW5jZU1hcD17cHJlZmVyZW5jZU1hcH1cblx0XHRcdFx0XHRcdFx0c2V0UHJlZmVyZW5jZU1hcD17c2V0UHJlZmVyZW5jZU1hcH1cblx0XHRcdFx0XHRcdFx0cHJlZmVyZW5jZT17XCJTbm93ZmFsbCBBbW91bnRcIn1cblx0XHRcdFx0XHRcdFx0c2V0UmVzZXQ9e3NldFJlc2V0fVxuXHRcdFx0XHRcdFx0Lz5cblx0XHRcdFx0XHQ8L3RkPlxuXHRcdFx0XHRcdDx0ZCBjbGFzc05hbWU9XCJzcGFjZXJEYXR1bVwiPjwvdGQ+XG5cdFx0XHRcdFx0PHRkPlxuXHRcdFx0XHRcdFx0PGg0Pkxhc3QgU25vd2ZhbGw8L2g0PlxuXHRcdFx0XHRcdDwvdGQ+XG5cdFx0XHRcdFx0PHRkPlxuXHRcdFx0XHRcdFx0PFByZWZlcmVuY2VUaWNrZXJcblx0XHRcdFx0XHRcdFx0cHJlZmVyZW5jZU1hcD17cHJlZmVyZW5jZU1hcH1cblx0XHRcdFx0XHRcdFx0c2V0UHJlZmVyZW5jZU1hcD17c2V0UHJlZmVyZW5jZU1hcH1cblx0XHRcdFx0XHRcdFx0cHJlZmVyZW5jZT17XCJMYXN0IFNub3dmYWxsXCJ9XG5cdFx0XHRcdFx0XHRcdHNldFJlc2V0PXtzZXRSZXNldH1cblx0XHRcdFx0XHRcdC8+XG5cdFx0XHRcdFx0PC90ZD5cblx0XHRcdFx0PC90cj5cblx0XHRcdFx0PHRyPlxuXHRcdFx0XHRcdDx0ZD5cblx0XHRcdFx0XHRcdDxoND5CYXNlLWRlcHRoPC9oND5cblx0XHRcdFx0XHQ8L3RkPlxuXHRcdFx0XHRcdDx0ZD5cblx0XHRcdFx0XHRcdDxQcmVmZXJlbmNlVGlja2VyXG5cdFx0XHRcdFx0XHRcdHByZWZlcmVuY2VNYXA9e3ByZWZlcmVuY2VNYXB9XG5cdFx0XHRcdFx0XHRcdHNldFByZWZlcmVuY2VNYXA9e3NldFByZWZlcmVuY2VNYXB9XG5cdFx0XHRcdFx0XHRcdHByZWZlcmVuY2U9e1wiQmFzZS1kZXB0aFwifVxuXHRcdFx0XHRcdFx0XHRzZXRSZXNldD17c2V0UmVzZXR9XG5cdFx0XHRcdFx0XHQvPlxuXHRcdFx0XHRcdDwvdGQ+XG5cdFx0XHRcdFx0PHRkIGNsYXNzTmFtZT1cInNwYWNlckRhdHVtXCI+PC90ZD5cblx0XHRcdFx0XHQ8dGQ+XG5cdFx0XHRcdFx0XHQ8aDQ+UHJpY2U8L2g0PlxuXHRcdFx0XHRcdDwvdGQ+XG5cdFx0XHRcdFx0PHRkPlxuXHRcdFx0XHRcdFx0PFByZWZlcmVuY2VUaWNrZXJcblx0XHRcdFx0XHRcdFx0cHJlZmVyZW5jZU1hcD17cHJlZmVyZW5jZU1hcH1cblx0XHRcdFx0XHRcdFx0c2V0UHJlZmVyZW5jZU1hcD17c2V0UHJlZmVyZW5jZU1hcH1cblx0XHRcdFx0XHRcdFx0cHJlZmVyZW5jZT17XCJQcmljZVwifVxuXHRcdFx0XHRcdFx0XHRzZXRSZXNldD17c2V0UmVzZXR9XG5cdFx0XHRcdFx0XHQvPlxuXHRcdFx0XHRcdDwvdGQ+XG5cdFx0XHRcdDwvdHI+XG5cdFx0XHRcdDx0cj5cblx0XHRcdFx0XHQ8dGQ+XG5cdFx0XHRcdFx0XHQ8aDQ+TGlmdHMgT3BlbjwvaDQ+XG5cdFx0XHRcdFx0PC90ZD5cblx0XHRcdFx0XHQ8dGQ+XG5cdFx0XHRcdFx0XHQ8UHJlZmVyZW5jZVRpY2tlclxuXHRcdFx0XHRcdFx0XHRwcmVmZXJlbmNlTWFwPXtwcmVmZXJlbmNlTWFwfVxuXHRcdFx0XHRcdFx0XHRzZXRQcmVmZXJlbmNlTWFwPXtzZXRQcmVmZXJlbmNlTWFwfVxuXHRcdFx0XHRcdFx0XHRwcmVmZXJlbmNlPXtcIkxpZnRzIE9wZW5cIn1cblx0XHRcdFx0XHRcdFx0c2V0UmVzZXQ9e3NldFJlc2V0fVxuXHRcdFx0XHRcdFx0Lz5cblx0XHRcdFx0XHQ8L3RkPlxuXHRcdFx0XHRcdDx0ZCBjbGFzc05hbWU9XCJzcGFjZXJEYXR1bVwiPjwvdGQ+XG5cdFx0XHRcdFx0PHRkPlxuXHRcdFx0XHRcdFx0PGg0PlN1bW1pdCBFbGV2YXRpb248L2g0PlxuXHRcdFx0XHRcdDwvdGQ+XG5cdFx0XHRcdFx0PHRkPlxuXHRcdFx0XHRcdFx0PFByZWZlcmVuY2VUaWNrZXJcblx0XHRcdFx0XHRcdFx0cHJlZmVyZW5jZU1hcD17cHJlZmVyZW5jZU1hcH1cblx0XHRcdFx0XHRcdFx0c2V0UHJlZmVyZW5jZU1hcD17c2V0UHJlZmVyZW5jZU1hcH1cblx0XHRcdFx0XHRcdFx0cHJlZmVyZW5jZT17XCJTdW1taXQgRWxldmF0aW9uXCJ9XG5cdFx0XHRcdFx0XHRcdHNldFJlc2V0PXtzZXRSZXNldH1cblx0XHRcdFx0XHRcdC8+XG5cdFx0XHRcdFx0PC90ZD5cblx0XHRcdFx0PC90cj5cblx0XHRcdFx0PHRyPlxuXHRcdFx0XHRcdDx0ZD5cblx0XHRcdFx0XHRcdDxoND5UZW1wZXJhdHVyZTwvaDQ+XG5cdFx0XHRcdFx0PC90ZD5cblx0XHRcdFx0XHQ8dGQ+XG5cdFx0XHRcdFx0XHQ8UHJlZmVyZW5jZVRpY2tlclxuXHRcdFx0XHRcdFx0XHRwcmVmZXJlbmNlTWFwPXtwcmVmZXJlbmNlTWFwfVxuXHRcdFx0XHRcdFx0XHRzZXRQcmVmZXJlbmNlTWFwPXtzZXRQcmVmZXJlbmNlTWFwfVxuXHRcdFx0XHRcdFx0XHRwcmVmZXJlbmNlPXtcIlRlbXBlcmF0dXJlXCJ9XG5cdFx0XHRcdFx0XHRcdHNldFJlc2V0PXtzZXRSZXNldH1cblx0XHRcdFx0XHRcdC8+XG5cdFx0XHRcdFx0PC90ZD5cblx0XHRcdFx0XHQ8dGQgY2xhc3NOYW1lPVwic3BhY2VyRGF0dW1cIj48L3RkPlxuXHRcdFx0XHRcdDx0ZD5cblx0XHRcdFx0XHRcdDxoND5XaW5kc3BlZWQ8L2g0PlxuXHRcdFx0XHRcdDwvdGQ+XG5cdFx0XHRcdFx0PHRkPlxuXHRcdFx0XHRcdFx0PFByZWZlcmVuY2VUaWNrZXJcblx0XHRcdFx0XHRcdFx0cHJlZmVyZW5jZU1hcD17cHJlZmVyZW5jZU1hcH1cblx0XHRcdFx0XHRcdFx0c2V0UHJlZmVyZW5jZU1hcD17c2V0UHJlZmVyZW5jZU1hcH1cblx0XHRcdFx0XHRcdFx0cHJlZmVyZW5jZT17XCJXaW5kc3BlZWRcIn1cblx0XHRcdFx0XHRcdFx0c2V0UmVzZXQ9e3NldFJlc2V0fVxuXHRcdFx0XHRcdFx0Lz5cblx0XHRcdFx0XHQ8L3RkPlxuXHRcdFx0XHQ8L3RyPlxuXHRcdFx0PC90YWJsZT5cblx0XHRcdDxidXR0b24gaWQ9XCJwcmVmZXJlbmNlQnV0dG9uXCIgb25DbGljaz17KCkgPT4gaGFuZGxlUHJlZlNlYXJjaCgpfSBhcmlhLWxhYmVsPVwiU2VhcmNoIHJlc29ydHMgYmFzZWQgb24gcHJlZmVyZW5jZXNcIj5cblx0XHRcdFx0U2VhcmNoIEJ5IFByZWZlcmVuY2VzXG5cdFx0XHQ8L2J1dHRvbj5cblx0XHQ8L2Rpdj5cblx0KTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2F1c3RpbndpbGxpYW1zL0RvY3VtZW50cy9TY2hvb2wvdGhpcmRTZW1lc3Rlci9DUzMyL3Rlcm0tcHJvamVjdC10YnpoYW8tdHBlenphLXNtc2NodWNoLWJ3aWxsaTQ4L0Zyb250ZW5kL3NraS9zcmMvY29tcG9uZW50cy9wcmVmcy9QcmVmZXJlbmNlcy50c3gifQ==