import {
  require_react
} from "/node_modules/.vite/deps/chunk-MYQCFY5U.js?v=36ac7ba8";
export default require_react();
//# sourceMappingURL=react.js.map
