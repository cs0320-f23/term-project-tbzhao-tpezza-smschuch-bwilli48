import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/search/Search.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=36ac7ba8"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/search/Search.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import "/src/styles/main.css";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=36ac7ba8"; const useState = __vite__cjsImport4_react["useState"];
import { ControlledInput } from "/src/components/search/ControlledInput.tsx";
import { ResortDropdown } from "/src/components/search/ResortsDropdown.tsx";
import { getMockSearchResort, getSearchResort, mockResortNames, resortNames } from "/src/components/resorts/ResortClass.tsx";
export function Search(props) {
  _s();
  const [showDropDown, setShowDropDown] = useState(false);
  const [selectResort, setSelectResort] = useState("");
  const [commandString, setCommandString] = useState("");
  var resorts = props.mockMode ? mockResortNames() : resortNames();
  const toggleDropDown = () => {
    setShowDropDown(!showDropDown);
  };
  const dismissHandler = (event) => {
    if (event.currentTarget === event.target) {
      setShowDropDown(false);
    }
  };
  const resortOptionsSelection = (resortOption) => {
    setSelectResort(resortOption);
  };
  function handleSearch(commandString2) {
    if (commandString2 !== "") {
      const result = props.mockMode ? getMockSearchResort(commandString2) : getSearchResort(commandString2);
      props.setResortList(result);
    }
    setCommandString("");
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "search-container", "aria-label": "Resort search section", children: [
    /* @__PURE__ */ jsxDEV("h3", { className: "search-title", children: "Search for a specific resort:" }, void 0, false, {
      fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/search/Search.tsx",
      lineNumber: 69,
      columnNumber: 4
    }, this),
    /* @__PURE__ */ jsxDEV(ControlledInput, { value: commandString, setValue: setCommandString, onKeyDown: (event) => {
      if (event.key === "Enter") {
        event.preventDefault();
        handleSearch(commandString);
      }
    } }, void 0, false, {
      fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/search/Search.tsx",
      lineNumber: 70,
      columnNumber: 4
    }, this),
    /* @__PURE__ */ jsxDEV("button", { className: "search-button", id: "searchButton", onClick: () => handleSearch(commandString), "aria-label": "Search for a resort", children: "Search" }, void 0, false, {
      fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/search/Search.tsx",
      lineNumber: 76,
      columnNumber: 4
    }, this),
    /* @__PURE__ */ jsxDEV("button", { id: "searchDropdown", className: `search-dropdown ${showDropDown ? "active" : ""}`, onClick: toggleDropDown, onBlur: dismissHandler, "aria-label": "Show or hide resort list dropdown", children: [
      selectResort ? "See resorts ..." : " See full list of resorts...",
      showDropDown && /* @__PURE__ */ jsxDEV(ResortDropdown, { resortOptions: resorts, showDropDown, toggleDropDown, resortOptionsSelection, setCommandString }, void 0, false, {
        fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/search/Search.tsx",
        lineNumber: 81,
        columnNumber: 22
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/search/Search.tsx",
      lineNumber: 79,
      columnNumber: 4
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/search/Search.tsx",
    lineNumber: 68,
    columnNumber: 10
  }, this);
}
_s(Search, "MWG6vfGHnpn+8k15vYOqi1LjzPs=");
_c = Search;
var _c;
$RefreshReg$(_c, "Search");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/search/Search.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBNEVHOzs7Ozs7Ozs7Ozs7Ozs7OztBQTVFSCxPQUFPO0FBQ1AsU0FBbUNBLGdCQUFnQjtBQUNuRCxTQUFTQyx1QkFBdUI7QUFDaEMsU0FBU0Msc0JBQXNCO0FBQy9CLFNBQ0NDLHFCQUNBQyxpQkFDQUMsaUJBR0FDLG1CQUNNO0FBZUEsZ0JBQVNDLE9BQU9DLE9BQW9CO0FBQUFDLEtBQUE7QUFFMUMsUUFBTSxDQUFDQyxjQUFjQyxlQUFlLElBQUlYLFNBQWtCLEtBQUs7QUFHL0QsUUFBTSxDQUFDWSxjQUFjQyxlQUFlLElBQUliLFNBQWlCLEVBQUU7QUFHM0QsUUFBTSxDQUFDYyxlQUFlQyxnQkFBZ0IsSUFBSWYsU0FBaUIsRUFBRTtBQUU3RCxNQUFJZ0IsVUFBb0JSLE1BQU1TLFdBQVdaLGdCQUFnQixJQUFJQyxZQUFZO0FBS3pFLFFBQU1ZLGlCQUFpQkEsTUFBTTtBQUM1QlAsb0JBQWdCLENBQUNELFlBQVk7QUFBQSxFQUM5QjtBQUtBLFFBQU1TLGlCQUFpQkEsQ0FBQ0MsVUFBcUQ7QUFDNUUsUUFBSUEsTUFBTUMsa0JBQWtCRCxNQUFNRSxRQUFRO0FBQ3pDWCxzQkFBZ0IsS0FBSztBQUFBLElBQ3RCO0FBQUEsRUFDRDtBQU1BLFFBQU1ZLHlCQUF5QkEsQ0FBQ0MsaUJBQStCO0FBQzlEWCxvQkFBZ0JXLFlBQVk7QUFBQSxFQUM3QjtBQU1BLFdBQVNDLGFBQWFYLGdCQUF1QjtBQUM1QyxRQUFJQSxtQkFBa0IsSUFBSTtBQUN6QixZQUFNWSxTQUFTbEIsTUFBTVMsV0FBV2Qsb0JBQW9CVyxjQUFhLElBQUlWLGdCQUFnQlUsY0FBYTtBQUNsR04sWUFBTW1CLGNBQWNELE1BQU07QUFBQSxJQUMzQjtBQUNBWCxxQkFBaUIsRUFBRTtBQUFBLEVBQ3BCO0FBRUEsU0FDQyx1QkFBQyxTQUFJLFdBQVUsb0JBQW1CLGNBQVcseUJBQzVDO0FBQUEsMkJBQUMsUUFBRyxXQUFVLGdCQUFlLDZDQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTBEO0FBQUEsSUFDMUQsdUJBQUMsbUJBQ0EsT0FBT0QsZUFDUCxVQUFVQyxrQkFDVixXQUFZSyxXQUFVO0FBQ3JCLFVBQUlBLE1BQU1RLFFBQVEsU0FBUztBQUMxQlIsY0FBTVMsZUFBZTtBQUNyQkoscUJBQWFYLGFBQWE7QUFBQSxNQUMzQjtBQUFBLElBQ0QsS0FSRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBUUc7QUFBQSxJQUVILHVCQUFDLFlBQ0EsV0FBVSxpQkFDVixJQUFHLGdCQUNILFNBQVMsTUFBTVcsYUFBYVgsYUFBYSxHQUN6QyxjQUFXLHVCQUFxQixzQkFKakM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU9BO0FBQUEsSUFDQSx1QkFBQyxZQUNBLElBQUcsa0JBQ0gsV0FBWSxtQkFBa0JKLGVBQWUsV0FBVyxFQUFHLElBQzNELFNBQVNRLGdCQUNULFFBQVFDLGdCQUNSLGNBQVcscUNBRVZQO0FBQUFBLHFCQUFlLG9CQUFvQjtBQUFBLE1BQ25DRixnQkFDQSx1QkFBQyxrQkFDQSxlQUFlTSxTQUNmLGNBQ0EsZ0JBQ0Esd0JBQ0Esb0JBTEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtvQztBQUFBLFNBZHRDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FpQkE7QUFBQSxPQXJDRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBc0NBO0FBRUY7QUFBQ1AsR0F6RmVGLFFBQU07QUFBQXVCLEtBQU52QjtBQUFNLElBQUF1QjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsidXNlU3RhdGUiLCJDb250cm9sbGVkSW5wdXQiLCJSZXNvcnREcm9wZG93biIsImdldE1vY2tTZWFyY2hSZXNvcnQiLCJnZXRTZWFyY2hSZXNvcnQiLCJtb2NrUmVzb3J0TmFtZXMiLCJyZXNvcnROYW1lcyIsIlNlYXJjaCIsInByb3BzIiwiX3MiLCJzaG93RHJvcERvd24iLCJzZXRTaG93RHJvcERvd24iLCJzZWxlY3RSZXNvcnQiLCJzZXRTZWxlY3RSZXNvcnQiLCJjb21tYW5kU3RyaW5nIiwic2V0Q29tbWFuZFN0cmluZyIsInJlc29ydHMiLCJtb2NrTW9kZSIsInRvZ2dsZURyb3BEb3duIiwiZGlzbWlzc0hhbmRsZXIiLCJldmVudCIsImN1cnJlbnRUYXJnZXQiLCJ0YXJnZXQiLCJyZXNvcnRPcHRpb25zU2VsZWN0aW9uIiwicmVzb3J0T3B0aW9uIiwiaGFuZGxlU2VhcmNoIiwicmVzdWx0Iiwic2V0UmVzb3J0TGlzdCIsImtleSIsInByZXZlbnREZWZhdWx0IiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJTZWFyY2gudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBcIi4uLy4uL3N0eWxlcy9tYWluLmNzc1wiO1xuaW1wb3J0IHsgRGlzcGF0Y2gsIFNldFN0YXRlQWN0aW9uLCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgQ29udHJvbGxlZElucHV0IH0gZnJvbSBcIi4vQ29udHJvbGxlZElucHV0XCI7XG5pbXBvcnQgeyBSZXNvcnREcm9wZG93biB9IGZyb20gXCIuL1Jlc29ydHNEcm9wZG93blwiO1xuaW1wb3J0IHtcblx0Z2V0TW9ja1NlYXJjaFJlc29ydCxcblx0Z2V0U2VhcmNoUmVzb3J0LFxuXHRtb2NrUmVzb3J0TmFtZXMsXG5cdG1vY2tSZXNvcnRzU2VhcmNoLFxuXHRSZXNvcnQsXG5cdHJlc29ydE5hbWVzLFxufSBmcm9tIFwiLi4vcmVzb3J0cy9SZXNvcnRDbGFzc1wiO1xuXG4vKipcbiAqIFByb3BlcnRpZXMgZm9yIHRoZSBTZWFyY2ggY29tcG9uZW50LlxuICovXG5pbnRlcmZhY2UgU2VhcmNoUHJvcHMge1xuXHRyZXNvcnRMaXN0OiBSZXNvcnRbXTtcblx0c2V0UmVzb3J0TGlzdDogRGlzcGF0Y2g8U2V0U3RhdGVBY3Rpb248UmVzb3J0W10+Pjtcblx0bW9ja01vZGU6IGJvb2xlYW47XG59XG5cbi8qKlxuICogUHJvdmlkZXMgYW4gaW50ZXJmYWNlIGZvciBzZWFyY2hpbmcgcmVzb3J0cyBieSBuYW1lLiBJbmNsdWRlcyBhIHRleHQgaW5wdXQgZm9yXG4gKiBlbnRlcmluZyBzZWFyY2ggY29tbWFuZHMsIGEgc2VhcmNoIGJ1dHRvbiwgYW5kIGEgZHJvcGRvd24gbWVudSB0aGF0IGxpc3RzIHJlc29ydHMuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBTZWFyY2gocHJvcHM6IFNlYXJjaFByb3BzKSB7XG5cdC8vIFN0YXRlIHRoYXQgbWFuYWdlcyB3aGV0aGVyIHRoZSBzZWUgcmVzb3J0cyBkcm9wZG93biBpcyBzaG93blxuXHRjb25zdCBbc2hvd0Ryb3BEb3duLCBzZXRTaG93RHJvcERvd25dID0gdXNlU3RhdGU8Ym9vbGVhbj4oZmFsc2UpO1xuXG5cdC8vIFN0YXRlIHRoYXQgbWFuYWdlcyB0aGUgc2VhcmNoIGJveC5cblx0Y29uc3QgW3NlbGVjdFJlc29ydCwgc2V0U2VsZWN0UmVzb3J0XSA9IHVzZVN0YXRlPHN0cmluZz4oXCJcIik7XG5cblx0Ly8gU3RhdGUgdGhlIG1hbmFnZXMgdGhlIGNvbW1hbmQgc3RyaW5nXG5cdGNvbnN0IFtjb21tYW5kU3RyaW5nLCBzZXRDb21tYW5kU3RyaW5nXSA9IHVzZVN0YXRlPHN0cmluZz4oXCJcIik7XG5cblx0dmFyIHJlc29ydHM6IHN0cmluZ1tdID0gcHJvcHMubW9ja01vZGUgPyBtb2NrUmVzb3J0TmFtZXMoKSA6IHJlc29ydE5hbWVzKCk7XG5cblx0LyoqXG5cdCAqIFRvZ2dsZXMgdGhlIHZpc2liaWxpdHkgb2YgdGhlIGRyb3Bkb3duIG1lbnUuXG5cdCAqL1xuXHRjb25zdCB0b2dnbGVEcm9wRG93biA9ICgpID0+IHtcblx0XHRzZXRTaG93RHJvcERvd24oIXNob3dEcm9wRG93bik7XG5cdH07XG5cblx0LyoqXG5cdCAqIEhhbmRsZXMgY2xvc2luZyB0aGUgZHJvcGRvd24gbWVudSBpZiBhbiBvdXRzaWRlIGNsaWNrIGlzIGRldGVjdGVkLlxuXHQgKi9cblx0Y29uc3QgZGlzbWlzc0hhbmRsZXIgPSAoZXZlbnQ6IFJlYWN0LkZvY3VzRXZlbnQ8SFRNTEJ1dHRvbkVsZW1lbnQ+KTogdm9pZCA9PiB7XG5cdFx0aWYgKGV2ZW50LmN1cnJlbnRUYXJnZXQgPT09IGV2ZW50LnRhcmdldCkge1xuXHRcdFx0c2V0U2hvd0Ryb3BEb3duKGZhbHNlKTtcblx0XHR9XG5cdH07XG5cblx0LyoqXG5cdCAqIFNldHMgdGhlIGN1cnJlbnRseSBzZWxlY3RlZCByZXNvcnQgZnJvbSB0aGUgZHJvcGRvd24uXG5cdCAqIEBwYXJhbSB7c3RyaW5nfSByZXNvcnRPcHRpb24gLSBUaGUgcmVzb3J0IG9wdGlvbiB0aGF0IHdhcyBzZWxlY3RlZC5cblx0ICovXG5cdGNvbnN0IHJlc29ydE9wdGlvbnNTZWxlY3Rpb24gPSAocmVzb3J0T3B0aW9uOiBzdHJpbmcpOiB2b2lkID0+IHtcblx0XHRzZXRTZWxlY3RSZXNvcnQocmVzb3J0T3B0aW9uKTtcblx0fTtcblxuXHQvKipcblx0ICogSGFuZGxlcyBhIHNlYXJjaCBidXR0b24gY2xpY2sgYnkgdXBkYXRpbmcgdGhlIHJlc29ydCBsaXN0IGFjY29yZGluZ2x5LlxuXHQgKiBAcGFyYW0ge3N0cmluZ30gY29tbWFuZFN0cmluZyAtIFRoZSByZXNvcnQgdG8gc2VhcmNoIGZvci5cblx0ICovXG5cdGZ1bmN0aW9uIGhhbmRsZVNlYXJjaChjb21tYW5kU3RyaW5nOiBzdHJpbmcpIHtcblx0XHRpZiAoY29tbWFuZFN0cmluZyAhPT0gXCJcIikge1xuXHRcdFx0Y29uc3QgcmVzdWx0ID0gcHJvcHMubW9ja01vZGUgPyBnZXRNb2NrU2VhcmNoUmVzb3J0KGNvbW1hbmRTdHJpbmcpIDogZ2V0U2VhcmNoUmVzb3J0KGNvbW1hbmRTdHJpbmcpO1xuXHRcdFx0cHJvcHMuc2V0UmVzb3J0TGlzdChyZXN1bHQpO1xuXHRcdH1cblx0XHRzZXRDb21tYW5kU3RyaW5nKFwiXCIpO1xuXHR9XG5cblx0cmV0dXJuIChcblx0XHQ8ZGl2IGNsYXNzTmFtZT1cInNlYXJjaC1jb250YWluZXJcIiBhcmlhLWxhYmVsPVwiUmVzb3J0IHNlYXJjaCBzZWN0aW9uXCI+XG5cdFx0XHQ8aDMgY2xhc3NOYW1lPVwic2VhcmNoLXRpdGxlXCI+U2VhcmNoIGZvciBhIHNwZWNpZmljIHJlc29ydDo8L2gzPlxuXHRcdFx0PENvbnRyb2xsZWRJbnB1dFxuXHRcdFx0XHR2YWx1ZT17Y29tbWFuZFN0cmluZ31cblx0XHRcdFx0c2V0VmFsdWU9e3NldENvbW1hbmRTdHJpbmd9XG5cdFx0XHRcdG9uS2V5RG93bj17KGV2ZW50KSA9PiB7XG5cdFx0XHRcdFx0aWYgKGV2ZW50LmtleSA9PT0gXCJFbnRlclwiKSB7XG5cdFx0XHRcdFx0XHRldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xuXHRcdFx0XHRcdFx0aGFuZGxlU2VhcmNoKGNvbW1hbmRTdHJpbmcpO1xuXHRcdFx0XHRcdH1cblx0XHRcdFx0fX1cblx0XHRcdC8+XG5cdFx0XHQ8YnV0dG9uXG5cdFx0XHRcdGNsYXNzTmFtZT1cInNlYXJjaC1idXR0b25cIlxuXHRcdFx0XHRpZD1cInNlYXJjaEJ1dHRvblwiXG5cdFx0XHRcdG9uQ2xpY2s9eygpID0+IGhhbmRsZVNlYXJjaChjb21tYW5kU3RyaW5nKX1cblx0XHRcdFx0YXJpYS1sYWJlbD1cIlNlYXJjaCBmb3IgYSByZXNvcnRcIlxuXHRcdFx0PlxuXHRcdFx0XHRTZWFyY2hcblx0XHRcdDwvYnV0dG9uPlxuXHRcdFx0PGJ1dHRvblxuXHRcdFx0XHRpZD1cInNlYXJjaERyb3Bkb3duXCJcblx0XHRcdFx0Y2xhc3NOYW1lPXtgc2VhcmNoLWRyb3Bkb3duICR7c2hvd0Ryb3BEb3duID8gXCJhY3RpdmVcIiA6IFwiXCJ9YH1cblx0XHRcdFx0b25DbGljaz17dG9nZ2xlRHJvcERvd259XG5cdFx0XHRcdG9uQmx1cj17ZGlzbWlzc0hhbmRsZXJ9XG5cdFx0XHRcdGFyaWEtbGFiZWw9XCJTaG93IG9yIGhpZGUgcmVzb3J0IGxpc3QgZHJvcGRvd25cIlxuXHRcdFx0PlxuXHRcdFx0XHR7c2VsZWN0UmVzb3J0ID8gXCJTZWUgcmVzb3J0cyAuLi5cIiA6IFwiIFNlZSBmdWxsIGxpc3Qgb2YgcmVzb3J0cy4uLlwifVxuXHRcdFx0XHR7c2hvd0Ryb3BEb3duICYmIChcblx0XHRcdFx0XHQ8UmVzb3J0RHJvcGRvd25cblx0XHRcdFx0XHRcdHJlc29ydE9wdGlvbnM9e3Jlc29ydHN9XG5cdFx0XHRcdFx0XHRzaG93RHJvcERvd249e3Nob3dEcm9wRG93bn1cblx0XHRcdFx0XHRcdHRvZ2dsZURyb3BEb3duPXt0b2dnbGVEcm9wRG93bn1cblx0XHRcdFx0XHRcdHJlc29ydE9wdGlvbnNTZWxlY3Rpb249e3Jlc29ydE9wdGlvbnNTZWxlY3Rpb259XG5cdFx0XHRcdFx0XHRzZXRDb21tYW5kU3RyaW5nPXtzZXRDb21tYW5kU3RyaW5nfVxuXHRcdFx0XHRcdC8+XG5cdFx0XHRcdCl9XG5cdFx0XHQ8L2J1dHRvbj5cblx0XHQ8L2Rpdj5cblx0KTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2F1c3RpbndpbGxpYW1zL0RvY3VtZW50cy9TY2hvb2wvdGhpcmRTZW1lc3Rlci9DUzMyL3Rlcm0tcHJvamVjdC10YnpoYW8tdHBlenphLXNtc2NodWNoLWJ3aWxsaTQ4L0Zyb250ZW5kL3NraS9zcmMvY29tcG9uZW50cy9zZWFyY2gvU2VhcmNoLnRzeCJ9