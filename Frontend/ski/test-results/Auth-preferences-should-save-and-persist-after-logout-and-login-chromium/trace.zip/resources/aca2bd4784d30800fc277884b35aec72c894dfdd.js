import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/prefs/PreferenceTicker.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=36ac7ba8"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/PreferenceTicker.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import "/src/styles/main.css";
var resetNum = 1;
export function PreferenceTicker(props) {
  function upWeight() {
    var currentPref = props.preferenceMap.get(props.preference);
    if (currentPref === void 0) {
      throw console.error();
    }
    if (currentPref.weight < 10) {
      const newMap = new Map(props.preferenceMap);
      newMap.get(props.preference)?.upWeight();
      props.setPreferenceMap(newMap);
    }
    props.setReset(resetNum);
    resetNum += 1;
  }
  function downWeight() {
    var currentPref = props.preferenceMap.get(props.preference);
    if (currentPref === void 0) {
      throw console.error();
    }
    if (currentPref.weight > 0) {
      const newMap = new Map(props.preferenceMap);
      newMap.get(props.preference)?.downWeight();
      props.setPreferenceMap(newMap);
    }
    props.setReset(resetNum);
    resetNum += 1;
  }
  function upValue() {
    var currentPref = props.preferenceMap.get(props.preference);
    if (currentPref === void 0) {
      throw console.error();
    }
    if (currentPref.value < 10) {
      const newMap = new Map(props.preferenceMap);
      newMap.get(props.preference)?.upValue();
      props.setPreferenceMap(newMap);
    }
    props.setReset(resetNum);
    resetNum += 1;
  }
  function downValue() {
    var currentPref = props.preferenceMap.get(props.preference);
    if (currentPref === void 0) {
      throw console.error();
    }
    if (currentPref.value > 0) {
      const newMap = new Map(props.preferenceMap);
      newMap.get(props.preference)?.downValue();
      props.setPreferenceMap(newMap);
    }
    props.setReset(resetNum);
    resetNum += 1;
  }
  return /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV("table", { children: /* @__PURE__ */ jsxDEV("tr", { children: [
    /* @__PURE__ */ jsxDEV("td", { children: /* @__PURE__ */ jsxDEV("p", { children: [
      "Weight: ",
      props.preferenceMap.get(props.preference)?.weight
    ] }, void 0, true, {
      fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/PreferenceTicker.tsx",
      lineNumber: 82,
      columnNumber: 7
    }, this) }, void 0, false, {
      fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/PreferenceTicker.tsx",
      lineNumber: 81,
      columnNumber: 6
    }, this),
    /* @__PURE__ */ jsxDEV("td", { children: /* @__PURE__ */ jsxDEV("table", { children: [
      /* @__PURE__ */ jsxDEV("tr", { children: /* @__PURE__ */ jsxDEV("td", { children: /* @__PURE__ */ jsxDEV("button", { id: "upButton", onClick: () => upWeight(), "aria-label": `Increase weight for ${props.preference}`, children: "^" }, void 0, false, {
        fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/PreferenceTicker.tsx",
        lineNumber: 88,
        columnNumber: 10
      }, this) }, void 0, false, {
        fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/PreferenceTicker.tsx",
        lineNumber: 87,
        columnNumber: 9
      }, this) }, void 0, false, {
        fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/PreferenceTicker.tsx",
        lineNumber: 86,
        columnNumber: 8
      }, this),
      /* @__PURE__ */ jsxDEV("tr", { children: /* @__PURE__ */ jsxDEV("td", { children: /* @__PURE__ */ jsxDEV("button", { id: "downButton", onClick: () => downWeight(), "aria-label": `Decrease weight for ${props.preference}`, children: "v" }, void 0, false, {
        fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/PreferenceTicker.tsx",
        lineNumber: 95,
        columnNumber: 10
      }, this) }, void 0, false, {
        fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/PreferenceTicker.tsx",
        lineNumber: 94,
        columnNumber: 9
      }, this) }, void 0, false, {
        fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/PreferenceTicker.tsx",
        lineNumber: 93,
        columnNumber: 8
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/PreferenceTicker.tsx",
      lineNumber: 85,
      columnNumber: 7
    }, this) }, void 0, false, {
      fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/PreferenceTicker.tsx",
      lineNumber: 84,
      columnNumber: 6
    }, this),
    /* @__PURE__ */ jsxDEV("td", { children: /* @__PURE__ */ jsxDEV("p", { children: [
      "Value: ",
      props.preferenceMap.get(props.preference)?.value
    ] }, void 0, true, {
      fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/PreferenceTicker.tsx",
      lineNumber: 103,
      columnNumber: 7
    }, this) }, void 0, false, {
      fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/PreferenceTicker.tsx",
      lineNumber: 102,
      columnNumber: 6
    }, this),
    /* @__PURE__ */ jsxDEV("td", { children: /* @__PURE__ */ jsxDEV("table", { children: [
      /* @__PURE__ */ jsxDEV("tr", { children: /* @__PURE__ */ jsxDEV("td", { children: /* @__PURE__ */ jsxDEV("button", { id: "upButton", onClick: () => upValue(), "aria-label": `Increase value for ${props.preference}`, children: "^" }, void 0, false, {
        fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/PreferenceTicker.tsx",
        lineNumber: 109,
        columnNumber: 10
      }, this) }, void 0, false, {
        fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/PreferenceTicker.tsx",
        lineNumber: 108,
        columnNumber: 9
      }, this) }, void 0, false, {
        fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/PreferenceTicker.tsx",
        lineNumber: 107,
        columnNumber: 8
      }, this),
      /* @__PURE__ */ jsxDEV("tr", { children: /* @__PURE__ */ jsxDEV("td", { children: /* @__PURE__ */ jsxDEV("button", { id: "downButton", onClick: () => downValue(), "aria-label": `Decrease value for ${props.preference}`, children: "v" }, void 0, false, {
        fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/PreferenceTicker.tsx",
        lineNumber: 116,
        columnNumber: 10
      }, this) }, void 0, false, {
        fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/PreferenceTicker.tsx",
        lineNumber: 115,
        columnNumber: 9
      }, this) }, void 0, false, {
        fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/PreferenceTicker.tsx",
        lineNumber: 114,
        columnNumber: 8
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/PreferenceTicker.tsx",
      lineNumber: 106,
      columnNumber: 7
    }, this) }, void 0, false, {
      fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/PreferenceTicker.tsx",
      lineNumber: 105,
      columnNumber: 6
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/PreferenceTicker.tsx",
    lineNumber: 80,
    columnNumber: 5
  }, this) }, void 0, false, {
    fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/PreferenceTicker.tsx",
    lineNumber: 79,
    columnNumber: 4
  }, this) }, void 0, false, {
    fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/PreferenceTicker.tsx",
    lineNumber: 78,
    columnNumber: 10
  }, this);
}
_c = PreferenceTicker;
var _c;
$RefreshReg$(_c, "PreferenceTicker");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/PreferenceTicker.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0ZNO0FBcEZOLE9BQU87QUFBdUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBWTlCLElBQUlBLFdBQVc7QUFNUixnQkFBU0MsaUJBQWlCQyxPQUE4QjtBQUU5RCxXQUFTQyxXQUFXO0FBQ25CLFFBQUlDLGNBQWNGLE1BQU1HLGNBQWNDLElBQUlKLE1BQU1LLFVBQVU7QUFDMUQsUUFBSUgsZ0JBQWdCSSxRQUFXO0FBQzlCLFlBQU1DLFFBQVFDLE1BQU07QUFBQSxJQUNyQjtBQUNBLFFBQUlOLFlBQVlPLFNBQVMsSUFBSTtBQUM1QixZQUFNQyxTQUFTLElBQUlDLElBQUlYLE1BQU1HLGFBQWE7QUFDMUNPLGFBQU9OLElBQUlKLE1BQU1LLFVBQVUsR0FBR0osU0FBUztBQUN2Q0QsWUFBTVksaUJBQWlCRixNQUFNO0FBQUEsSUFDOUI7QUFDQVYsVUFBTWEsU0FBU2YsUUFBUTtBQUN2QkEsZ0JBQVk7QUFBQSxFQUNiO0FBR0EsV0FBU2dCLGFBQWE7QUFDckIsUUFBSVosY0FBY0YsTUFBTUcsY0FBY0MsSUFBSUosTUFBTUssVUFBVTtBQUMxRCxRQUFJSCxnQkFBZ0JJLFFBQVc7QUFDOUIsWUFBTUMsUUFBUUMsTUFBTTtBQUFBLElBQ3JCO0FBQ0EsUUFBSU4sWUFBWU8sU0FBUyxHQUFHO0FBQzNCLFlBQU1DLFNBQVMsSUFBSUMsSUFBSVgsTUFBTUcsYUFBYTtBQUMxQ08sYUFBT04sSUFBSUosTUFBTUssVUFBVSxHQUFHUyxXQUFXO0FBQ3pDZCxZQUFNWSxpQkFBaUJGLE1BQU07QUFBQSxJQUM5QjtBQUNBVixVQUFNYSxTQUFTZixRQUFRO0FBQ3ZCQSxnQkFBWTtBQUFBLEVBQ2I7QUFHQSxXQUFTaUIsVUFBVTtBQUNsQixRQUFJYixjQUFjRixNQUFNRyxjQUFjQyxJQUFJSixNQUFNSyxVQUFVO0FBQzFELFFBQUlILGdCQUFnQkksUUFBVztBQUM5QixZQUFNQyxRQUFRQyxNQUFNO0FBQUEsSUFDckI7QUFDQSxRQUFJTixZQUFZYyxRQUFRLElBQUk7QUFDM0IsWUFBTU4sU0FBUyxJQUFJQyxJQUFJWCxNQUFNRyxhQUFhO0FBQzFDTyxhQUFPTixJQUFJSixNQUFNSyxVQUFVLEdBQUdVLFFBQVE7QUFDdENmLFlBQU1ZLGlCQUFpQkYsTUFBTTtBQUFBLElBQzlCO0FBQ0FWLFVBQU1hLFNBQVNmLFFBQVE7QUFDdkJBLGdCQUFZO0FBQUEsRUFDYjtBQUdBLFdBQVNtQixZQUFZO0FBQ3BCLFFBQUlmLGNBQWNGLE1BQU1HLGNBQWNDLElBQUlKLE1BQU1LLFVBQVU7QUFDMUQsUUFBSUgsZ0JBQWdCSSxRQUFXO0FBQzlCLFlBQU1DLFFBQVFDLE1BQU07QUFBQSxJQUNyQjtBQUNBLFFBQUlOLFlBQVljLFFBQVEsR0FBRztBQUMxQixZQUFNTixTQUFTLElBQUlDLElBQUlYLE1BQU1HLGFBQWE7QUFDMUNPLGFBQU9OLElBQUlKLE1BQU1LLFVBQVUsR0FBR1ksVUFBVTtBQUN4Q2pCLFlBQU1ZLGlCQUFpQkYsTUFBTTtBQUFBLElBQzlCO0FBQ0FWLFVBQU1hLFNBQVNmLFFBQVE7QUFDdkJBLGdCQUFZO0FBQUEsRUFDYjtBQUVBLFNBQ0MsdUJBQUMsU0FDQSxpQ0FBQyxXQUNBLGlDQUFDLFFBQ0E7QUFBQSwyQkFBQyxRQUNBLGlDQUFDLE9BQUU7QUFBQTtBQUFBLE1BQVNFLE1BQU1HLGNBQWNDLElBQUlKLE1BQU1LLFVBQVUsR0FBR0k7QUFBQUEsU0FBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE4RCxLQUQvRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUNBLHVCQUFDLFFBQ0EsaUNBQUMsV0FDQTtBQUFBLDZCQUFDLFFBQ0EsaUNBQUMsUUFDQSxpQ0FBQyxZQUNBLElBQUcsWUFDSCxTQUFTLE1BQU1SLFNBQVMsR0FDeEIsY0FBYSx1QkFBc0JELE1BQU1LLFVBQVcsSUFBRSxpQkFIdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU1BLEtBUEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVFBLEtBVEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVVBO0FBQUEsTUFDQSx1QkFBQyxRQUNBLGlDQUFDLFFBQ0EsaUNBQUMsWUFDQSxJQUFHLGNBQ0gsU0FBUyxNQUFNUyxXQUFXLEdBQzFCLGNBQWEsdUJBQXNCZCxNQUFNSyxVQUFXLElBQUUsaUJBSHZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFNQSxLQVBEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFRQSxLQVREO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFVQTtBQUFBLFNBdEJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F1QkEsS0F4QkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXlCQTtBQUFBLElBQ0EsdUJBQUMsUUFDQSxpQ0FBQyxPQUFFO0FBQUE7QUFBQSxNQUFRTCxNQUFNRyxjQUFjQyxJQUFJSixNQUFNSyxVQUFVLEdBQUdXO0FBQUFBLFNBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNEQsS0FEN0Q7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsSUFDQSx1QkFBQyxRQUNBLGlDQUFDLFdBQ0E7QUFBQSw2QkFBQyxRQUNBLGlDQUFDLFFBQ0EsaUNBQUMsWUFBTyxJQUFHLFlBQVcsU0FBUyxNQUFNRCxRQUFRLEdBQUcsY0FBYSxzQkFBcUJmLE1BQU1LLFVBQVcsSUFBRSxpQkFBckc7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUVBLEtBSEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUlBLEtBTEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU1BO0FBQUEsTUFDQSx1QkFBQyxRQUNBLGlDQUFDLFFBQ0EsaUNBQUMsWUFDQSxJQUFHLGNBQ0gsU0FBUyxNQUFNWSxVQUFVLEdBQ3pCLGNBQWEsc0JBQXFCakIsTUFBTUssVUFBVyxJQUFFLGlCQUh0RDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBTUEsS0FQRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBUUEsS0FURDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBVUE7QUFBQSxTQWxCRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBbUJBLEtBcEJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FxQkE7QUFBQSxPQXRERDtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBdURBLEtBeEREO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0F5REEsS0ExREQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTJEQTtBQUVGO0FBQUNhLEtBM0hlbkI7QUFBZ0IsSUFBQW1CO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJyZXNldE51bSIsIlByZWZlcmVuY2VUaWNrZXIiLCJwcm9wcyIsInVwV2VpZ2h0IiwiY3VycmVudFByZWYiLCJwcmVmZXJlbmNlTWFwIiwiZ2V0IiwicHJlZmVyZW5jZSIsInVuZGVmaW5lZCIsImNvbnNvbGUiLCJlcnJvciIsIndlaWdodCIsIm5ld01hcCIsIk1hcCIsInNldFByZWZlcmVuY2VNYXAiLCJzZXRSZXNldCIsImRvd25XZWlnaHQiLCJ1cFZhbHVlIiwidmFsdWUiLCJkb3duVmFsdWUiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlByZWZlcmVuY2VUaWNrZXIudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBcIi4uLy4uL3N0eWxlcy9tYWluLmNzc1wiO1xuaW1wb3J0IHsgRGlzcGF0Y2gsIFNldFN0YXRlQWN0aW9uLCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgUHJlZmVyZW5jZUFuZFZhbHVlIH0gZnJvbSBcIi4vUHJlZmVyZW5jZXNcIjtcblxuLy8gUHJvcGVydGllcyBmb3IgdGhlIFByZWZlcmVuY2VUaWNrZXIgY29tcG9uZW50LlxuaW50ZXJmYWNlIFByZWZlcmVuY2VUaWNrZXJQcm9wcyB7XG5cdHByZWZlcmVuY2VNYXA6IE1hcDxzdHJpbmcsIFByZWZlcmVuY2VBbmRWYWx1ZT47XG5cdHNldFByZWZlcmVuY2VNYXA6IERpc3BhdGNoPFNldFN0YXRlQWN0aW9uPE1hcDxzdHJpbmcsIFByZWZlcmVuY2VBbmRWYWx1ZT4+Pjtcblx0c2V0UmVzZXQ6IERpc3BhdGNoPG51bWJlcj47XG5cdHByZWZlcmVuY2U6IHN0cmluZztcbn1cblxudmFyIHJlc2V0TnVtID0gMTtcblxuLyoqXG4gKiBBbGxvd3MgdXNlcnMgdG8gaW5jcmVhc2Ugb3IgZGVjcmVhc2UgdGhlIHdlaWdodCBhbmQgdmFsdWUgb2YgYSBwYXJ0aWN1bGFyIHByZWZlcmVuY2UuXG4gKiBSZW5kZXJzIGEgc2V0IG9mIGNvbnRyb2xzIGZvciBhZGp1c3RpbmcgdGhlc2UgYXR0cmlidXRlcyBhc3NvY2lhdGVkIHdpdGggYSB1c2VyJ3MgcHJlZmVyZW5jZS5cbiAqL1xuZXhwb3J0IGZ1bmN0aW9uIFByZWZlcmVuY2VUaWNrZXIocHJvcHM6IFByZWZlcmVuY2VUaWNrZXJQcm9wcykge1xuXHQvLyBNYW5hZ2VzIHRoZSB1cCBhcnJvdy4gSW5jcmVhc2VzIHRoZSBjb3VudCBieSAxIGlmIGl0IGlzbid0IGF0IHRoZSBtYXggdmFsdWUgYWxyZWFkeS5cblx0ZnVuY3Rpb24gdXBXZWlnaHQoKSB7XG5cdFx0dmFyIGN1cnJlbnRQcmVmID0gcHJvcHMucHJlZmVyZW5jZU1hcC5nZXQocHJvcHMucHJlZmVyZW5jZSk7XG5cdFx0aWYgKGN1cnJlbnRQcmVmID09PSB1bmRlZmluZWQpIHtcblx0XHRcdHRocm93IGNvbnNvbGUuZXJyb3IoKTtcblx0XHR9XG5cdFx0aWYgKGN1cnJlbnRQcmVmLndlaWdodCA8IDEwKSB7XG5cdFx0XHRjb25zdCBuZXdNYXAgPSBuZXcgTWFwKHByb3BzLnByZWZlcmVuY2VNYXApO1xuXHRcdFx0bmV3TWFwLmdldChwcm9wcy5wcmVmZXJlbmNlKT8udXBXZWlnaHQoKTtcblx0XHRcdHByb3BzLnNldFByZWZlcmVuY2VNYXAobmV3TWFwKTtcblx0XHR9XG5cdFx0cHJvcHMuc2V0UmVzZXQocmVzZXROdW0pO1xuXHRcdHJlc2V0TnVtICs9IDE7XG5cdH1cblxuXHQvLyBNYW5hZ2VzIHRoZSBkb3duIGFycm93LiBEZWNyZWFzZXMgdGhlIGNvdW50IGJ5IDEgaWYgaXQgaXNuJ3QgYXQgdGhlIG1heC5cblx0ZnVuY3Rpb24gZG93bldlaWdodCgpIHtcblx0XHR2YXIgY3VycmVudFByZWYgPSBwcm9wcy5wcmVmZXJlbmNlTWFwLmdldChwcm9wcy5wcmVmZXJlbmNlKTtcblx0XHRpZiAoY3VycmVudFByZWYgPT09IHVuZGVmaW5lZCkge1xuXHRcdFx0dGhyb3cgY29uc29sZS5lcnJvcigpO1xuXHRcdH1cblx0XHRpZiAoY3VycmVudFByZWYud2VpZ2h0ID4gMCkge1xuXHRcdFx0Y29uc3QgbmV3TWFwID0gbmV3IE1hcChwcm9wcy5wcmVmZXJlbmNlTWFwKTtcblx0XHRcdG5ld01hcC5nZXQocHJvcHMucHJlZmVyZW5jZSk/LmRvd25XZWlnaHQoKTtcblx0XHRcdHByb3BzLnNldFByZWZlcmVuY2VNYXAobmV3TWFwKTtcblx0XHR9XG5cdFx0cHJvcHMuc2V0UmVzZXQocmVzZXROdW0pO1xuXHRcdHJlc2V0TnVtICs9IDE7XG5cdH1cblxuXHQvLyBNYW5hZ2VzIHRoZSB1cCBhcnJvdy4gSW5jcmVhc2VzIHRoZSBjb3VudCBieSAxIGlmIGl0IGlzbid0IGF0IHRoZSBtYXhcblx0ZnVuY3Rpb24gdXBWYWx1ZSgpIHtcblx0XHR2YXIgY3VycmVudFByZWYgPSBwcm9wcy5wcmVmZXJlbmNlTWFwLmdldChwcm9wcy5wcmVmZXJlbmNlKTtcblx0XHRpZiAoY3VycmVudFByZWYgPT09IHVuZGVmaW5lZCkge1xuXHRcdFx0dGhyb3cgY29uc29sZS5lcnJvcigpO1xuXHRcdH1cblx0XHRpZiAoY3VycmVudFByZWYudmFsdWUgPCAxMCkge1xuXHRcdFx0Y29uc3QgbmV3TWFwID0gbmV3IE1hcChwcm9wcy5wcmVmZXJlbmNlTWFwKTtcblx0XHRcdG5ld01hcC5nZXQocHJvcHMucHJlZmVyZW5jZSk/LnVwVmFsdWUoKTtcblx0XHRcdHByb3BzLnNldFByZWZlcmVuY2VNYXAobmV3TWFwKTtcblx0XHR9XG5cdFx0cHJvcHMuc2V0UmVzZXQocmVzZXROdW0pO1xuXHRcdHJlc2V0TnVtICs9IDE7XG5cdH1cblxuXHQvLyBNYW5hZ2VzIHRoZSBkb3duIGFycm93LiBEZWNyZWFzZXMgdGhlIGNvdW50IGJ5IDEgaWYgaXQgaXNuJ3QgYXQgdGhlIG1heFxuXHRmdW5jdGlvbiBkb3duVmFsdWUoKSB7XG5cdFx0dmFyIGN1cnJlbnRQcmVmID0gcHJvcHMucHJlZmVyZW5jZU1hcC5nZXQocHJvcHMucHJlZmVyZW5jZSk7XG5cdFx0aWYgKGN1cnJlbnRQcmVmID09PSB1bmRlZmluZWQpIHtcblx0XHRcdHRocm93IGNvbnNvbGUuZXJyb3IoKTtcblx0XHR9XG5cdFx0aWYgKGN1cnJlbnRQcmVmLnZhbHVlID4gMCkge1xuXHRcdFx0Y29uc3QgbmV3TWFwID0gbmV3IE1hcChwcm9wcy5wcmVmZXJlbmNlTWFwKTtcblx0XHRcdG5ld01hcC5nZXQocHJvcHMucHJlZmVyZW5jZSk/LmRvd25WYWx1ZSgpO1xuXHRcdFx0cHJvcHMuc2V0UHJlZmVyZW5jZU1hcChuZXdNYXApO1xuXHRcdH1cblx0XHRwcm9wcy5zZXRSZXNldChyZXNldE51bSk7XG5cdFx0cmVzZXROdW0gKz0gMTtcblx0fVxuXG5cdHJldHVybiAoXG5cdFx0PGRpdj5cblx0XHRcdDx0YWJsZT5cblx0XHRcdFx0PHRyPlxuXHRcdFx0XHRcdDx0ZD5cblx0XHRcdFx0XHRcdDxwPldlaWdodDoge3Byb3BzLnByZWZlcmVuY2VNYXAuZ2V0KHByb3BzLnByZWZlcmVuY2UpPy53ZWlnaHR9PC9wPlxuXHRcdFx0XHRcdDwvdGQ+XG5cdFx0XHRcdFx0PHRkPlxuXHRcdFx0XHRcdFx0PHRhYmxlPlxuXHRcdFx0XHRcdFx0XHQ8dHI+XG5cdFx0XHRcdFx0XHRcdFx0PHRkPlxuXHRcdFx0XHRcdFx0XHRcdFx0PGJ1dHRvblxuXHRcdFx0XHRcdFx0XHRcdFx0XHRpZD1cInVwQnV0dG9uXCJcblx0XHRcdFx0XHRcdFx0XHRcdFx0b25DbGljaz17KCkgPT4gdXBXZWlnaHQoKX1cblx0XHRcdFx0XHRcdFx0XHRcdFx0YXJpYS1sYWJlbD17YEluY3JlYXNlIHdlaWdodCBmb3IgJHtwcm9wcy5wcmVmZXJlbmNlfWB9XG5cdFx0XHRcdFx0XHRcdFx0XHQ+XG5cdFx0XHRcdFx0XHRcdFx0XHRcdF5cblx0XHRcdFx0XHRcdFx0XHRcdDwvYnV0dG9uPlxuXHRcdFx0XHRcdFx0XHRcdDwvdGQ+XG5cdFx0XHRcdFx0XHRcdDwvdHI+XG5cdFx0XHRcdFx0XHRcdDx0cj5cblx0XHRcdFx0XHRcdFx0XHQ8dGQ+XG5cdFx0XHRcdFx0XHRcdFx0XHQ8YnV0dG9uXG5cdFx0XHRcdFx0XHRcdFx0XHRcdGlkPVwiZG93bkJ1dHRvblwiXG5cdFx0XHRcdFx0XHRcdFx0XHRcdG9uQ2xpY2s9eygpID0+IGRvd25XZWlnaHQoKX1cblx0XHRcdFx0XHRcdFx0XHRcdFx0YXJpYS1sYWJlbD17YERlY3JlYXNlIHdlaWdodCBmb3IgJHtwcm9wcy5wcmVmZXJlbmNlfWB9XG5cdFx0XHRcdFx0XHRcdFx0XHQ+XG5cdFx0XHRcdFx0XHRcdFx0XHRcdHZcblx0XHRcdFx0XHRcdFx0XHRcdDwvYnV0dG9uPlxuXHRcdFx0XHRcdFx0XHRcdDwvdGQ+XG5cdFx0XHRcdFx0XHRcdDwvdHI+XG5cdFx0XHRcdFx0XHQ8L3RhYmxlPlxuXHRcdFx0XHRcdDwvdGQ+XG5cdFx0XHRcdFx0PHRkPlxuXHRcdFx0XHRcdFx0PHA+VmFsdWU6IHtwcm9wcy5wcmVmZXJlbmNlTWFwLmdldChwcm9wcy5wcmVmZXJlbmNlKT8udmFsdWV9PC9wPlxuXHRcdFx0XHRcdDwvdGQ+XG5cdFx0XHRcdFx0PHRkPlxuXHRcdFx0XHRcdFx0PHRhYmxlPlxuXHRcdFx0XHRcdFx0XHQ8dHI+XG5cdFx0XHRcdFx0XHRcdFx0PHRkPlxuXHRcdFx0XHRcdFx0XHRcdFx0PGJ1dHRvbiBpZD1cInVwQnV0dG9uXCIgb25DbGljaz17KCkgPT4gdXBWYWx1ZSgpfSBhcmlhLWxhYmVsPXtgSW5jcmVhc2UgdmFsdWUgZm9yICR7cHJvcHMucHJlZmVyZW5jZX1gfT5cblx0XHRcdFx0XHRcdFx0XHRcdFx0XlxuXHRcdFx0XHRcdFx0XHRcdFx0PC9idXR0b24+XG5cdFx0XHRcdFx0XHRcdFx0PC90ZD5cblx0XHRcdFx0XHRcdFx0PC90cj5cblx0XHRcdFx0XHRcdFx0PHRyPlxuXHRcdFx0XHRcdFx0XHRcdDx0ZD5cblx0XHRcdFx0XHRcdFx0XHRcdDxidXR0b25cblx0XHRcdFx0XHRcdFx0XHRcdFx0aWQ9XCJkb3duQnV0dG9uXCJcblx0XHRcdFx0XHRcdFx0XHRcdFx0b25DbGljaz17KCkgPT4gZG93blZhbHVlKCl9XG5cdFx0XHRcdFx0XHRcdFx0XHRcdGFyaWEtbGFiZWw9e2BEZWNyZWFzZSB2YWx1ZSBmb3IgJHtwcm9wcy5wcmVmZXJlbmNlfWB9XG5cdFx0XHRcdFx0XHRcdFx0XHQ+XG5cdFx0XHRcdFx0XHRcdFx0XHRcdHZcblx0XHRcdFx0XHRcdFx0XHRcdDwvYnV0dG9uPlxuXHRcdFx0XHRcdFx0XHRcdDwvdGQ+XG5cdFx0XHRcdFx0XHRcdDwvdHI+XG5cdFx0XHRcdFx0XHQ8L3RhYmxlPlxuXHRcdFx0XHRcdDwvdGQ+XG5cdFx0XHRcdDwvdHI+XG5cdFx0XHQ8L3RhYmxlPlxuXHRcdDwvZGl2PlxuXHQpO1xufVxuIl0sImZpbGUiOiIvVXNlcnMvYXVzdGlud2lsbGlhbXMvRG9jdW1lbnRzL1NjaG9vbC90aGlyZFNlbWVzdGVyL0NTMzIvdGVybS1wcm9qZWN0LXRiemhhby10cGV6emEtc21zY2h1Y2gtYndpbGxpNDgvRnJvbnRlbmQvc2tpL3NyYy9jb21wb25lbnRzL3ByZWZzL1ByZWZlcmVuY2VUaWNrZXIudHN4In0=