import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/auth/Profile.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=36ac7ba8"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/auth/Profile.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useAuth0 } from "/node_modules/.vite/deps/@auth0_auth0-react.js?v=36ac7ba8";
import LogoutButton from "/src/components/auth/LogoutButton.tsx";
const Profile = ({
  className
}) => {
  _s();
  const {
    user,
    isAuthenticated,
    isLoading
  } = useAuth0();
  if (isLoading) {
    return /* @__PURE__ */ jsxDEV("div", { role: "alert", children: "Loading ..." }, void 0, false, {
      fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/auth/Profile.tsx",
      lineNumber: 27,
      columnNumber: 12
    }, this);
  }
  if (!isAuthenticated || !user) {
    return null;
  }
  return /* @__PURE__ */ jsxDEV("div", { className, children: [
    /* @__PURE__ */ jsxDEV("img", { src: user.picture, alt: user.name, className: "profile-pic", "aria-label": "Profile picture" }, void 0, false, {
      fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/auth/Profile.tsx",
      lineNumber: 33,
      columnNumber: 4
    }, this),
    /* @__PURE__ */ jsxDEV("h2", { children: user.name }, void 0, false, {
      fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/auth/Profile.tsx",
      lineNumber: 34,
      columnNumber: 4
    }, this),
    /* @__PURE__ */ jsxDEV("p", { children: user.email }, void 0, false, {
      fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/auth/Profile.tsx",
      lineNumber: 35,
      columnNumber: 4
    }, this),
    /* @__PURE__ */ jsxDEV(LogoutButton, { "aria-label": "Log out" }, void 0, false, {
      fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/auth/Profile.tsx",
      lineNumber: 36,
      columnNumber: 4
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/auth/Profile.tsx",
    lineNumber: 32,
    columnNumber: 10
  }, this);
};
_s(Profile, "5f6CICO7cPumV3lZMMWoV1Bl2ts=", false, function() {
  return [useAuth0];
});
_c = Profile;
export default Profile;
var _c;
$RefreshReg$(_c, "Profile");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/auth/Profile.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbUJTOzs7Ozs7Ozs7Ozs7Ozs7OztBQWxCVCxTQUFTQSxnQkFBZ0I7QUFDekIsT0FBT0Msa0JBQWtCO0FBYXpCLE1BQU1DLFVBQWtDQSxDQUFDO0FBQUEsRUFBRUM7QUFBVSxNQUFNO0FBQUFDLEtBQUE7QUFDMUQsUUFBTTtBQUFBLElBQUVDO0FBQUFBLElBQU1DO0FBQUFBLElBQWlCQztBQUFBQSxFQUFVLElBQUlQLFNBQVM7QUFFdEQsTUFBSU8sV0FBVztBQUNkLFdBQU8sdUJBQUMsU0FBSSxNQUFLLFNBQVEsMkJBQWxCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNkI7QUFBQSxFQUNyQztBQUVBLE1BQUksQ0FBQ0QsbUJBQW1CLENBQUNELE1BQU07QUFDOUIsV0FBTztBQUFBLEVBQ1I7QUFFQSxTQUNDLHVCQUFDLFNBQUksV0FDSjtBQUFBLDJCQUFDLFNBQUksS0FBS0EsS0FBS0csU0FBUyxLQUFLSCxLQUFLSSxNQUFNLFdBQVUsZUFBYyxjQUFXLHFCQUEzRTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQTRGO0FBQUEsSUFDNUYsdUJBQUMsUUFBSUosZUFBS0ksUUFBVjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQWU7QUFBQSxJQUNmLHVCQUFDLE9BQUdKLGVBQUtLLFNBQVQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFlO0FBQUEsSUFDZix1QkFBQyxnQkFBYSxjQUFXLGFBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBa0M7QUFBQSxPQUpuQztBQUFBO0FBQUE7QUFBQTtBQUFBLFNBS0E7QUFFRjtBQUFFTixHQW5CSUYsU0FBK0I7QUFBQSxVQUNTRixRQUFRO0FBQUE7QUFBQVcsS0FEaERUO0FBcUJOLGVBQWVBO0FBQVEsSUFBQVM7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZUF1dGgwIiwiTG9nb3V0QnV0dG9uIiwiUHJvZmlsZSIsImNsYXNzTmFtZSIsIl9zIiwidXNlciIsImlzQXV0aGVudGljYXRlZCIsImlzTG9hZGluZyIsInBpY3R1cmUiLCJuYW1lIiwiZW1haWwiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlByb2ZpbGUudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IHVzZUF1dGgwIH0gZnJvbSBcIkBhdXRoMC9hdXRoMC1yZWFjdFwiO1xuaW1wb3J0IExvZ291dEJ1dHRvbiBmcm9tIFwiLi9Mb2dvdXRCdXR0b25cIjtcblxuLyoqXG4gKiBQcm9wZXJ0aWVzIHRoYXQgdGhlIFByb2ZpbGUgY29tcG9uZW50IGFjY2VwdHMuXG4gKi9cbnR5cGUgUHJvZmlsZVByb3BzID0ge1xuXHRjbGFzc05hbWU6IHN0cmluZztcbn07XG5cbi8qKlxuICogRGlzcGxheXMgdGhlIGF1dGhlbnRpY2F0ZWQgdXNlcidzIHByb2ZpbGUgaW5mb3JtYXRpb24uIFNob3dzIHRoZSB1c2VyJ3MgcGljdHVyZSwgbmFtZSxcbiAqIGFuZCBlbWFpbCwgYW5kIGluY2x1ZGVzIGEgbG9nb3V0IGJ1dHRvbi5cbiAqL1xuY29uc3QgUHJvZmlsZTogUmVhY3QuRkM8UHJvZmlsZVByb3BzPiA9ICh7IGNsYXNzTmFtZSB9KSA9PiB7XG5cdGNvbnN0IHsgdXNlciwgaXNBdXRoZW50aWNhdGVkLCBpc0xvYWRpbmcgfSA9IHVzZUF1dGgwKCk7XG5cblx0aWYgKGlzTG9hZGluZykge1xuXHRcdHJldHVybiA8ZGl2IHJvbGU9XCJhbGVydFwiPkxvYWRpbmcgLi4uPC9kaXY+O1xuXHR9XG5cblx0aWYgKCFpc0F1dGhlbnRpY2F0ZWQgfHwgIXVzZXIpIHtcblx0XHRyZXR1cm4gbnVsbDtcblx0fVxuXG5cdHJldHVybiAoXG5cdFx0PGRpdiBjbGFzc05hbWU9e2NsYXNzTmFtZX0+XG5cdFx0XHQ8aW1nIHNyYz17dXNlci5waWN0dXJlfSBhbHQ9e3VzZXIubmFtZX0gY2xhc3NOYW1lPVwicHJvZmlsZS1waWNcIiBhcmlhLWxhYmVsPVwiUHJvZmlsZSBwaWN0dXJlXCIgLz5cblx0XHRcdDxoMj57dXNlci5uYW1lfTwvaDI+XG5cdFx0XHQ8cD57dXNlci5lbWFpbH08L3A+XG5cdFx0XHQ8TG9nb3V0QnV0dG9uIGFyaWEtbGFiZWw9XCJMb2cgb3V0XCIgLz5cblx0XHQ8L2Rpdj5cblx0KTtcbn07XG5cbmV4cG9ydCBkZWZhdWx0IFByb2ZpbGU7XG4iXSwiZmlsZSI6Ii9Vc2Vycy9hdXN0aW53aWxsaWFtcy9Eb2N1bWVudHMvU2Nob29sL3RoaXJkU2VtZXN0ZXIvQ1MzMi90ZXJtLXByb2plY3QtdGJ6aGFvLXRwZXp6YS1zbXNjaHVjaC1id2lsbGk0OC9Gcm9udGVuZC9za2kvc3JjL2NvbXBvbmVudHMvYXV0aC9Qcm9maWxlLnRzeCJ9