import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/resorts/SingleResort.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=36ac7ba8"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/resorts/SingleResort.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import "/src/styles/main.css";
export function SingleResort(props) {
  const lastSnowfall = props.resort.lastSnowfall === 0 ? "Last Snow: today" : `Last Snow: ${props.resort.lastSnowfall} days ago`;
  return /* @__PURE__ */ jsxDEV("div", { id: "listDiv", className: "repl-history", "aria-label": "Resort information", children: [
    /* @__PURE__ */ jsxDEV("h2", { id: "resortName", children: props.resort.name }, void 0, false, {
      fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/resorts/SingleResort.tsx",
      lineNumber: 18,
      columnNumber: 4
    }, this),
    /* @__PURE__ */ jsxDEV("table", { children: /* @__PURE__ */ jsxDEV("tr", { children: [
      /* @__PURE__ */ jsxDEV("td", { className: "resortListDatum", children: [
        /* @__PURE__ */ jsxDEV("h3", { children: "Snow Stats" }, void 0, false, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/resorts/SingleResort.tsx",
          lineNumber: 22,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV("p", { children: [
          "Snowfall: ",
          props.resort.snowfallAmount,
          " in."
        ] }, void 0, true, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/resorts/SingleResort.tsx",
          lineNumber: 23,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV("p", { children: lastSnowfall }, void 0, false, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/resorts/SingleResort.tsx",
          lineNumber: 24,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV("p", { children: [
          "Base-depth: ",
          props.resort.baseDepth,
          " in."
        ] }, void 0, true, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/resorts/SingleResort.tsx",
          lineNumber: 25,
          columnNumber: 7
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/resorts/SingleResort.tsx",
        lineNumber: 21,
        columnNumber: 6
      }, this),
      /* @__PURE__ */ jsxDEV("td", { className: "resortListDatum", children: [
        /* @__PURE__ */ jsxDEV("h3", { children: "Weather" }, void 0, false, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/resorts/SingleResort.tsx",
          lineNumber: 28,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV("p", { children: [
          "Temperature: ",
          props.resort.temperature,
          "°F"
        ] }, void 0, true, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/resorts/SingleResort.tsx",
          lineNumber: 29,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV("p", { children: [
          "Windspeed: ",
          props.resort.windspeed,
          " mph"
        ] }, void 0, true, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/resorts/SingleResort.tsx",
          lineNumber: 30,
          columnNumber: 7
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/resorts/SingleResort.tsx",
        lineNumber: 27,
        columnNumber: 6
      }, this),
      /* @__PURE__ */ jsxDEV("td", { className: "resortListDatum", children: [
        /* @__PURE__ */ jsxDEV("h3", { children: "Mountain Info" }, void 0, false, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/resorts/SingleResort.tsx",
          lineNumber: 33,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV("p", { children: [
          "Top Elevation: ",
          props.resort.summitElevation,
          "ft"
        ] }, void 0, true, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/resorts/SingleResort.tsx",
          lineNumber: 34,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV("p", { children: [
          "Lifts Open: ",
          props.resort.liftsOpen
        ] }, void 0, true, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/resorts/SingleResort.tsx",
          lineNumber: 35,
          columnNumber: 7
        }, this),
        /* @__PURE__ */ jsxDEV("p", { children: [
          "Price: $",
          props.resort.price
        ] }, void 0, true, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/resorts/SingleResort.tsx",
          lineNumber: 36,
          columnNumber: 7
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/resorts/SingleResort.tsx",
        lineNumber: 32,
        columnNumber: 6
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/resorts/SingleResort.tsx",
      lineNumber: 20,
      columnNumber: 5
    }, this) }, void 0, false, {
      fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/resorts/SingleResort.tsx",
      lineNumber: 19,
      columnNumber: 4
    }, this),
    /* @__PURE__ */ jsxDEV("hr", {}, void 0, false, {
      fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/resorts/SingleResort.tsx",
      lineNumber: 40,
      columnNumber: 4
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/resorts/SingleResort.tsx",
    lineNumber: 17,
    columnNumber: 10
  }, this);
}
_c = SingleResort;
var _c;
$RefreshReg$(_c, "SingleResort");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/resorts/SingleResort.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0JHO0FBcEJILDJCQUF1QjtBQUFlO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDdEMsT0FBTztBQWFBLGdCQUFTQSxhQUFhQyxPQUEwQjtBQUN0RCxRQUFNQyxlQUNMRCxNQUFNRSxPQUFPRCxpQkFBaUIsSUFBSSxxQkFBc0IsY0FBYUQsTUFBTUUsT0FBT0QsWUFBYTtBQUVoRyxTQUNDLHVCQUFDLFNBQUksSUFBRyxXQUFVLFdBQVUsZ0JBQWUsY0FBVyxzQkFDckQ7QUFBQSwyQkFBQyxRQUFHLElBQUcsY0FBY0QsZ0JBQU1FLE9BQU9DLFFBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBdUM7QUFBQSxJQUN2Qyx1QkFBQyxXQUNBLGlDQUFDLFFBQ0E7QUFBQSw2QkFBQyxRQUFHLFdBQVUsbUJBQ2I7QUFBQSwrQkFBQyxRQUFHLDBCQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBYztBQUFBLFFBQ2QsdUJBQUMsT0FBRTtBQUFBO0FBQUEsVUFBV0gsTUFBTUUsT0FBT0U7QUFBQUEsVUFBZTtBQUFBLGFBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBOEM7QUFBQSxRQUM5Qyx1QkFBQyxPQUFHSCwwQkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWlCO0FBQUEsUUFDakIsdUJBQUMsT0FBRTtBQUFBO0FBQUEsVUFBYUQsTUFBTUUsT0FBT0c7QUFBQUEsVUFBVTtBQUFBLGFBQXZDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBMkM7QUFBQSxXQUo1QztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0E7QUFBQSxNQUNBLHVCQUFDLFFBQUcsV0FBVSxtQkFDYjtBQUFBLCtCQUFDLFFBQUcsdUJBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFXO0FBQUEsUUFDWCx1QkFBQyxPQUFFO0FBQUE7QUFBQSxVQUFjTCxNQUFNRSxPQUFPSTtBQUFBQSxVQUFZO0FBQUEsYUFBMUM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUE0QztBQUFBLFFBQzVDLHVCQUFDLE9BQUU7QUFBQTtBQUFBLFVBQVlOLE1BQU1FLE9BQU9LO0FBQUFBLFVBQVU7QUFBQSxhQUF0QztBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTBDO0FBQUEsV0FIM0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUlBO0FBQUEsTUFDQSx1QkFBQyxRQUFHLFdBQVUsbUJBQ2I7QUFBQSwrQkFBQyxRQUFHLDZCQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBaUI7QUFBQSxRQUNqQix1QkFBQyxPQUFFO0FBQUE7QUFBQSxVQUFnQlAsTUFBTUUsT0FBT007QUFBQUEsVUFBZ0I7QUFBQSxhQUFoRDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWtEO0FBQUEsUUFDbEQsdUJBQUMsT0FBRTtBQUFBO0FBQUEsVUFBYVIsTUFBTUUsT0FBT087QUFBQUEsYUFBN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUF1QztBQUFBLFFBQ3ZDLHVCQUFDLE9BQUU7QUFBQTtBQUFBLFVBQVNULE1BQU1FLE9BQU9RO0FBQUFBLGFBQXpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBK0I7QUFBQSxXQUpoQztBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS0E7QUFBQSxTQWpCRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBa0JBLEtBbkJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FvQkE7QUFBQSxJQUNBLHVCQUFDLFVBQUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUFJO0FBQUEsT0F2Qkw7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQXdCQTtBQUVGO0FBQUNDLEtBL0JlWjtBQUFZLElBQUFZO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJTaW5nbGVSZXNvcnQiLCJwcm9wcyIsImxhc3RTbm93ZmFsbCIsInJlc29ydCIsIm5hbWUiLCJzbm93ZmFsbEFtb3VudCIsImJhc2VEZXB0aCIsInRlbXBlcmF0dXJlIiwid2luZHNwZWVkIiwic3VtbWl0RWxldmF0aW9uIiwibGlmdHNPcGVuIiwicHJpY2UiLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIlNpbmdsZVJlc29ydC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgUmVzb3J0IH0gZnJvbSBcIi4vUmVzb3J0Q2xhc3NcIjtcbmltcG9ydCBcIi4uLy4uL3N0eWxlcy9tYWluLmNzc1wiO1xuXG4vKipcbiAqIFByb3BlcnRpZXMgZm9yIHRoZSBTaW5nbGVSZXNvcnQgY29tcG9uZW50LlxuICovXG5pbnRlcmZhY2UgU2luZ2xlUmVzb3J0UHJvcHMge1xuXHRyZXNvcnQ6IFJlc29ydDtcbn1cblxuLyoqXG4gKiBSZW5kZXJzIGRldGFpbGVkIGluZm9ybWF0aW9uIGFib3V0IGEgc2luZ2xlIHJlc29ydC4gRGlzcGxheXMgdmFyaW91cyBzdGF0aXN0aWNzIGFuZFxuICogaW5mb3JtYXRpb24gYWJvdXQgdGhlIHJlc29ydCwgc3VjaCBhcyBzbm93ZmFsbCwgd2VhdGhlciwgYW5kIG1vdW50YWluIGluZm9ybWF0aW9uLlxuICovXG5leHBvcnQgZnVuY3Rpb24gU2luZ2xlUmVzb3J0KHByb3BzOiBTaW5nbGVSZXNvcnRQcm9wcykge1xuXHRjb25zdCBsYXN0U25vd2ZhbGwgPVxuXHRcdHByb3BzLnJlc29ydC5sYXN0U25vd2ZhbGwgPT09IDAgPyBcIkxhc3QgU25vdzogdG9kYXlcIiA6IGBMYXN0IFNub3c6ICR7cHJvcHMucmVzb3J0Lmxhc3RTbm93ZmFsbH0gZGF5cyBhZ29gO1xuXG5cdHJldHVybiAoXG5cdFx0PGRpdiBpZD1cImxpc3REaXZcIiBjbGFzc05hbWU9XCJyZXBsLWhpc3RvcnlcIiBhcmlhLWxhYmVsPVwiUmVzb3J0IGluZm9ybWF0aW9uXCI+XG5cdFx0XHQ8aDIgaWQ9XCJyZXNvcnROYW1lXCI+e3Byb3BzLnJlc29ydC5uYW1lfTwvaDI+XG5cdFx0XHQ8dGFibGU+XG5cdFx0XHRcdDx0cj5cblx0XHRcdFx0XHQ8dGQgY2xhc3NOYW1lPVwicmVzb3J0TGlzdERhdHVtXCI+XG5cdFx0XHRcdFx0XHQ8aDM+U25vdyBTdGF0czwvaDM+XG5cdFx0XHRcdFx0XHQ8cD5Tbm93ZmFsbDoge3Byb3BzLnJlc29ydC5zbm93ZmFsbEFtb3VudH0gaW4uPC9wPlxuXHRcdFx0XHRcdFx0PHA+e2xhc3RTbm93ZmFsbH08L3A+XG5cdFx0XHRcdFx0XHQ8cD5CYXNlLWRlcHRoOiB7cHJvcHMucmVzb3J0LmJhc2VEZXB0aH0gaW4uPC9wPlxuXHRcdFx0XHRcdDwvdGQ+XG5cdFx0XHRcdFx0PHRkIGNsYXNzTmFtZT1cInJlc29ydExpc3REYXR1bVwiPlxuXHRcdFx0XHRcdFx0PGgzPldlYXRoZXI8L2gzPlxuXHRcdFx0XHRcdFx0PHA+VGVtcGVyYXR1cmU6IHtwcm9wcy5yZXNvcnQudGVtcGVyYXR1cmV9wrBGPC9wPlxuXHRcdFx0XHRcdFx0PHA+V2luZHNwZWVkOiB7cHJvcHMucmVzb3J0LndpbmRzcGVlZH0gbXBoPC9wPlxuXHRcdFx0XHRcdDwvdGQ+XG5cdFx0XHRcdFx0PHRkIGNsYXNzTmFtZT1cInJlc29ydExpc3REYXR1bVwiPlxuXHRcdFx0XHRcdFx0PGgzPk1vdW50YWluIEluZm88L2gzPlxuXHRcdFx0XHRcdFx0PHA+VG9wIEVsZXZhdGlvbjoge3Byb3BzLnJlc29ydC5zdW1taXRFbGV2YXRpb259ZnQ8L3A+XG5cdFx0XHRcdFx0XHQ8cD5MaWZ0cyBPcGVuOiB7cHJvcHMucmVzb3J0LmxpZnRzT3Blbn08L3A+XG5cdFx0XHRcdFx0XHQ8cD5QcmljZTogJHtwcm9wcy5yZXNvcnQucHJpY2V9PC9wPlxuXHRcdFx0XHRcdDwvdGQ+XG5cdFx0XHRcdDwvdHI+XG5cdFx0XHQ8L3RhYmxlPlxuXHRcdFx0PGhyPjwvaHI+XG5cdFx0PC9kaXY+XG5cdCk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9hdXN0aW53aWxsaWFtcy9Eb2N1bWVudHMvU2Nob29sL3RoaXJkU2VtZXN0ZXIvQ1MzMi90ZXJtLXByb2plY3QtdGJ6aGFvLXRwZXp6YS1zbXNjaHVjaC1id2lsbGk0OC9Gcm9udGVuZC9za2kvc3JjL2NvbXBvbmVudHMvcmVzb3J0cy9TaW5nbGVSZXNvcnQudHN4In0=