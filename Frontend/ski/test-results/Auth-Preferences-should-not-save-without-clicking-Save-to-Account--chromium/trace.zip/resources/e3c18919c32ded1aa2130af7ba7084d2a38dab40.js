import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/resorts/SingleResort.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=36ac7ba8"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/resorts/SingleResort.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import "/src/styles/main.css";
export function SingleResort(props) {
  return /* @__PURE__ */ jsxDEV("div", { id: "listDiv", className: "repl-history", "aria-label": "Resort information", children: [
    /* @__PURE__ */ jsxDEV("h2", { id: "resortName", children: props.resort.name }, void 0, false, {
      fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/resorts/SingleResort.tsx",
      lineNumber: 17,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("table", { children: /* @__PURE__ */ jsxDEV("tr", { children: [
      /* @__PURE__ */ jsxDEV("td", { className: "resortListDatum", children: [
        /* @__PURE__ */ jsxDEV("h3", { children: "Snow Stats" }, void 0, false, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/resorts/SingleResort.tsx",
          lineNumber: 21,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("p", { children: [
          "Snowfall: ",
          props.resort.snowfallAmount
        ] }, void 0, true, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/resorts/SingleResort.tsx",
          lineNumber: 22,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("p", { children: [
          "Last Snow: ",
          props.resort.lastSnowfall
        ] }, void 0, true, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/resorts/SingleResort.tsx",
          lineNumber: 23,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("p", { children: [
          "Base-depth: ",
          props.resort.baseDepth
        ] }, void 0, true, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/resorts/SingleResort.tsx",
          lineNumber: 24,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/resorts/SingleResort.tsx",
        lineNumber: 20,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("td", { className: "resortListDatum", children: [
        /* @__PURE__ */ jsxDEV("h3", { children: "Weather" }, void 0, false, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/resorts/SingleResort.tsx",
          lineNumber: 27,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("p", { children: [
          "Temperature: ",
          props.resort.temperature,
          "°F"
        ] }, void 0, true, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/resorts/SingleResort.tsx",
          lineNumber: 28,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("p", { children: [
          "Windspeed: ",
          props.resort.windspeed,
          " mph"
        ] }, void 0, true, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/resorts/SingleResort.tsx",
          lineNumber: 29,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/resorts/SingleResort.tsx",
        lineNumber: 26,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ jsxDEV("td", { className: "resortListDatum", children: [
        /* @__PURE__ */ jsxDEV("h3", { children: "Mountain Info" }, void 0, false, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/resorts/SingleResort.tsx",
          lineNumber: 32,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("p", { children: [
          "Top Elevation: ",
          props.resort.summitElevation
        ] }, void 0, true, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/resorts/SingleResort.tsx",
          lineNumber: 33,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("p", { children: [
          "Lifts Open: ",
          props.resort.liftsOpen
        ] }, void 0, true, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/resorts/SingleResort.tsx",
          lineNumber: 34,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("p", { children: [
          "Price: $",
          props.resort.price
        ] }, void 0, true, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/resorts/SingleResort.tsx",
          lineNumber: 35,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/resorts/SingleResort.tsx",
        lineNumber: 31,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/resorts/SingleResort.tsx",
      lineNumber: 19,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/resorts/SingleResort.tsx",
      lineNumber: 18,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("hr", {}, void 0, false, {
      fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/resorts/SingleResort.tsx",
      lineNumber: 39,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/resorts/SingleResort.tsx",
    lineNumber: 16,
    columnNumber: 10
  }, this);
}
_c = SingleResort;
var _c;
$RefreshReg$(_c, "SingleResort");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/resorts/SingleResort.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUJNO0FBakJOLDJCQUF1QjtBQUFlO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDdEMsT0FBTztBQWFBLGdCQUFTQSxhQUFhQyxPQUEwQjtBQUNyRCxTQUNFLHVCQUFDLFNBQUksSUFBRyxXQUFVLFdBQVUsZ0JBQWUsY0FBVyxzQkFDcEQ7QUFBQSwyQkFBQyxRQUFHLElBQUcsY0FBY0EsZ0JBQU1DLE9BQU9DLFFBQWxDO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBdUM7QUFBQSxJQUN2Qyx1QkFBQyxXQUNDLGlDQUFDLFFBQ0M7QUFBQSw2QkFBQyxRQUFHLFdBQVUsbUJBQ1o7QUFBQSwrQkFBQyxRQUFHLDBCQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBYztBQUFBLFFBQ2QsdUJBQUMsT0FBRTtBQUFBO0FBQUEsVUFBV0YsTUFBTUMsT0FBT0U7QUFBQUEsYUFBM0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwQztBQUFBLFFBQzFDLHVCQUFDLE9BQUU7QUFBQTtBQUFBLFVBQVlILE1BQU1DLE9BQU9HO0FBQUFBLGFBQTVCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBeUM7QUFBQSxRQUN6Qyx1QkFBQyxPQUFFO0FBQUE7QUFBQSxVQUFhSixNQUFNQyxPQUFPSTtBQUFBQSxhQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXVDO0FBQUEsV0FKekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBO0FBQUEsTUFDQSx1QkFBQyxRQUFHLFdBQVUsbUJBQ1o7QUFBQSwrQkFBQyxRQUFHLHVCQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBVztBQUFBLFFBQ1gsdUJBQUMsT0FBRTtBQUFBO0FBQUEsVUFBY0wsTUFBTUMsT0FBT0s7QUFBQUEsVUFBWTtBQUFBLGFBQTFDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNEM7QUFBQSxRQUM1Qyx1QkFBQyxPQUFFO0FBQUE7QUFBQSxVQUFZTixNQUFNQyxPQUFPTTtBQUFBQSxVQUFVO0FBQUEsYUFBdEM7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUEwQztBQUFBLFdBSDVDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFJQTtBQUFBLE1BQ0EsdUJBQUMsUUFBRyxXQUFVLG1CQUNaO0FBQUEsK0JBQUMsUUFBRyw2QkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWlCO0FBQUEsUUFDakIsdUJBQUMsT0FBRTtBQUFBO0FBQUEsVUFBZ0JQLE1BQU1DLE9BQU9PO0FBQUFBLGFBQWhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBZ0Q7QUFBQSxRQUNoRCx1QkFBQyxPQUFFO0FBQUE7QUFBQSxVQUFhUixNQUFNQyxPQUFPUTtBQUFBQSxhQUE3QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQXVDO0FBQUEsUUFDdkMsdUJBQUMsT0FBRTtBQUFBO0FBQUEsVUFBU1QsTUFBTUMsT0FBT1M7QUFBQUEsYUFBekI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUErQjtBQUFBLFdBSmpDO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFLQTtBQUFBLFNBakJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FrQkEsS0FuQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQW9CQTtBQUFBLElBQ0EsdUJBQUMsVUFBRDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBQUk7QUFBQSxPQXZCTjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBd0JBO0FBRUo7QUFBQ0MsS0E1QmVaO0FBQVksSUFBQVk7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIlNpbmdsZVJlc29ydCIsInByb3BzIiwicmVzb3J0IiwibmFtZSIsInNub3dmYWxsQW1vdW50IiwibGFzdFNub3dmYWxsIiwiYmFzZURlcHRoIiwidGVtcGVyYXR1cmUiLCJ3aW5kc3BlZWQiLCJzdW1taXRFbGV2YXRpb24iLCJsaWZ0c09wZW4iLCJwcmljZSIsIl9jIiwiJFJlZnJlc2hSZWckIl0sInNvdXJjZXMiOlsiU2luZ2xlUmVzb3J0LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBSZXNvcnQgfSBmcm9tIFwiLi9SZXNvcnRDbGFzc1wiO1xuaW1wb3J0IFwiLi4vLi4vc3R5bGVzL21haW4uY3NzXCI7XG5cbi8qKlxuICogUHJvcGVydGllcyBmb3IgdGhlIFNpbmdsZVJlc29ydCBjb21wb25lbnQuXG4gKi9cbmludGVyZmFjZSBTaW5nbGVSZXNvcnRQcm9wcyB7XG4gIHJlc29ydDogUmVzb3J0O1xufVxuXG4vKipcbiAqIFJlbmRlcnMgZGV0YWlsZWQgaW5mb3JtYXRpb24gYWJvdXQgYSBzaW5nbGUgcmVzb3J0LiBEaXNwbGF5cyB2YXJpb3VzIHN0YXRpc3RpY3MgYW5kXG4gKiBpbmZvcm1hdGlvbiBhYm91dCB0aGUgcmVzb3J0LCBzdWNoIGFzIHNub3dmYWxsLCB3ZWF0aGVyLCBhbmQgbW91bnRhaW4gaW5mb3JtYXRpb24uXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBTaW5nbGVSZXNvcnQocHJvcHM6IFNpbmdsZVJlc29ydFByb3BzKSB7XG4gIHJldHVybiAoXG4gICAgPGRpdiBpZD1cImxpc3REaXZcIiBjbGFzc05hbWU9XCJyZXBsLWhpc3RvcnlcIiBhcmlhLWxhYmVsPVwiUmVzb3J0IGluZm9ybWF0aW9uXCI+XG4gICAgICA8aDIgaWQ9XCJyZXNvcnROYW1lXCI+e3Byb3BzLnJlc29ydC5uYW1lfTwvaDI+XG4gICAgICA8dGFibGU+XG4gICAgICAgIDx0cj5cbiAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwicmVzb3J0TGlzdERhdHVtXCI+XG4gICAgICAgICAgICA8aDM+U25vdyBTdGF0czwvaDM+XG4gICAgICAgICAgICA8cD5Tbm93ZmFsbDoge3Byb3BzLnJlc29ydC5zbm93ZmFsbEFtb3VudH08L3A+XG4gICAgICAgICAgICA8cD5MYXN0IFNub3c6IHtwcm9wcy5yZXNvcnQubGFzdFNub3dmYWxsfTwvcD5cbiAgICAgICAgICAgIDxwPkJhc2UtZGVwdGg6IHtwcm9wcy5yZXNvcnQuYmFzZURlcHRofTwvcD5cbiAgICAgICAgICA8L3RkPlxuICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJyZXNvcnRMaXN0RGF0dW1cIj5cbiAgICAgICAgICAgIDxoMz5XZWF0aGVyPC9oMz5cbiAgICAgICAgICAgIDxwPlRlbXBlcmF0dXJlOiB7cHJvcHMucmVzb3J0LnRlbXBlcmF0dXJlfcKwRjwvcD5cbiAgICAgICAgICAgIDxwPldpbmRzcGVlZDoge3Byb3BzLnJlc29ydC53aW5kc3BlZWR9IG1waDwvcD5cbiAgICAgICAgICA8L3RkPlxuICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJyZXNvcnRMaXN0RGF0dW1cIj5cbiAgICAgICAgICAgIDxoMz5Nb3VudGFpbiBJbmZvPC9oMz5cbiAgICAgICAgICAgIDxwPlRvcCBFbGV2YXRpb246IHtwcm9wcy5yZXNvcnQuc3VtbWl0RWxldmF0aW9ufTwvcD5cbiAgICAgICAgICAgIDxwPkxpZnRzIE9wZW46IHtwcm9wcy5yZXNvcnQubGlmdHNPcGVufTwvcD5cbiAgICAgICAgICAgIDxwPlByaWNlOiAke3Byb3BzLnJlc29ydC5wcmljZX08L3A+XG4gICAgICAgICAgPC90ZD5cbiAgICAgICAgPC90cj5cbiAgICAgIDwvdGFibGU+XG4gICAgICA8aHI+PC9ocj5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2F1c3RpbndpbGxpYW1zL0RvY3VtZW50cy9TY2hvb2wvdGhpcmRTZW1lc3Rlci9DUzMyL3Rlcm0tcHJvamVjdC10YnpoYW8tdHBlenphLXNtc2NodWNoLWJ3aWxsaTQ4L0Zyb250ZW5kL3NraS9zcmMvY29tcG9uZW50cy9yZXNvcnRzL1NpbmdsZVJlc29ydC50c3gifQ==