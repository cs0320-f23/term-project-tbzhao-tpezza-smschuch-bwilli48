import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/resorts/ResortsList.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=36ac7ba8"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/resorts/ResortsList.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import "/src/styles/main.css";
import { SingleResort } from "/src/components/resorts/SingleResort.tsx";
export function ResortsList(props) {
  if (props.resortList.length === 1 && props.resortList[0].name === "Resort Not Found") {
    return /* @__PURE__ */ jsxDEV("div", { className: "resorts-list", "aria-label": "No resorts found", children: /* @__PURE__ */ jsxDEV("p", { id: "resortTitle", children: "Resort Not Found" }, void 0, false, {
      fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/resorts/ResortsList.tsx",
      lineNumber: 20,
      columnNumber: 5
    }, this) }, void 0, false, {
      fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/resorts/ResortsList.tsx",
      lineNumber: 19,
      columnNumber: 12
    }, this);
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "resorts-list", "aria-label": "List of resorts", children: [
    /* @__PURE__ */ jsxDEV("p", { id: "resortTitle", children: "Resorts" }, void 0, false, {
      fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/resorts/ResortsList.tsx",
      lineNumber: 24,
      columnNumber: 4
    }, this),
    props.resortList.map((resort, index) => /* @__PURE__ */ jsxDEV(SingleResort, { resort }, index, false, {
      fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/resorts/ResortsList.tsx",
      lineNumber: 25,
      columnNumber: 45
    }, this))
  ] }, void 0, true, {
    fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/resorts/ResortsList.tsx",
    lineNumber: 23,
    columnNumber: 10
  }, this);
}
_c = ResortsList;
var _c;
$RefreshReg$(_c, "ResortsList");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/resorts/ResortsList.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBb0JJO0FBcEJKLE9BQU87QUFBdUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBRTlCLFNBQVNBLG9CQUFvQjtBQWN0QixnQkFBU0MsWUFBWUMsT0FBeUI7QUFDcEQsTUFBSUEsTUFBTUMsV0FBV0MsV0FBVyxLQUFLRixNQUFNQyxXQUFXLENBQUMsRUFBRUUsU0FBUyxvQkFBb0I7QUFDckYsV0FDQyx1QkFBQyxTQUFJLFdBQVUsZ0JBQWUsY0FBVyxvQkFDeEMsaUNBQUMsT0FBRSxJQUFHLGVBQWMsZ0NBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBb0MsS0FEckM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsRUFFRjtBQUNBLFNBQ0MsdUJBQUMsU0FBSSxXQUFVLGdCQUFlLGNBQVcsbUJBQ3hDO0FBQUEsMkJBQUMsT0FBRSxJQUFHLGVBQWMsdUJBQXBCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBMkI7QUFBQSxJQUMxQkgsTUFBTUMsV0FBV0csSUFBSSxDQUFDQyxRQUFRQyxVQUM5Qix1QkFBQyxnQkFBeUIsVUFBUEEsT0FBbkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUF5QyxDQUN6QztBQUFBLE9BSkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQUtBO0FBRUY7QUFBQ0MsS0FoQmVSO0FBQVcsSUFBQVE7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbIlNpbmdsZVJlc29ydCIsIlJlc29ydHNMaXN0IiwicHJvcHMiLCJyZXNvcnRMaXN0IiwibGVuZ3RoIiwibmFtZSIsIm1hcCIsInJlc29ydCIsImluZGV4IiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJSZXNvcnRzTGlzdC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFwiLi4vLi4vc3R5bGVzL21haW4uY3NzXCI7XG5pbXBvcnQgeyBSZXNvcnQgfSBmcm9tIFwiLi9SZXNvcnRDbGFzc1wiO1xuaW1wb3J0IHsgU2luZ2xlUmVzb3J0IH0gZnJvbSBcIi4vU2luZ2xlUmVzb3J0XCI7XG5cbi8qKlxuICogUHJvcGVydGllcyBmb3IgdGhlIFJlc29ydHNMaXN0IGNvbXBvbmVudC5cbiAqL1xuaW50ZXJmYWNlIFJlc29ydHNMaXN0UHJvcHMge1xuXHRyZXNvcnRMaXN0OiBSZXNvcnRbXTtcbn1cblxuLyoqXG4gKiBSZW5kZXJzIGEgbGlzdCBvZiByZXNvcnRzLiBEaXNwbGF5cyBcIlJlc29ydCBOb3QgRm91bmRcIiBpZiB0aGUgc2VhcmNoIHlpZWxkcyBubyByZXN1bHRzLFxuICogb3IgYSBsaXN0IG9mIHJlc29ydHMgb3RoZXJ3aXNlLiBGdW5jdGlvbnMgc2ltaWxhcmx5IHRvIGEgUkVQTCBoaXN0b3J5IGJveCwgbGlzdGluZyB0aGVcbiAqIG91dHB1dHMgb2YgcHJldmlvdXMgY29tbWFuZHMuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBSZXNvcnRzTGlzdChwcm9wczogUmVzb3J0c0xpc3RQcm9wcykge1xuXHRpZiAocHJvcHMucmVzb3J0TGlzdC5sZW5ndGggPT09IDEgJiYgcHJvcHMucmVzb3J0TGlzdFswXS5uYW1lID09PSBcIlJlc29ydCBOb3QgRm91bmRcIikge1xuXHRcdHJldHVybiAoXG5cdFx0XHQ8ZGl2IGNsYXNzTmFtZT1cInJlc29ydHMtbGlzdFwiIGFyaWEtbGFiZWw9XCJObyByZXNvcnRzIGZvdW5kXCI+XG5cdFx0XHRcdDxwIGlkPVwicmVzb3J0VGl0bGVcIj5SZXNvcnQgTm90IEZvdW5kPC9wPlxuXHRcdFx0PC9kaXY+XG5cdFx0KTtcblx0fVxuXHRyZXR1cm4gKFxuXHRcdDxkaXYgY2xhc3NOYW1lPVwicmVzb3J0cy1saXN0XCIgYXJpYS1sYWJlbD1cIkxpc3Qgb2YgcmVzb3J0c1wiPlxuXHRcdFx0PHAgaWQ9XCJyZXNvcnRUaXRsZVwiPlJlc29ydHM8L3A+XG5cdFx0XHR7cHJvcHMucmVzb3J0TGlzdC5tYXAoKHJlc29ydCwgaW5kZXgpID0+IChcblx0XHRcdFx0PFNpbmdsZVJlc29ydCBrZXk9e2luZGV4fSByZXNvcnQ9e3Jlc29ydH0gLz5cblx0XHRcdCkpfVxuXHRcdDwvZGl2PlxuXHQpO1xufVxuIl0sImZpbGUiOiIvVXNlcnMvYXVzdGlud2lsbGlhbXMvRG9jdW1lbnRzL1NjaG9vbC90aGlyZFNlbWVzdGVyL0NTMzIvdGVybS1wcm9qZWN0LXRiemhhby10cGV6emEtc21zY2h1Y2gtYndpbGxpNDgvRnJvbnRlbmQvc2tpL3NyYy9jb21wb25lbnRzL3Jlc29ydHMvUmVzb3J0c0xpc3QudHN4In0=