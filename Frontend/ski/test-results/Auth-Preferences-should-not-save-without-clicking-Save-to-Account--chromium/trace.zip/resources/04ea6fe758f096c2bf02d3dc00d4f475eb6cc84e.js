import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/search/ResortsDropdown.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=36ac7ba8"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/search/ResortsDropdown.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import "/src/styles/main.css";
export function ResortDropdown(props) {
  return /* @__PURE__ */ jsxDEV("div", { className: props.showDropDown ? "dropdown-visible" : "dropdown-hidden", "aria-label": "Resort options dropdown", children: props.resortOptions.map((resortOption, index) => {
    return /* @__PURE__ */ jsxDEV("div", { onClick: () => {
      props.resortOptionsSelection(resortOption);
      props.setCommandString(resortOption);
      props.toggleDropDown();
    }, "aria-label": `Select resort: ${resortOption}`, children: [
      /* @__PURE__ */ jsxDEV("hr", { className: "dropdownHR" }, void 0, false, {
        fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/search/ResortsDropdown.tsx",
        lineNumber: 27,
        columnNumber: 7
      }, this),
      /* @__PURE__ */ jsxDEV("p", { children: resortOption }, void 0, false, {
        fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/search/ResortsDropdown.tsx",
        lineNumber: 28,
        columnNumber: 7
      }, this)
    ] }, index, true, {
      fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/search/ResortsDropdown.tsx",
      lineNumber: 22,
      columnNumber: 14
    }, this);
  }) }, void 0, false, {
    fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/search/ResortsDropdown.tsx",
    lineNumber: 20,
    columnNumber: 10
  }, this);
}
_c = ResortDropdown;
var _c;
$RefreshReg$(_c, "ResortDropdown");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/search/ResortsDropdown.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0NNO0FBaENOLE9BQU9BLG9CQUFtQkM7QUFBZ0JDLE1BQVMsY0FBVSxPQUFRLHNCQUFPO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFDNUUsT0FBTztBQWlCQSxnQkFBU0MsZUFBZUMsT0FBNEI7QUFDMUQsU0FDQyx1QkFBQyxTQUFJLFdBQVdBLE1BQU1DLGVBQWUscUJBQXFCLG1CQUFtQixjQUFXLDJCQUN0RkQsZ0JBQU1FLGNBQWNDLElBQUksQ0FBQ0MsY0FBc0JDLFVBQStCO0FBQzlFLFdBQ0MsdUJBQUMsU0FFQSxTQUFTLE1BQVk7QUFDcEJMLFlBQU1NLHVCQUF1QkYsWUFBWTtBQUN6Q0osWUFBTU8saUJBQWlCSCxZQUFZO0FBQ25DSixZQUFNUSxlQUFlO0FBQUEsSUFDdEIsR0FDQSxjQUFhLGtCQUFpQkosWUFBYSxJQUUzQztBQUFBLDZCQUFDLFFBQUcsV0FBVSxnQkFBZDtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQTJCO0FBQUEsTUFDM0IsdUJBQUMsT0FBR0EsMEJBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUFpQjtBQUFBLFNBVFpDLE9BRE47QUFBQTtBQUFBO0FBQUE7QUFBQSxXQVdBO0FBQUEsRUFFRixDQUFDLEtBaEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FpQkE7QUFFRjtBQUFDSSxLQXJCZVY7QUFBYyxJQUFBVTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiUmVhY3QiLCJTZXRTdGF0ZUFjdGlvbiIsInVzZUVmZmVjdCIsIlJlc29ydERyb3Bkb3duIiwicHJvcHMiLCJzaG93RHJvcERvd24iLCJyZXNvcnRPcHRpb25zIiwibWFwIiwicmVzb3J0T3B0aW9uIiwiaW5kZXgiLCJyZXNvcnRPcHRpb25zU2VsZWN0aW9uIiwic2V0Q29tbWFuZFN0cmluZyIsInRvZ2dsZURyb3BEb3duIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJSZXNvcnRzRHJvcGRvd24udHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBSZWFjdCwgeyBEaXNwYXRjaCwgU2V0U3RhdGVBY3Rpb24sIHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCBcIi4uLy4uL3N0eWxlcy9tYWluLmNzc1wiO1xuXG4vKipcbiAqIFByb3BlcnRpZXMgZm9yIHRoZSBSZXNvcnREcm9wZG93biBjb21wb25lbnQuXG4gKi9cbmludGVyZmFjZSBSZXNvcnREcm9wZG93blByb3BzIHtcblx0cmVzb3J0T3B0aW9uczogc3RyaW5nW107XG5cdHNob3dEcm9wRG93bjogYm9vbGVhbjtcblx0dG9nZ2xlRHJvcERvd246ICgpID0+IHZvaWQ7XG5cdHJlc29ydE9wdGlvbnNTZWxlY3Rpb246IChyZXNvcnRPcHRpb246IHN0cmluZykgPT4gdm9pZDtcblx0c2V0Q29tbWFuZFN0cmluZzogRGlzcGF0Y2g8U2V0U3RhdGVBY3Rpb248c3RyaW5nPj47XG59XG5cbi8qKlxuICogUmVuZGVycyBhIGRyb3Bkb3duIG1lbnUgd2l0aCByZXNvcnQgb3B0aW9ucy4gQWxsb3dzIGEgdXNlciB0byBzZWxlY3QgYSByZXNvcnQgZnJvbVxuICogdGhlIGRyb3Bkb3duLiBUaGUgc2VsZWN0aW9uIGlzIG1hbmFnZWQgdGhyb3VnaCBhIGNhbGxiYWNrIGZ1bmN0aW9uLlxuICovXG5leHBvcnQgZnVuY3Rpb24gUmVzb3J0RHJvcGRvd24ocHJvcHM6IFJlc29ydERyb3Bkb3duUHJvcHMpIHtcblx0cmV0dXJuIChcblx0XHQ8ZGl2IGNsYXNzTmFtZT17cHJvcHMuc2hvd0Ryb3BEb3duID8gXCJkcm9wZG93bi12aXNpYmxlXCIgOiBcImRyb3Bkb3duLWhpZGRlblwifSBhcmlhLWxhYmVsPVwiUmVzb3J0IG9wdGlvbnMgZHJvcGRvd25cIj5cblx0XHRcdHtwcm9wcy5yZXNvcnRPcHRpb25zLm1hcCgocmVzb3J0T3B0aW9uOiBzdHJpbmcsIGluZGV4OiBudW1iZXIpOiBKU1guRWxlbWVudCA9PiB7XG5cdFx0XHRcdHJldHVybiAoXG5cdFx0XHRcdFx0PGRpdlxuXHRcdFx0XHRcdFx0a2V5PXtpbmRleH1cblx0XHRcdFx0XHRcdG9uQ2xpY2s9eygpOiB2b2lkID0+IHtcblx0XHRcdFx0XHRcdFx0cHJvcHMucmVzb3J0T3B0aW9uc1NlbGVjdGlvbihyZXNvcnRPcHRpb24pO1xuXHRcdFx0XHRcdFx0XHRwcm9wcy5zZXRDb21tYW5kU3RyaW5nKHJlc29ydE9wdGlvbik7XG5cdFx0XHRcdFx0XHRcdHByb3BzLnRvZ2dsZURyb3BEb3duKCk7XG5cdFx0XHRcdFx0XHR9fVxuXHRcdFx0XHRcdFx0YXJpYS1sYWJlbD17YFNlbGVjdCByZXNvcnQ6ICR7cmVzb3J0T3B0aW9ufWB9XG5cdFx0XHRcdFx0PlxuXHRcdFx0XHRcdFx0PGhyIGNsYXNzTmFtZT1cImRyb3Bkb3duSFJcIj48L2hyPlxuXHRcdFx0XHRcdFx0PHA+e3Jlc29ydE9wdGlvbn08L3A+XG5cdFx0XHRcdFx0PC9kaXY+XG5cdFx0XHRcdCk7XG5cdFx0XHR9KX1cblx0XHQ8L2Rpdj5cblx0KTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2F1c3RpbndpbGxpYW1zL0RvY3VtZW50cy9TY2hvb2wvdGhpcmRTZW1lc3Rlci9DUzMyL3Rlcm0tcHJvamVjdC10YnpoYW8tdHBlenphLXNtc2NodWNoLWJ3aWxsaTQ4L0Zyb250ZW5kL3NraS9zcmMvY29tcG9uZW50cy9zZWFyY2gvUmVzb3J0c0Ryb3Bkb3duLnRzeCJ9