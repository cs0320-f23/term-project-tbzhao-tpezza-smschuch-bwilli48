import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/auth/LoginButton.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=36ac7ba8"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/auth/LoginButton.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import { useAuth0 } from "/node_modules/.vite/deps/@auth0_auth0-react.js?v=36ac7ba8";
const LoginButton = ({
  className
}) => {
  _s();
  const {
    loginWithRedirect
  } = useAuth0();
  return /* @__PURE__ */ jsxDEV("button", { className, onClick: () => loginWithRedirect(), "aria-label": "Log in", children: "Log In" }, void 0, false, {
    fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/auth/LoginButton.tsx",
    lineNumber: 21,
    columnNumber: 10
  }, this);
};
_s(LoginButton, "pQ5EEIQFqTRjxAX5iN+Mi9UtuKA=", false, function() {
  return [useAuth0];
});
_c = LoginButton;
export default LoginButton;
var _c;
$RefreshReg$(_c, "LoginButton");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/auth/LoginButton.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBZ0JFOzs7Ozs7Ozs7Ozs7Ozs7OztBQWhCRixTQUFTQSxnQkFBZ0I7QUFZekIsTUFBTUMsY0FBMENBLENBQUM7QUFBQSxFQUFFQztBQUFVLE1BQU07QUFBQUMsS0FBQTtBQUNsRSxRQUFNO0FBQUEsSUFBRUM7QUFBQUEsRUFBa0IsSUFBSUosU0FBUztBQUV2QyxTQUNDLHVCQUFDLFlBQU8sV0FBc0IsU0FBUyxNQUFNSSxrQkFBa0IsR0FBRyxjQUFXLFVBQVEsc0JBQXJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FFQTtBQUVGO0FBQUVELEdBUklGLGFBQXVDO0FBQUEsVUFDZEQsUUFBUTtBQUFBO0FBQUFLLEtBRGpDSjtBQVVOLGVBQWVBO0FBQVksSUFBQUk7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZUF1dGgwIiwiTG9naW5CdXR0b24iLCJjbGFzc05hbWUiLCJfcyIsImxvZ2luV2l0aFJlZGlyZWN0IiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJMb2dpbkJ1dHRvbi50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlQXV0aDAgfSBmcm9tIFwiQGF1dGgwL2F1dGgwLXJlYWN0XCI7XG5cbi8qKlxuICogUHJvcGVydGllcyBhY2NlcHRlZCBieSB0aGUgTG9naW5CdXR0b24gY29tcG9uZW50LlxuICovXG50eXBlIExvZ2luQnV0dG9uUHJvcHMgPSB7XG5cdGNsYXNzTmFtZTogc3RyaW5nO1xufTtcblxuLyoqXG4gKiBSZW5kZXJzIGEgYnV0dG9uIHRoYXQgdHJpZ2dlcnMgdGhlIEF1dGgwIGxvZ2luIGZsb3cuXG4gKi9cbmNvbnN0IExvZ2luQnV0dG9uOiBSZWFjdC5GQzxMb2dpbkJ1dHRvblByb3BzPiA9ICh7IGNsYXNzTmFtZSB9KSA9PiB7XG5cdGNvbnN0IHsgbG9naW5XaXRoUmVkaXJlY3QgfSA9IHVzZUF1dGgwKCk7XG5cblx0cmV0dXJuIChcblx0XHQ8YnV0dG9uIGNsYXNzTmFtZT17Y2xhc3NOYW1lfSBvbkNsaWNrPXsoKSA9PiBsb2dpbldpdGhSZWRpcmVjdCgpfSBhcmlhLWxhYmVsPVwiTG9nIGluXCI+XG5cdFx0XHRMb2cgSW5cblx0XHQ8L2J1dHRvbj5cblx0KTtcbn07XG5cbmV4cG9ydCBkZWZhdWx0IExvZ2luQnV0dG9uO1xuIl0sImZpbGUiOiIvVXNlcnMvYXVzdGlud2lsbGlhbXMvRG9jdW1lbnRzL1NjaG9vbC90aGlyZFNlbWVzdGVyL0NTMzIvdGVybS1wcm9qZWN0LXRiemhhby10cGV6emEtc21zY2h1Y2gtYndpbGxpNDgvRnJvbnRlbmQvc2tpL3NyYy9jb21wb25lbnRzL2F1dGgvTG9naW5CdXR0b24udHN4In0=