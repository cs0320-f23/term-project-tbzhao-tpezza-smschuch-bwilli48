import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/prefs/PreferenceTicker.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=36ac7ba8"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/PreferenceTicker.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import "/src/styles/main.css";
var resetNum = 1;
export function PreferenceTicker(props) {
  function upWeight() {
    var currentPref = props.preferenceMap.get(props.preference);
    if (currentPref === void 0) {
      throw console.error();
    }
    if (currentPref.weight < 10) {
      const newMap = new Map(props.preferenceMap);
      newMap.get(props.preference)?.upWeight();
      props.setPreferenceMap(newMap);
    }
    props.setReset(resetNum);
    resetNum += 1;
  }
  function downWeight() {
    var currentPref = props.preferenceMap.get(props.preference);
    if (currentPref === void 0) {
      throw console.error();
    }
    if (currentPref.weight > 0) {
      const newMap = new Map(props.preferenceMap);
      newMap.get(props.preference)?.downWeight();
      props.setPreferenceMap(newMap);
    }
    props.setReset(resetNum);
    resetNum += 1;
  }
  function upValue() {
    var currentPref = props.preferenceMap.get(props.preference);
    if (currentPref === void 0) {
      throw console.error();
    }
    const newMap = new Map(props.preferenceMap);
    newMap.get(props.preference)?.upValue(props.valueJump);
    props.setPreferenceMap(newMap);
    props.setReset(resetNum);
    resetNum += 1;
  }
  function downValue() {
    var currentPref = props.preferenceMap.get(props.preference);
    if (currentPref === void 0) {
      throw console.error();
    }
    const newMap = new Map(props.preferenceMap);
    newMap.get(props.preference)?.downValue(props.valueJump);
    props.setPreferenceMap(newMap);
    props.setReset(resetNum);
    resetNum += 1;
  }
  return /* @__PURE__ */ jsxDEV("div", { children: /* @__PURE__ */ jsxDEV("table", { children: /* @__PURE__ */ jsxDEV("tr", { children: [
    /* @__PURE__ */ jsxDEV("td", { children: /* @__PURE__ */ jsxDEV("p", { children: [
      "Weight: ",
      props.preferenceMap.get(props.preference)?.weight
    ] }, void 0, true, {
      fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/PreferenceTicker.tsx",
      lineNumber: 79,
      columnNumber: 13
    }, this) }, void 0, false, {
      fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/PreferenceTicker.tsx",
      lineNumber: 78,
      columnNumber: 11
    }, this),
    /* @__PURE__ */ jsxDEV("td", { children: /* @__PURE__ */ jsxDEV("table", { children: [
      /* @__PURE__ */ jsxDEV("tr", { children: /* @__PURE__ */ jsxDEV("td", { children: /* @__PURE__ */ jsxDEV("button", { id: "upButton", onClick: () => upWeight(), "aria-label": `Increase weight for ${props.preference}`, children: "^" }, void 0, false, {
        fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/PreferenceTicker.tsx",
        lineNumber: 85,
        columnNumber: 19
      }, this) }, void 0, false, {
        fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/PreferenceTicker.tsx",
        lineNumber: 84,
        columnNumber: 17
      }, this) }, void 0, false, {
        fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/PreferenceTicker.tsx",
        lineNumber: 83,
        columnNumber: 15
      }, this),
      /* @__PURE__ */ jsxDEV("tr", { children: /* @__PURE__ */ jsxDEV("td", { children: /* @__PURE__ */ jsxDEV("button", { id: "downButton", onClick: () => downWeight(), "aria-label": `Decrease weight for ${props.preference}`, children: "v" }, void 0, false, {
        fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/PreferenceTicker.tsx",
        lineNumber: 92,
        columnNumber: 19
      }, this) }, void 0, false, {
        fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/PreferenceTicker.tsx",
        lineNumber: 91,
        columnNumber: 17
      }, this) }, void 0, false, {
        fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/PreferenceTicker.tsx",
        lineNumber: 90,
        columnNumber: 15
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/PreferenceTicker.tsx",
      lineNumber: 82,
      columnNumber: 13
    }, this) }, void 0, false, {
      fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/PreferenceTicker.tsx",
      lineNumber: 81,
      columnNumber: 11
    }, this),
    /* @__PURE__ */ jsxDEV("td", { children: /* @__PURE__ */ jsxDEV("p", { children: [
      "Value: ",
      props.preferenceMap.get(props.preference)?.value
    ] }, void 0, true, {
      fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/PreferenceTicker.tsx",
      lineNumber: 100,
      columnNumber: 13
    }, this) }, void 0, false, {
      fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/PreferenceTicker.tsx",
      lineNumber: 99,
      columnNumber: 11
    }, this),
    /* @__PURE__ */ jsxDEV("td", { children: /* @__PURE__ */ jsxDEV("table", { children: [
      /* @__PURE__ */ jsxDEV("tr", { children: /* @__PURE__ */ jsxDEV("td", { children: /* @__PURE__ */ jsxDEV("button", { id: "upButton", onClick: () => upValue(), "aria-label": `Increase value for ${props.preference}`, children: "^" }, void 0, false, {
        fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/PreferenceTicker.tsx",
        lineNumber: 106,
        columnNumber: 19
      }, this) }, void 0, false, {
        fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/PreferenceTicker.tsx",
        lineNumber: 105,
        columnNumber: 17
      }, this) }, void 0, false, {
        fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/PreferenceTicker.tsx",
        lineNumber: 104,
        columnNumber: 15
      }, this),
      /* @__PURE__ */ jsxDEV("tr", { children: /* @__PURE__ */ jsxDEV("td", { children: /* @__PURE__ */ jsxDEV("button", { id: "downButton", onClick: () => downValue(), "aria-label": `Decrease value for ${props.preference}`, children: "v" }, void 0, false, {
        fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/PreferenceTicker.tsx",
        lineNumber: 113,
        columnNumber: 19
      }, this) }, void 0, false, {
        fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/PreferenceTicker.tsx",
        lineNumber: 112,
        columnNumber: 17
      }, this) }, void 0, false, {
        fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/PreferenceTicker.tsx",
        lineNumber: 111,
        columnNumber: 15
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/PreferenceTicker.tsx",
      lineNumber: 103,
      columnNumber: 13
    }, this) }, void 0, false, {
      fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/PreferenceTicker.tsx",
      lineNumber: 102,
      columnNumber: 11
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/PreferenceTicker.tsx",
    lineNumber: 77,
    columnNumber: 9
  }, this) }, void 0, false, {
    fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/PreferenceTicker.tsx",
    lineNumber: 76,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/PreferenceTicker.tsx",
    lineNumber: 75,
    columnNumber: 10
  }, this);
}
_c = PreferenceTicker;
var _c;
$RefreshReg$(_c, "PreferenceTicker");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/PreferenceTicker.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBaUZZO0FBakZaLE9BQU87QUFBdUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBYTlCLElBQUlBLFdBQVc7QUFNUixnQkFBU0MsaUJBQWlCQyxPQUE4QjtBQUU3RCxXQUFTQyxXQUFXO0FBQ2xCLFFBQUlDLGNBQWNGLE1BQU1HLGNBQWNDLElBQUlKLE1BQU1LLFVBQVU7QUFDMUQsUUFBSUgsZ0JBQWdCSSxRQUFXO0FBQzdCLFlBQU1DLFFBQVFDLE1BQU07QUFBQSxJQUN0QjtBQUNBLFFBQUlOLFlBQVlPLFNBQVMsSUFBSTtBQUMzQixZQUFNQyxTQUFTLElBQUlDLElBQUlYLE1BQU1HLGFBQWE7QUFDMUNPLGFBQU9OLElBQUlKLE1BQU1LLFVBQVUsR0FBR0osU0FBUztBQUN2Q0QsWUFBTVksaUJBQWlCRixNQUFNO0FBQUEsSUFDL0I7QUFDQVYsVUFBTWEsU0FBU2YsUUFBUTtBQUN2QkEsZ0JBQVk7QUFBQSxFQUNkO0FBR0EsV0FBU2dCLGFBQWE7QUFDcEIsUUFBSVosY0FBY0YsTUFBTUcsY0FBY0MsSUFBSUosTUFBTUssVUFBVTtBQUMxRCxRQUFJSCxnQkFBZ0JJLFFBQVc7QUFDN0IsWUFBTUMsUUFBUUMsTUFBTTtBQUFBLElBQ3RCO0FBQ0EsUUFBSU4sWUFBWU8sU0FBUyxHQUFHO0FBQzFCLFlBQU1DLFNBQVMsSUFBSUMsSUFBSVgsTUFBTUcsYUFBYTtBQUMxQ08sYUFBT04sSUFBSUosTUFBTUssVUFBVSxHQUFHUyxXQUFXO0FBQ3pDZCxZQUFNWSxpQkFBaUJGLE1BQU07QUFBQSxJQUMvQjtBQUNBVixVQUFNYSxTQUFTZixRQUFRO0FBQ3ZCQSxnQkFBWTtBQUFBLEVBQ2Q7QUFHQSxXQUFTaUIsVUFBVTtBQUNqQixRQUFJYixjQUFjRixNQUFNRyxjQUFjQyxJQUFJSixNQUFNSyxVQUFVO0FBQzFELFFBQUlILGdCQUFnQkksUUFBVztBQUM3QixZQUFNQyxRQUFRQyxNQUFNO0FBQUEsSUFDdEI7QUFDQSxVQUFNRSxTQUFTLElBQUlDLElBQUlYLE1BQU1HLGFBQWE7QUFDMUNPLFdBQU9OLElBQUlKLE1BQU1LLFVBQVUsR0FBR1UsUUFBUWYsTUFBTWdCLFNBQVM7QUFDckRoQixVQUFNWSxpQkFBaUJGLE1BQU07QUFDN0JWLFVBQU1hLFNBQVNmLFFBQVE7QUFDdkJBLGdCQUFZO0FBQUEsRUFDZDtBQUdBLFdBQVNtQixZQUFZO0FBQ25CLFFBQUlmLGNBQWNGLE1BQU1HLGNBQWNDLElBQUlKLE1BQU1LLFVBQVU7QUFDMUQsUUFBSUgsZ0JBQWdCSSxRQUFXO0FBQzdCLFlBQU1DLFFBQVFDLE1BQU07QUFBQSxJQUN0QjtBQUNBLFVBQU1FLFNBQVMsSUFBSUMsSUFBSVgsTUFBTUcsYUFBYTtBQUMxQ08sV0FBT04sSUFBSUosTUFBTUssVUFBVSxHQUFHWSxVQUFVakIsTUFBTWdCLFNBQVM7QUFDdkRoQixVQUFNWSxpQkFBaUJGLE1BQU07QUFDN0JWLFVBQU1hLFNBQVNmLFFBQVE7QUFDdkJBLGdCQUFZO0FBQUEsRUFDZDtBQUVBLFNBQ0UsdUJBQUMsU0FDQyxpQ0FBQyxXQUNDLGlDQUFDLFFBQ0M7QUFBQSwyQkFBQyxRQUNDLGlDQUFDLE9BQUU7QUFBQTtBQUFBLE1BQVNFLE1BQU1HLGNBQWNDLElBQUlKLE1BQU1LLFVBQVUsR0FBR0k7QUFBQUEsU0FBdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUE4RCxLQURoRTtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBRUE7QUFBQSxJQUNBLHVCQUFDLFFBQ0MsaUNBQUMsV0FDQztBQUFBLDZCQUFDLFFBQ0MsaUNBQUMsUUFDQyxpQ0FBQyxZQUNDLElBQUcsWUFDSCxTQUFTLE1BQU1SLFNBQVMsR0FDeEIsY0FBYSx1QkFBc0JELE1BQU1LLFVBQVcsSUFBRSxpQkFIeEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU1BLEtBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVFBLEtBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVVBO0FBQUEsTUFDQSx1QkFBQyxRQUNDLGlDQUFDLFFBQ0MsaUNBQUMsWUFDQyxJQUFHLGNBQ0gsU0FBUyxNQUFNUyxXQUFXLEdBQzFCLGNBQWEsdUJBQXNCZCxNQUFNSyxVQUFXLElBQUUsaUJBSHhEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFNQSxLQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFRQSxLQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFVQTtBQUFBLFNBdEJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0F1QkEsS0F4QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXlCQTtBQUFBLElBQ0EsdUJBQUMsUUFDQyxpQ0FBQyxPQUFFO0FBQUE7QUFBQSxNQUFRTCxNQUFNRyxjQUFjQyxJQUFJSixNQUFNSyxVQUFVLEdBQUdhO0FBQUFBLFNBQXREO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBNEQsS0FEOUQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsSUFDQSx1QkFBQyxRQUNDLGlDQUFDLFdBQ0M7QUFBQSw2QkFBQyxRQUNDLGlDQUFDLFFBQ0MsaUNBQUMsWUFDQyxJQUFHLFlBQ0gsU0FBUyxNQUFNSCxRQUFRLEdBQ3ZCLGNBQWEsc0JBQXFCZixNQUFNSyxVQUFXLElBQUUsaUJBSHZEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFNQSxLQVBGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFRQSxLQVRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFVQTtBQUFBLE1BQ0EsdUJBQUMsUUFDQyxpQ0FBQyxRQUNDLGlDQUFDLFlBQ0MsSUFBRyxjQUNILFNBQVMsTUFBTVksVUFBVSxHQUN6QixjQUFhLHNCQUFxQmpCLE1BQU1LLFVBQVcsSUFBRSxpQkFIdkQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU1BLEtBUEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVFBLEtBVEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVVBO0FBQUEsU0F0QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQXVCQSxLQXhCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBeUJBO0FBQUEsT0ExREY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQTJEQSxLQTVERjtBQUFBO0FBQUE7QUFBQTtBQUFBLFNBNkRBLEtBOURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0ErREE7QUFFSjtBQUFDYyxLQTNIZXBCO0FBQWdCLElBQUFvQjtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsicmVzZXROdW0iLCJQcmVmZXJlbmNlVGlja2VyIiwicHJvcHMiLCJ1cFdlaWdodCIsImN1cnJlbnRQcmVmIiwicHJlZmVyZW5jZU1hcCIsImdldCIsInByZWZlcmVuY2UiLCJ1bmRlZmluZWQiLCJjb25zb2xlIiwiZXJyb3IiLCJ3ZWlnaHQiLCJuZXdNYXAiLCJNYXAiLCJzZXRQcmVmZXJlbmNlTWFwIiwic2V0UmVzZXQiLCJkb3duV2VpZ2h0IiwidXBWYWx1ZSIsInZhbHVlSnVtcCIsImRvd25WYWx1ZSIsInZhbHVlIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJQcmVmZXJlbmNlVGlja2VyLnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgXCIuLi8uLi9zdHlsZXMvbWFpbi5jc3NcIjtcbmltcG9ydCB7IERpc3BhdGNoLCBTZXRTdGF0ZUFjdGlvbiwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcbmltcG9ydCB7IFByZWZlcmVuY2VBbmRWYWx1ZSB9IGZyb20gXCIuL1ByZWZlcmVuY2VzXCI7XG5cbi8vIFByb3BlcnRpZXMgZm9yIHRoZSBQcmVmZXJlbmNlVGlja2VyIGNvbXBvbmVudC5cbmludGVyZmFjZSBQcmVmZXJlbmNlVGlja2VyUHJvcHMge1xuICBwcmVmZXJlbmNlTWFwOiBNYXA8c3RyaW5nLCBQcmVmZXJlbmNlQW5kVmFsdWU+O1xuICBzZXRQcmVmZXJlbmNlTWFwOiBEaXNwYXRjaDxTZXRTdGF0ZUFjdGlvbjxNYXA8c3RyaW5nLCBQcmVmZXJlbmNlQW5kVmFsdWU+Pj47XG4gIHNldFJlc2V0OiBEaXNwYXRjaDxudW1iZXI+O1xuICBwcmVmZXJlbmNlOiBzdHJpbmc7XG4gIHZhbHVlSnVtcDogbnVtYmVyO1xufVxuXG52YXIgcmVzZXROdW0gPSAxO1xuXG4vKipcbiAqIEFsbG93cyB1c2VycyB0byBpbmNyZWFzZSBvciBkZWNyZWFzZSB0aGUgd2VpZ2h0IGFuZCB2YWx1ZSBvZiBhIHBhcnRpY3VsYXIgcHJlZmVyZW5jZS5cbiAqIFJlbmRlcnMgYSBzZXQgb2YgY29udHJvbHMgZm9yIGFkanVzdGluZyB0aGVzZSBhdHRyaWJ1dGVzIGFzc29jaWF0ZWQgd2l0aCBhIHVzZXIncyBwcmVmZXJlbmNlLlxuICovXG5leHBvcnQgZnVuY3Rpb24gUHJlZmVyZW5jZVRpY2tlcihwcm9wczogUHJlZmVyZW5jZVRpY2tlclByb3BzKSB7XG4gIC8vIE1hbmFnZXMgdGhlIHVwIGFycm93LiBJbmNyZWFzZXMgdGhlIGNvdW50IGJ5IDEgaWYgaXQgaXNuJ3QgYXQgdGhlIG1heCB2YWx1ZSBhbHJlYWR5LlxuICBmdW5jdGlvbiB1cFdlaWdodCgpIHtcbiAgICB2YXIgY3VycmVudFByZWYgPSBwcm9wcy5wcmVmZXJlbmNlTWFwLmdldChwcm9wcy5wcmVmZXJlbmNlKTtcbiAgICBpZiAoY3VycmVudFByZWYgPT09IHVuZGVmaW5lZCkge1xuICAgICAgdGhyb3cgY29uc29sZS5lcnJvcigpO1xuICAgIH1cbiAgICBpZiAoY3VycmVudFByZWYud2VpZ2h0IDwgMTApIHtcbiAgICAgIGNvbnN0IG5ld01hcCA9IG5ldyBNYXAocHJvcHMucHJlZmVyZW5jZU1hcCk7XG4gICAgICBuZXdNYXAuZ2V0KHByb3BzLnByZWZlcmVuY2UpPy51cFdlaWdodCgpO1xuICAgICAgcHJvcHMuc2V0UHJlZmVyZW5jZU1hcChuZXdNYXApO1xuICAgIH1cbiAgICBwcm9wcy5zZXRSZXNldChyZXNldE51bSk7XG4gICAgcmVzZXROdW0gKz0gMTtcbiAgfVxuXG4gIC8vIE1hbmFnZXMgdGhlIGRvd24gYXJyb3cuIERlY3JlYXNlcyB0aGUgY291bnQgYnkgMSBpZiBpdCBpc24ndCBhdCB0aGUgbWF4LlxuICBmdW5jdGlvbiBkb3duV2VpZ2h0KCkge1xuICAgIHZhciBjdXJyZW50UHJlZiA9IHByb3BzLnByZWZlcmVuY2VNYXAuZ2V0KHByb3BzLnByZWZlcmVuY2UpO1xuICAgIGlmIChjdXJyZW50UHJlZiA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICB0aHJvdyBjb25zb2xlLmVycm9yKCk7XG4gICAgfVxuICAgIGlmIChjdXJyZW50UHJlZi53ZWlnaHQgPiAwKSB7XG4gICAgICBjb25zdCBuZXdNYXAgPSBuZXcgTWFwKHByb3BzLnByZWZlcmVuY2VNYXApO1xuICAgICAgbmV3TWFwLmdldChwcm9wcy5wcmVmZXJlbmNlKT8uZG93bldlaWdodCgpO1xuICAgICAgcHJvcHMuc2V0UHJlZmVyZW5jZU1hcChuZXdNYXApO1xuICAgIH1cbiAgICBwcm9wcy5zZXRSZXNldChyZXNldE51bSk7XG4gICAgcmVzZXROdW0gKz0gMTtcbiAgfVxuXG4gIC8vIE1hbmFnZXMgdGhlIHVwIGFycm93LiBJbmNyZWFzZXMgdGhlIGNvdW50IGJ5IDEgaWYgaXQgaXNuJ3QgYXQgdGhlIG1heFxuICBmdW5jdGlvbiB1cFZhbHVlKCkge1xuICAgIHZhciBjdXJyZW50UHJlZiA9IHByb3BzLnByZWZlcmVuY2VNYXAuZ2V0KHByb3BzLnByZWZlcmVuY2UpO1xuICAgIGlmIChjdXJyZW50UHJlZiA9PT0gdW5kZWZpbmVkKSB7XG4gICAgICB0aHJvdyBjb25zb2xlLmVycm9yKCk7XG4gICAgfVxuICAgIGNvbnN0IG5ld01hcCA9IG5ldyBNYXAocHJvcHMucHJlZmVyZW5jZU1hcCk7XG4gICAgbmV3TWFwLmdldChwcm9wcy5wcmVmZXJlbmNlKT8udXBWYWx1ZShwcm9wcy52YWx1ZUp1bXApO1xuICAgIHByb3BzLnNldFByZWZlcmVuY2VNYXAobmV3TWFwKTtcbiAgICBwcm9wcy5zZXRSZXNldChyZXNldE51bSk7XG4gICAgcmVzZXROdW0gKz0gMTtcbiAgfVxuXG4gIC8vIE1hbmFnZXMgdGhlIGRvd24gYXJyb3cuIERlY3JlYXNlcyB0aGUgY291bnQgYnkgMSBpZiBpdCBpc24ndCBhdCB0aGUgbWF4XG4gIGZ1bmN0aW9uIGRvd25WYWx1ZSgpIHtcbiAgICB2YXIgY3VycmVudFByZWYgPSBwcm9wcy5wcmVmZXJlbmNlTWFwLmdldChwcm9wcy5wcmVmZXJlbmNlKTtcbiAgICBpZiAoY3VycmVudFByZWYgPT09IHVuZGVmaW5lZCkge1xuICAgICAgdGhyb3cgY29uc29sZS5lcnJvcigpO1xuICAgIH1cbiAgICBjb25zdCBuZXdNYXAgPSBuZXcgTWFwKHByb3BzLnByZWZlcmVuY2VNYXApO1xuICAgIG5ld01hcC5nZXQocHJvcHMucHJlZmVyZW5jZSk/LmRvd25WYWx1ZShwcm9wcy52YWx1ZUp1bXApO1xuICAgIHByb3BzLnNldFByZWZlcmVuY2VNYXAobmV3TWFwKTtcbiAgICBwcm9wcy5zZXRSZXNldChyZXNldE51bSk7XG4gICAgcmVzZXROdW0gKz0gMTtcbiAgfVxuXG4gIHJldHVybiAoXG4gICAgPGRpdj5cbiAgICAgIDx0YWJsZT5cbiAgICAgICAgPHRyPlxuICAgICAgICAgIDx0ZD5cbiAgICAgICAgICAgIDxwPldlaWdodDoge3Byb3BzLnByZWZlcmVuY2VNYXAuZ2V0KHByb3BzLnByZWZlcmVuY2UpPy53ZWlnaHR9PC9wPlxuICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgPHRkPlxuICAgICAgICAgICAgPHRhYmxlPlxuICAgICAgICAgICAgICA8dHI+XG4gICAgICAgICAgICAgICAgPHRkPlxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICBpZD1cInVwQnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gdXBXZWlnaHQoKX1cbiAgICAgICAgICAgICAgICAgICAgYXJpYS1sYWJlbD17YEluY3JlYXNlIHdlaWdodCBmb3IgJHtwcm9wcy5wcmVmZXJlbmNlfWB9XG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIF5cbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICAgIDx0cj5cbiAgICAgICAgICAgICAgICA8dGQ+XG4gICAgICAgICAgICAgICAgICA8YnV0dG9uXG4gICAgICAgICAgICAgICAgICAgIGlkPVwiZG93bkJ1dHRvblwiXG4gICAgICAgICAgICAgICAgICAgIG9uQ2xpY2s9eygpID0+IGRvd25XZWlnaHQoKX1cbiAgICAgICAgICAgICAgICAgICAgYXJpYS1sYWJlbD17YERlY3JlYXNlIHdlaWdodCBmb3IgJHtwcm9wcy5wcmVmZXJlbmNlfWB9XG4gICAgICAgICAgICAgICAgICA+XG4gICAgICAgICAgICAgICAgICAgIHZcbiAgICAgICAgICAgICAgICAgIDwvYnV0dG9uPlxuICAgICAgICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgICAgIDwvdHI+XG4gICAgICAgICAgICA8L3RhYmxlPlxuICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgPHRkPlxuICAgICAgICAgICAgPHA+VmFsdWU6IHtwcm9wcy5wcmVmZXJlbmNlTWFwLmdldChwcm9wcy5wcmVmZXJlbmNlKT8udmFsdWV9PC9wPlxuICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgPHRkPlxuICAgICAgICAgICAgPHRhYmxlPlxuICAgICAgICAgICAgICA8dHI+XG4gICAgICAgICAgICAgICAgPHRkPlxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICBpZD1cInVwQnV0dG9uXCJcbiAgICAgICAgICAgICAgICAgICAgb25DbGljaz17KCkgPT4gdXBWYWx1ZSgpfVxuICAgICAgICAgICAgICAgICAgICBhcmlhLWxhYmVsPXtgSW5jcmVhc2UgdmFsdWUgZm9yICR7cHJvcHMucHJlZmVyZW5jZX1gfVxuICAgICAgICAgICAgICAgICAgPlxuICAgICAgICAgICAgICAgICAgICBeXG4gICAgICAgICAgICAgICAgICA8L2J1dHRvbj5cbiAgICAgICAgICAgICAgICA8L3RkPlxuICAgICAgICAgICAgICA8L3RyPlxuICAgICAgICAgICAgICA8dHI+XG4gICAgICAgICAgICAgICAgPHRkPlxuICAgICAgICAgICAgICAgICAgPGJ1dHRvblxuICAgICAgICAgICAgICAgICAgICBpZD1cImRvd25CdXR0b25cIlxuICAgICAgICAgICAgICAgICAgICBvbkNsaWNrPXsoKSA9PiBkb3duVmFsdWUoKX1cbiAgICAgICAgICAgICAgICAgICAgYXJpYS1sYWJlbD17YERlY3JlYXNlIHZhbHVlIGZvciAke3Byb3BzLnByZWZlcmVuY2V9YH1cbiAgICAgICAgICAgICAgICAgID5cbiAgICAgICAgICAgICAgICAgICAgdlxuICAgICAgICAgICAgICAgICAgPC9idXR0b24+XG4gICAgICAgICAgICAgICAgPC90ZD5cbiAgICAgICAgICAgICAgPC90cj5cbiAgICAgICAgICAgIDwvdGFibGU+XG4gICAgICAgICAgPC90ZD5cbiAgICAgICAgPC90cj5cbiAgICAgIDwvdGFibGU+XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9hdXN0aW53aWxsaWFtcy9Eb2N1bWVudHMvU2Nob29sL3RoaXJkU2VtZXN0ZXIvQ1MzMi90ZXJtLXByb2plY3QtdGJ6aGFvLXRwZXp6YS1zbXNjaHVjaC1id2lsbGk0OC9Gcm9udGVuZC9za2kvc3JjL2NvbXBvbmVudHMvcHJlZnMvUHJlZmVyZW5jZVRpY2tlci50c3gifQ==