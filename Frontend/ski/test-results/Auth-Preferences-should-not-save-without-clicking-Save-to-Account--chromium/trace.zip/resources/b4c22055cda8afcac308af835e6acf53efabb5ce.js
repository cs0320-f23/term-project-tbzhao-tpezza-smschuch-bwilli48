import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/prefs/Preferences.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=36ac7ba8"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=36ac7ba8"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import { PreferenceTicker } from "/src/components/prefs/PreferenceTicker.tsx";
import { getMockRankedResorts, getRankedResorts } from "/src/components/resorts/ResortClass.tsx";
import "/src/styles/main.css";
export class PreferenceAndValue {
  constructor(weight, value) {
    this.weight = weight;
    this.value = value;
  }
  upWeight() {
    this.weight += 1;
  }
  downWeight() {
    this.weight -= 1;
  }
  upValue(jump) {
    this.value += jump;
  }
  downValue(jump) {
    this.value -= jump;
  }
}
export function Preferences(props) {
  _s();
  var initialPrefs = /* @__PURE__ */ new Map([["Snowfall Amount", new PreferenceAndValue(5, 6)], ["Last Snowfall", new PreferenceAndValue(5, 2)], ["Base-depth", new PreferenceAndValue(5, 40)], ["Price", new PreferenceAndValue(5, 110)], ["Lifts Open", new PreferenceAndValue(5, 6)], ["Summit Elevation", new PreferenceAndValue(5, 9e3)], ["Temperature", new PreferenceAndValue(5, 25)], ["Windspeed", new PreferenceAndValue(5, 10)]]);
  const convertUserPrefsToMap = (userPrefs) => {
    const map = /* @__PURE__ */ new Map();
    if (userPrefs) {
      userPrefs.forEach((prefItem, key) => {
        map.set(key, new PreferenceAndValue(prefItem.weight, prefItem.value));
      });
    } else {
      initialPrefs.forEach((value, key) => {
        map.set(key, new PreferenceAndValue(value.weight, value.value));
      });
    }
    return map;
  };
  const [preferenceMap, setPreferenceMap] = useState(() => convertUserPrefsToMap(props.preferences));
  const [reset, setReset] = useState(0);
  function handlePrefSearch() {
    if (props.mockMode) {
      props.setResortList(getMockRankedResorts(preferenceMap));
    } else {
      props.setResortList(getRankedResorts(preferenceMap));
    }
  }
  const handleSaveClick = () => {
    const updatedPreferences = new Map(preferenceMap);
    props.onSavePreferences(updatedPreferences);
  };
  useEffect(() => {
    if (props.preferences !== null) {
      setPreferenceMap(convertUserPrefsToMap(props.preferences));
    }
  }, [props.preferences]);
  return /* @__PURE__ */ jsxDEV("div", { className: "preferences-container", children: [
    /* @__PURE__ */ jsxDEV("div", { className: "preferences-header", children: [
      /* @__PURE__ */ jsxDEV("h2", { children: "Preferences" }, void 0, false, {
        fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
        lineNumber: 110,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("button", { id: "savePreferencesButton", onClick: handleSaveClick, "aria-label": "Save preferences to your account", children: "Save to Account" }, void 0, false, {
        fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
        lineNumber: 111,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
      lineNumber: 109,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("table", { id: "prefTable", children: [
      /* @__PURE__ */ jsxDEV("tr", { children: [
        /* @__PURE__ */ jsxDEV("td", { children: /* @__PURE__ */ jsxDEV("h4", { children: "Snowfall Amount" }, void 0, false, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
          lineNumber: 118,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
          lineNumber: 117,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("td", { children: /* @__PURE__ */ jsxDEV(PreferenceTicker, { preferenceMap, setPreferenceMap, preference: "Snowfall Amount", setReset, valueJump: 1 }, void 0, false, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
          lineNumber: 121,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
          lineNumber: 120,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("td", { className: "spacerDatum" }, void 0, false, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
          lineNumber: 123,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("td", { children: /* @__PURE__ */ jsxDEV("h4", { children: "Last Snowfall" }, void 0, false, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
          lineNumber: 125,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
          lineNumber: 124,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("td", { children: /* @__PURE__ */ jsxDEV(PreferenceTicker, { preferenceMap, setPreferenceMap, preference: "Last Snowfall", setReset, valueJump: 1 }, void 0, false, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
          lineNumber: 128,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
          lineNumber: 127,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
        lineNumber: 116,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("tr", { children: [
        /* @__PURE__ */ jsxDEV("td", { children: /* @__PURE__ */ jsxDEV("h4", { children: "Base-depth" }, void 0, false, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
          lineNumber: 133,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
          lineNumber: 132,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("td", { children: /* @__PURE__ */ jsxDEV(PreferenceTicker, { preferenceMap, setPreferenceMap, preference: "Base-depth", setReset, valueJump: 5 }, void 0, false, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
          lineNumber: 136,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
          lineNumber: 135,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("td", { className: "spacerDatum" }, void 0, false, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
          lineNumber: 138,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("td", { children: /* @__PURE__ */ jsxDEV("h4", { children: "Price" }, void 0, false, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
          lineNumber: 140,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
          lineNumber: 139,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("td", { children: /* @__PURE__ */ jsxDEV(PreferenceTicker, { preferenceMap, setPreferenceMap, preference: "Price", setReset, valueJump: 5 }, void 0, false, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
          lineNumber: 143,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
          lineNumber: 142,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
        lineNumber: 131,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("tr", { children: [
        /* @__PURE__ */ jsxDEV("td", { children: /* @__PURE__ */ jsxDEV("h4", { children: "Lifts Open" }, void 0, false, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
          lineNumber: 148,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
          lineNumber: 147,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("td", { children: /* @__PURE__ */ jsxDEV(PreferenceTicker, { preferenceMap, setPreferenceMap, preference: "Lifts Open", setReset, valueJump: 1 }, void 0, false, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
          lineNumber: 151,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
          lineNumber: 150,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("td", { className: "spacerDatum" }, void 0, false, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
          lineNumber: 153,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("td", { children: /* @__PURE__ */ jsxDEV("h4", { children: "Summit Elevation" }, void 0, false, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
          lineNumber: 155,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
          lineNumber: 154,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("td", { children: /* @__PURE__ */ jsxDEV(PreferenceTicker, { preferenceMap, setPreferenceMap, preference: "Summit Elevation", setReset, valueJump: 100 }, void 0, false, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
          lineNumber: 158,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
          lineNumber: 157,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
        lineNumber: 146,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("tr", { children: [
        /* @__PURE__ */ jsxDEV("td", { children: /* @__PURE__ */ jsxDEV("h4", { children: "Temperature" }, void 0, false, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
          lineNumber: 163,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
          lineNumber: 162,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("td", { children: /* @__PURE__ */ jsxDEV(PreferenceTicker, { preferenceMap, setPreferenceMap, preference: "Temperature", setReset, valueJump: 1 }, void 0, false, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
          lineNumber: 166,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
          lineNumber: 165,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("td", { className: "spacerDatum" }, void 0, false, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
          lineNumber: 168,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("td", { children: /* @__PURE__ */ jsxDEV("h4", { children: "Windspeed" }, void 0, false, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
          lineNumber: 170,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
          lineNumber: 169,
          columnNumber: 11
        }, this),
        /* @__PURE__ */ jsxDEV("td", { children: /* @__PURE__ */ jsxDEV(PreferenceTicker, { preferenceMap, setPreferenceMap, preference: "Windspeed", setReset, valueJump: 1 }, void 0, false, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
          lineNumber: 173,
          columnNumber: 13
        }, this) }, void 0, false, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
          lineNumber: 172,
          columnNumber: 11
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
        lineNumber: 161,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
      lineNumber: 115,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("button", { id: "preferenceButton", onClick: () => handlePrefSearch(), "aria-label": "Search resorts based on preferences", children: "Search By Preferences" }, void 0, false, {
      fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
      lineNumber: 177,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx",
    lineNumber: 108,
    columnNumber: 10
  }, this);
}
_s(Preferences, "g5sj29SDQb10w5r8hsOHVkMSKHk=");
_c = Preferences;
var _c;
$RefreshReg$(_c, "Preferences");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/prefs/Preferences.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBK0hROzs7Ozs7Ozs7Ozs7Ozs7OztBQS9IUixTQUFtQ0EsVUFBVUMsaUJBQWlCO0FBQzlELFNBQVNDLHdCQUF3QjtBQUNqQyxTQUNFQyxzQkFDQUMsd0JBRUs7QUFDUCxPQUFPO0FBbUJBLGFBQU1DLG1CQUFtQjtBQUFBLEVBSTlCQyxZQUFZQyxRQUFnQkMsT0FBZTtBQUN6QyxTQUFLRCxTQUFTQTtBQUNkLFNBQUtDLFFBQVFBO0FBQUFBLEVBQ2Y7QUFBQSxFQUNBQyxXQUFXO0FBQ1QsU0FBS0YsVUFBVTtBQUFBLEVBQ2pCO0FBQUEsRUFDQUcsYUFBYTtBQUNYLFNBQUtILFVBQVU7QUFBQSxFQUNqQjtBQUFBLEVBQ0FJLFFBQVFDLE1BQWM7QUFDcEIsU0FBS0osU0FBU0k7QUFBQUEsRUFDaEI7QUFBQSxFQUNBQyxVQUFVRCxNQUFjO0FBQ3RCLFNBQUtKLFNBQVNJO0FBQUFBLEVBQ2hCO0FBQ0Y7QUFNTyxnQkFBU0UsWUFBWUMsT0FBeUI7QUFBQUMsS0FBQTtBQUVuRCxNQUFJQyxlQUFlLG9CQUFJQyxJQUFnQyxDQUNyRCxDQUFDLG1CQUFtQixJQUFJYixtQkFBbUIsR0FBRyxDQUFDLENBQUMsR0FDaEQsQ0FBQyxpQkFBaUIsSUFBSUEsbUJBQW1CLEdBQUcsQ0FBQyxDQUFDLEdBQzlDLENBQUMsY0FBYyxJQUFJQSxtQkFBbUIsR0FBRyxFQUFFLENBQUMsR0FDNUMsQ0FBQyxTQUFTLElBQUlBLG1CQUFtQixHQUFHLEdBQUcsQ0FBQyxHQUN4QyxDQUFDLGNBQWMsSUFBSUEsbUJBQW1CLEdBQUcsQ0FBQyxDQUFDLEdBQzNDLENBQUMsb0JBQW9CLElBQUlBLG1CQUFtQixHQUFHLEdBQUksQ0FBQyxHQUNwRCxDQUFDLGVBQWUsSUFBSUEsbUJBQW1CLEdBQUcsRUFBRSxDQUFDLEdBQzdDLENBQUMsYUFBYSxJQUFJQSxtQkFBbUIsR0FBRyxFQUFFLENBQUMsQ0FBQyxDQUM3QztBQU9ELFFBQU1jLHdCQUF3QkEsQ0FDNUJDLGNBQ29DO0FBQ3BDLFVBQU1DLE1BQU0sb0JBQUlILElBQWdDO0FBQ2hELFFBQUlFLFdBQVc7QUFDYkEsZ0JBQVVFLFFBQVEsQ0FBQ0MsVUFBVUMsUUFBUTtBQUNuQ0gsWUFBSUksSUFBSUQsS0FBSyxJQUFJbkIsbUJBQW1Ca0IsU0FBU2hCLFFBQVFnQixTQUFTZixLQUFLLENBQUM7QUFBQSxNQUN0RSxDQUFDO0FBQUEsSUFDSCxPQUFPO0FBRUxTLG1CQUFhSyxRQUFRLENBQUNkLE9BQU9nQixRQUFRO0FBQ25DSCxZQUFJSSxJQUFJRCxLQUFLLElBQUluQixtQkFBbUJHLE1BQU1ELFFBQVFDLE1BQU1BLEtBQUssQ0FBQztBQUFBLE1BQ2hFLENBQUM7QUFBQSxJQUNIO0FBQ0EsV0FBT2E7QUFBQUEsRUFDVDtBQUdBLFFBQU0sQ0FBQ0ssZUFBZUMsZ0JBQWdCLElBQUkzQixTQUV4QyxNQUFNbUIsc0JBQXNCSixNQUFNYSxXQUFXLENBQUM7QUFHaEQsUUFBTSxDQUFDQyxPQUFPQyxRQUFRLElBQUk5QixTQUFpQixDQUFDO0FBSzVDLFdBQVMrQixtQkFBbUI7QUFDMUIsUUFBSWhCLE1BQU1pQixVQUFVO0FBQ2xCakIsWUFBTWtCLGNBQWM5QixxQkFBcUJ1QixhQUFhLENBQUM7QUFBQSxJQUN6RCxPQUFPO0FBQ0xYLFlBQU1rQixjQUFjN0IsaUJBQWlCc0IsYUFBYSxDQUFDO0FBQUEsSUFDckQ7QUFBQSxFQUNGO0FBTUEsUUFBTVEsa0JBQWtCQSxNQUFNO0FBQzVCLFVBQU1DLHFCQUFzQyxJQUFJakIsSUFBSVEsYUFBYTtBQUNqRVgsVUFBTXFCLGtCQUFrQkQsa0JBQWtCO0FBQUEsRUFDNUM7QUFLQWxDLFlBQVUsTUFBTTtBQUNkLFFBQUljLE1BQU1hLGdCQUFnQixNQUFNO0FBQzlCRCx1QkFBaUJSLHNCQUFzQkosTUFBTWEsV0FBVyxDQUFDO0FBQUEsSUFDM0Q7QUFBQSxFQUNGLEdBQUcsQ0FBQ2IsTUFBTWEsV0FBVyxDQUFDO0FBRXRCLFNBQ0UsdUJBQUMsU0FBSSxXQUFVLHlCQUNiO0FBQUEsMkJBQUMsU0FBSSxXQUFVLHNCQUNiO0FBQUEsNkJBQUMsUUFBRywyQkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBQWU7QUFBQSxNQUNmLHVCQUFDLFlBQ0MsSUFBRyx5QkFDSCxTQUFTTSxpQkFDVCxjQUFXLG9DQUFrQywrQkFIL0M7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQU1BO0FBQUEsU0FSRjtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBU0E7QUFBQSxJQUNBLHVCQUFDLFdBQU0sSUFBRyxhQUNSO0FBQUEsNkJBQUMsUUFDQztBQUFBLCtCQUFDLFFBQ0MsaUNBQUMsUUFBRywrQkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQW1CLEtBRHJCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsUUFDQyxpQ0FBQyxvQkFDQyxlQUNBLGtCQUNBLFlBQVksbUJBQ1osVUFDQSxXQUFXLEtBTGI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtlLEtBTmpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFRQTtBQUFBLFFBQ0EsdUJBQUMsUUFBRyxXQUFVLGlCQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNEI7QUFBQSxRQUM1Qix1QkFBQyxRQUNDLGlDQUFDLFFBQUcsNkJBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFpQixLQURuQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLFFBQ0MsaUNBQUMsb0JBQ0MsZUFDQSxrQkFDQSxZQUFZLGlCQUNaLFVBQ0EsV0FBVyxLQUxiO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFLZSxLQU5qQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBUUE7QUFBQSxXQXpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBMEJBO0FBQUEsTUFDQSx1QkFBQyxRQUNDO0FBQUEsK0JBQUMsUUFDQyxpQ0FBQyxRQUFHLDBCQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBYyxLQURoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLFFBQ0MsaUNBQUMsb0JBQ0MsZUFDQSxrQkFDQSxZQUFZLGNBQ1osVUFDQSxXQUFXLEtBTGI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtlLEtBTmpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFRQTtBQUFBLFFBQ0EsdUJBQUMsUUFBRyxXQUFVLGlCQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNEI7QUFBQSxRQUM1Qix1QkFBQyxRQUNDLGlDQUFDLFFBQUcscUJBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFTLEtBRFg7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxRQUNDLGlDQUFDLG9CQUNDLGVBQ0Esa0JBQ0EsWUFBWSxTQUNaLFVBQ0EsV0FBVyxLQUxiO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFLZSxLQU5qQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBUUE7QUFBQSxXQXpCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBMEJBO0FBQUEsTUFDQSx1QkFBQyxRQUNDO0FBQUEsK0JBQUMsUUFDQyxpQ0FBQyxRQUFHLDBCQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBYyxLQURoQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLFFBQ0MsaUNBQUMsb0JBQ0MsZUFDQSxrQkFDQSxZQUFZLGNBQ1osVUFDQSxXQUFXLEtBTGI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtlLEtBTmpCO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFRQTtBQUFBLFFBQ0EsdUJBQUMsUUFBRyxXQUFVLGlCQUFkO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBNEI7QUFBQSxRQUM1Qix1QkFBQyxRQUNDLGlDQUFDLFFBQUcsZ0NBQUo7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUFvQixLQUR0QjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBRUE7QUFBQSxRQUNBLHVCQUFDLFFBQ0MsaUNBQUMsb0JBQ0MsZUFDQSxrQkFDQSxZQUFZLG9CQUNaLFVBQ0EsV0FBVyxPQUxiO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFLaUIsS0FObkI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVFBO0FBQUEsV0F6QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTBCQTtBQUFBLE1BQ0EsdUJBQUMsUUFDQztBQUFBLCtCQUFDLFFBQ0MsaUNBQUMsUUFBRywyQkFBSjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQWUsS0FEakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUVBO0FBQUEsUUFDQSx1QkFBQyxRQUNDLGlDQUFDLG9CQUNDLGVBQ0Esa0JBQ0EsWUFBWSxlQUNaLFVBQ0EsV0FBVyxLQUxiO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFLZSxLQU5qQjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBUUE7QUFBQSxRQUNBLHVCQUFDLFFBQUcsV0FBVSxpQkFBZDtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBQTRCO0FBQUEsUUFDNUIsdUJBQUMsUUFDQyxpQ0FBQyxRQUFHLHlCQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFBYSxLQURmO0FBQUE7QUFBQTtBQUFBO0FBQUEsZUFFQTtBQUFBLFFBQ0EsdUJBQUMsUUFDQyxpQ0FBQyxvQkFDQyxlQUNBLGtCQUNBLFlBQVksYUFDWixVQUNBLFdBQVcsS0FMYjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBS2UsS0FOakI7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQVFBO0FBQUEsV0F6QkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQTBCQTtBQUFBLFNBNUdGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0E2R0E7QUFBQSxJQUNBLHVCQUFDLFlBQ0MsSUFBRyxvQkFDSCxTQUFTLE1BQU1ILGlCQUFpQixHQUNoQyxjQUFXLHVDQUFxQyxxQ0FIbEQ7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQU1BO0FBQUEsT0EvSEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxTQWdJQTtBQUVKO0FBQUNmLEdBM01lRixhQUFXO0FBQUF1QixLQUFYdkI7QUFBVyxJQUFBdUI7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlRWZmZWN0IiwiUHJlZmVyZW5jZVRpY2tlciIsImdldE1vY2tSYW5rZWRSZXNvcnRzIiwiZ2V0UmFua2VkUmVzb3J0cyIsIlByZWZlcmVuY2VBbmRWYWx1ZSIsImNvbnN0cnVjdG9yIiwid2VpZ2h0IiwidmFsdWUiLCJ1cFdlaWdodCIsImRvd25XZWlnaHQiLCJ1cFZhbHVlIiwianVtcCIsImRvd25WYWx1ZSIsIlByZWZlcmVuY2VzIiwicHJvcHMiLCJfcyIsImluaXRpYWxQcmVmcyIsIk1hcCIsImNvbnZlcnRVc2VyUHJlZnNUb01hcCIsInVzZXJQcmVmcyIsIm1hcCIsImZvckVhY2giLCJwcmVmSXRlbSIsImtleSIsInNldCIsInByZWZlcmVuY2VNYXAiLCJzZXRQcmVmZXJlbmNlTWFwIiwicHJlZmVyZW5jZXMiLCJyZXNldCIsInNldFJlc2V0IiwiaGFuZGxlUHJlZlNlYXJjaCIsIm1vY2tNb2RlIiwic2V0UmVzb3J0TGlzdCIsImhhbmRsZVNhdmVDbGljayIsInVwZGF0ZWRQcmVmZXJlbmNlcyIsIm9uU2F2ZVByZWZlcmVuY2VzIiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJQcmVmZXJlbmNlcy50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgRGlzcGF0Y2gsIFNldFN0YXRlQWN0aW9uLCB1c2VTdGF0ZSwgdXNlRWZmZWN0IH0gZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgeyBQcmVmZXJlbmNlVGlja2VyIH0gZnJvbSBcIi4vUHJlZmVyZW5jZVRpY2tlclwiO1xuaW1wb3J0IHtcbiAgZ2V0TW9ja1JhbmtlZFJlc29ydHMsXG4gIGdldFJhbmtlZFJlc29ydHMsXG4gIFJlc29ydCxcbn0gZnJvbSBcIi4uL3Jlc29ydHMvUmVzb3J0Q2xhc3NcIjtcbmltcG9ydCBcIi4uLy4uL3N0eWxlcy9tYWluLmNzc1wiO1xuXG4vLyBQcm9wZXJ0aWVzIGZvciB0aGUgUHJlZmVyZW5jZXMgY29tcG9uZW50LlxuaW50ZXJmYWNlIFByZWZlcmVuY2VzUHJvcHMge1xuICByZXNvcnRMaXN0OiBSZXNvcnRbXTtcbiAgc2V0UmVzb3J0TGlzdDogRGlzcGF0Y2g8U2V0U3RhdGVBY3Rpb248UmVzb3J0W10+PjtcbiAgcHJlZmVyZW5jZXM6IFVzZXJQcmVmZXJlbmNlcyB8IG51bGw7XG4gIG9uU2F2ZVByZWZlcmVuY2VzOiAobmV3UHJlZmVyZW5jZXM6IFVzZXJQcmVmZXJlbmNlcykgPT4gdm9pZDtcbiAgbW9ja01vZGU6IGJvb2xlYW47XG59XG5cbi8vIFR5cGVzIHVzZWQgZm9yIGFjY291bnQgcHJlZmVyZW5jZSBzYXZpbmcuXG5leHBvcnQgdHlwZSBVc2VyUHJlZmVyZW5jZXMgPSBNYXA8c3RyaW5nLCBQcmVmZXJlbmNlSXRlbT47XG5leHBvcnQgdHlwZSBQcmVmZXJlbmNlSXRlbSA9IHtcbiAgd2VpZ2h0OiBudW1iZXI7XG4gIHZhbHVlOiBudW1iZXI7XG59O1xuXG4vLyBDbGFzcyByZXByZXNlbnRpbmcgYSB3ZWlnaHQtdmFsdWUgcGFpciBmb3IgYSBwcmVmZXJlbmNlLlxuZXhwb3J0IGNsYXNzIFByZWZlcmVuY2VBbmRWYWx1ZSB7XG4gIHdlaWdodDogbnVtYmVyO1xuICB2YWx1ZTogbnVtYmVyO1xuXG4gIGNvbnN0cnVjdG9yKHdlaWdodDogbnVtYmVyLCB2YWx1ZTogbnVtYmVyKSB7XG4gICAgdGhpcy53ZWlnaHQgPSB3ZWlnaHQ7XG4gICAgdGhpcy52YWx1ZSA9IHZhbHVlO1xuICB9XG4gIHVwV2VpZ2h0KCkge1xuICAgIHRoaXMud2VpZ2h0ICs9IDE7XG4gIH1cbiAgZG93bldlaWdodCgpIHtcbiAgICB0aGlzLndlaWdodCAtPSAxO1xuICB9XG4gIHVwVmFsdWUoanVtcDogbnVtYmVyKSB7XG4gICAgdGhpcy52YWx1ZSArPSBqdW1wO1xuICB9XG4gIGRvd25WYWx1ZShqdW1wOiBudW1iZXIpIHtcbiAgICB0aGlzLnZhbHVlIC09IGp1bXA7XG4gIH1cbn1cblxuLyoqXG4gKiBSZW5kZXJzIGEgdGFibGUgb2YgdXNlciBwcmVmZXJlbmNlcyByZWdhcmRpbmcgcmVzb3J0IGNvbmRpdGlvbnMuIFVzZXJzIGNhbiBhZGp1c3QgdGhlXG4gKiB3ZWlnaHQgYW5kIHZhbHVlIG9mIGVhY2ggcHJlZmVyZW5jZSwgd2hpY2ggaXMgdXNlZCB0byBzb3J0IHRoZSBsaXN0IG9mIHJlc29ydHMuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBQcmVmZXJlbmNlcyhwcm9wczogUHJlZmVyZW5jZXNQcm9wcykge1xuICAvLyBJbml0aWFsIHByZWZlcmVuY2VzIHRoYXQgYXJlIHNldCBmb3IgYSBuZXcgdXNlci5cbiAgdmFyIGluaXRpYWxQcmVmcyA9IG5ldyBNYXA8c3RyaW5nLCBQcmVmZXJlbmNlQW5kVmFsdWU+KFtcbiAgICBbXCJTbm93ZmFsbCBBbW91bnRcIiwgbmV3IFByZWZlcmVuY2VBbmRWYWx1ZSg1LCA2KV0sXG4gICAgW1wiTGFzdCBTbm93ZmFsbFwiLCBuZXcgUHJlZmVyZW5jZUFuZFZhbHVlKDUsIDIpXSxcbiAgICBbXCJCYXNlLWRlcHRoXCIsIG5ldyBQcmVmZXJlbmNlQW5kVmFsdWUoNSwgNDApXSxcbiAgICBbXCJQcmljZVwiLCBuZXcgUHJlZmVyZW5jZUFuZFZhbHVlKDUsIDExMCldLFxuICAgIFtcIkxpZnRzIE9wZW5cIiwgbmV3IFByZWZlcmVuY2VBbmRWYWx1ZSg1LCA2KV0sXG4gICAgW1wiU3VtbWl0IEVsZXZhdGlvblwiLCBuZXcgUHJlZmVyZW5jZUFuZFZhbHVlKDUsIDkwMDApXSxcbiAgICBbXCJUZW1wZXJhdHVyZVwiLCBuZXcgUHJlZmVyZW5jZUFuZFZhbHVlKDUsIDI1KV0sXG4gICAgW1wiV2luZHNwZWVkXCIsIG5ldyBQcmVmZXJlbmNlQW5kVmFsdWUoNSwgMTApXSxcbiAgXSk7XG5cbiAgLyoqXG4gICAqIENvbnZlcnRzIHRoZSBVc2VyUHJlZmVyZW5jZXMgb2JqZWN0IHRvIGEgbWFwIG9mIHN0cmluZyB0byBQcmVmZXJlbmNlQW5kVmFsdWUuXG4gICAqIEBwYXJhbSB1c2VyUHJlZnMgVGhlIFVzZXJQcmVmZXJlbmNlcyBvYmplY3QgdG8gY29udmVydC5cbiAgICogQHJldHVybnMgbWFwIHJlcHJlc2VudGluZyB0aGUgdXNlciBwcmVmZXJlbmNlcy5cbiAgICovXG4gIGNvbnN0IGNvbnZlcnRVc2VyUHJlZnNUb01hcCA9IChcbiAgICB1c2VyUHJlZnM6IFVzZXJQcmVmZXJlbmNlcyB8IG51bGxcbiAgKTogTWFwPHN0cmluZywgUHJlZmVyZW5jZUFuZFZhbHVlPiA9PiB7XG4gICAgY29uc3QgbWFwID0gbmV3IE1hcDxzdHJpbmcsIFByZWZlcmVuY2VBbmRWYWx1ZT4oKTtcbiAgICBpZiAodXNlclByZWZzKSB7XG4gICAgICB1c2VyUHJlZnMuZm9yRWFjaCgocHJlZkl0ZW0sIGtleSkgPT4ge1xuICAgICAgICBtYXAuc2V0KGtleSwgbmV3IFByZWZlcmVuY2VBbmRWYWx1ZShwcmVmSXRlbS53ZWlnaHQsIHByZWZJdGVtLnZhbHVlKSk7XG4gICAgICB9KTtcbiAgICB9IGVsc2Uge1xuICAgICAgLy8gUG9wdWxhdGUgbWFwIHdpdGggaW5pdGlhbCBwcmVmZXJlbmNlcyBpZiB1c2VyUHJlZnMgaXMgbnVsbFxuICAgICAgaW5pdGlhbFByZWZzLmZvckVhY2goKHZhbHVlLCBrZXkpID0+IHtcbiAgICAgICAgbWFwLnNldChrZXksIG5ldyBQcmVmZXJlbmNlQW5kVmFsdWUodmFsdWUud2VpZ2h0LCB2YWx1ZS52YWx1ZSkpO1xuICAgICAgfSk7XG4gICAgfVxuICAgIHJldHVybiBtYXA7XG4gIH07XG5cbiAgLy8gU3RhdGUgZm9yIHRoZSBwcmVmZXJlbmNlIG1hcC5cbiAgY29uc3QgW3ByZWZlcmVuY2VNYXAsIHNldFByZWZlcmVuY2VNYXBdID0gdXNlU3RhdGU8XG4gICAgTWFwPHN0cmluZywgUHJlZmVyZW5jZUFuZFZhbHVlPlxuICA+KCgpID0+IGNvbnZlcnRVc2VyUHJlZnNUb01hcChwcm9wcy5wcmVmZXJlbmNlcykpO1xuXG4gIC8vIFN0YXRlIGZvciB0aGUgcmVzZXQgb2JqZWN0LlxuICBjb25zdCBbcmVzZXQsIHNldFJlc2V0XSA9IHVzZVN0YXRlPG51bWJlcj4oMCk7XG5cbiAgLyoqXG4gICAqIFVwZGF0ZXMgdGhlIHJlc29ydCBsaXN0IGJhc2VkIG9uIGEgdXNlcidzIGN1c3RvbSBwcmVmZXJlbmNlcy5cbiAgICovXG4gIGZ1bmN0aW9uIGhhbmRsZVByZWZTZWFyY2goKSB7XG4gICAgaWYgKHByb3BzLm1vY2tNb2RlKSB7XG4gICAgICBwcm9wcy5zZXRSZXNvcnRMaXN0KGdldE1vY2tSYW5rZWRSZXNvcnRzKHByZWZlcmVuY2VNYXApKTtcbiAgICB9IGVsc2Uge1xuICAgICAgcHJvcHMuc2V0UmVzb3J0TGlzdChnZXRSYW5rZWRSZXNvcnRzKHByZWZlcmVuY2VNYXApKTtcbiAgICB9XG4gIH1cblxuICAvKipcbiAgICogSGFuZGxlcyBzYXZpbmcgdGhlIGN1cnJlbnQgc3RhdGUgb2YgdXNlciBwcmVmZXJlbmNlcy4gVHJpZ2dlcmVkIHdoZW4gdGhlXG4gICAqICdTYXZlIHRvIEFjY291bnQnIGJ1dHRvbiBpcyBjbGlja2VkLlxuICAgKi9cbiAgY29uc3QgaGFuZGxlU2F2ZUNsaWNrID0gKCkgPT4ge1xuICAgIGNvbnN0IHVwZGF0ZWRQcmVmZXJlbmNlczogVXNlclByZWZlcmVuY2VzID0gbmV3IE1hcChwcmVmZXJlbmNlTWFwKTtcbiAgICBwcm9wcy5vblNhdmVQcmVmZXJlbmNlcyh1cGRhdGVkUHJlZmVyZW5jZXMpO1xuICB9O1xuXG4gIC8qKlxuICAgKiB1c2VFZmZlY3QgaG9vayB0byB1cGRhdGUgdGhlIHByZWZlcmVuY2VNYXAgc3RhdGUgd2hlbmV2ZXIgdGhlIHByb3BzLnByZWZlcmVuY2VzIGNoYW5nZXMuXG4gICAqL1xuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChwcm9wcy5wcmVmZXJlbmNlcyAhPT0gbnVsbCkge1xuICAgICAgc2V0UHJlZmVyZW5jZU1hcChjb252ZXJ0VXNlclByZWZzVG9NYXAocHJvcHMucHJlZmVyZW5jZXMpKTtcbiAgICB9XG4gIH0sIFtwcm9wcy5wcmVmZXJlbmNlc10pO1xuXG4gIHJldHVybiAoXG4gICAgPGRpdiBjbGFzc05hbWU9XCJwcmVmZXJlbmNlcy1jb250YWluZXJcIj5cbiAgICAgIDxkaXYgY2xhc3NOYW1lPVwicHJlZmVyZW5jZXMtaGVhZGVyXCI+XG4gICAgICAgIDxoMj5QcmVmZXJlbmNlczwvaDI+XG4gICAgICAgIDxidXR0b25cbiAgICAgICAgICBpZD1cInNhdmVQcmVmZXJlbmNlc0J1dHRvblwiXG4gICAgICAgICAgb25DbGljaz17aGFuZGxlU2F2ZUNsaWNrfVxuICAgICAgICAgIGFyaWEtbGFiZWw9XCJTYXZlIHByZWZlcmVuY2VzIHRvIHlvdXIgYWNjb3VudFwiXG4gICAgICAgID5cbiAgICAgICAgICBTYXZlIHRvIEFjY291bnRcbiAgICAgICAgPC9idXR0b24+XG4gICAgICA8L2Rpdj5cbiAgICAgIDx0YWJsZSBpZD1cInByZWZUYWJsZVwiPlxuICAgICAgICA8dHI+XG4gICAgICAgICAgPHRkPlxuICAgICAgICAgICAgPGg0PlNub3dmYWxsIEFtb3VudDwvaDQ+XG4gICAgICAgICAgPC90ZD5cbiAgICAgICAgICA8dGQ+XG4gICAgICAgICAgICA8UHJlZmVyZW5jZVRpY2tlclxuICAgICAgICAgICAgICBwcmVmZXJlbmNlTWFwPXtwcmVmZXJlbmNlTWFwfVxuICAgICAgICAgICAgICBzZXRQcmVmZXJlbmNlTWFwPXtzZXRQcmVmZXJlbmNlTWFwfVxuICAgICAgICAgICAgICBwcmVmZXJlbmNlPXtcIlNub3dmYWxsIEFtb3VudFwifVxuICAgICAgICAgICAgICBzZXRSZXNldD17c2V0UmVzZXR9XG4gICAgICAgICAgICAgIHZhbHVlSnVtcD17MX1cbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgPC90ZD5cbiAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwic3BhY2VyRGF0dW1cIj48L3RkPlxuICAgICAgICAgIDx0ZD5cbiAgICAgICAgICAgIDxoND5MYXN0IFNub3dmYWxsPC9oND5cbiAgICAgICAgICA8L3RkPlxuICAgICAgICAgIDx0ZD5cbiAgICAgICAgICAgIDxQcmVmZXJlbmNlVGlja2VyXG4gICAgICAgICAgICAgIHByZWZlcmVuY2VNYXA9e3ByZWZlcmVuY2VNYXB9XG4gICAgICAgICAgICAgIHNldFByZWZlcmVuY2VNYXA9e3NldFByZWZlcmVuY2VNYXB9XG4gICAgICAgICAgICAgIHByZWZlcmVuY2U9e1wiTGFzdCBTbm93ZmFsbFwifVxuICAgICAgICAgICAgICBzZXRSZXNldD17c2V0UmVzZXR9XG4gICAgICAgICAgICAgIHZhbHVlSnVtcD17MX1cbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgPC90ZD5cbiAgICAgICAgPC90cj5cbiAgICAgICAgPHRyPlxuICAgICAgICAgIDx0ZD5cbiAgICAgICAgICAgIDxoND5CYXNlLWRlcHRoPC9oND5cbiAgICAgICAgICA8L3RkPlxuICAgICAgICAgIDx0ZD5cbiAgICAgICAgICAgIDxQcmVmZXJlbmNlVGlja2VyXG4gICAgICAgICAgICAgIHByZWZlcmVuY2VNYXA9e3ByZWZlcmVuY2VNYXB9XG4gICAgICAgICAgICAgIHNldFByZWZlcmVuY2VNYXA9e3NldFByZWZlcmVuY2VNYXB9XG4gICAgICAgICAgICAgIHByZWZlcmVuY2U9e1wiQmFzZS1kZXB0aFwifVxuICAgICAgICAgICAgICBzZXRSZXNldD17c2V0UmVzZXR9XG4gICAgICAgICAgICAgIHZhbHVlSnVtcD17NX1cbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgPC90ZD5cbiAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwic3BhY2VyRGF0dW1cIj48L3RkPlxuICAgICAgICAgIDx0ZD5cbiAgICAgICAgICAgIDxoND5QcmljZTwvaDQ+XG4gICAgICAgICAgPC90ZD5cbiAgICAgICAgICA8dGQ+XG4gICAgICAgICAgICA8UHJlZmVyZW5jZVRpY2tlclxuICAgICAgICAgICAgICBwcmVmZXJlbmNlTWFwPXtwcmVmZXJlbmNlTWFwfVxuICAgICAgICAgICAgICBzZXRQcmVmZXJlbmNlTWFwPXtzZXRQcmVmZXJlbmNlTWFwfVxuICAgICAgICAgICAgICBwcmVmZXJlbmNlPXtcIlByaWNlXCJ9XG4gICAgICAgICAgICAgIHNldFJlc2V0PXtzZXRSZXNldH1cbiAgICAgICAgICAgICAgdmFsdWVKdW1wPXs1fVxuICAgICAgICAgICAgLz5cbiAgICAgICAgICA8L3RkPlxuICAgICAgICA8L3RyPlxuICAgICAgICA8dHI+XG4gICAgICAgICAgPHRkPlxuICAgICAgICAgICAgPGg0PkxpZnRzIE9wZW48L2g0PlxuICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgPHRkPlxuICAgICAgICAgICAgPFByZWZlcmVuY2VUaWNrZXJcbiAgICAgICAgICAgICAgcHJlZmVyZW5jZU1hcD17cHJlZmVyZW5jZU1hcH1cbiAgICAgICAgICAgICAgc2V0UHJlZmVyZW5jZU1hcD17c2V0UHJlZmVyZW5jZU1hcH1cbiAgICAgICAgICAgICAgcHJlZmVyZW5jZT17XCJMaWZ0cyBPcGVuXCJ9XG4gICAgICAgICAgICAgIHNldFJlc2V0PXtzZXRSZXNldH1cbiAgICAgICAgICAgICAgdmFsdWVKdW1wPXsxfVxuICAgICAgICAgICAgLz5cbiAgICAgICAgICA8L3RkPlxuICAgICAgICAgIDx0ZCBjbGFzc05hbWU9XCJzcGFjZXJEYXR1bVwiPjwvdGQ+XG4gICAgICAgICAgPHRkPlxuICAgICAgICAgICAgPGg0PlN1bW1pdCBFbGV2YXRpb248L2g0PlxuICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgPHRkPlxuICAgICAgICAgICAgPFByZWZlcmVuY2VUaWNrZXJcbiAgICAgICAgICAgICAgcHJlZmVyZW5jZU1hcD17cHJlZmVyZW5jZU1hcH1cbiAgICAgICAgICAgICAgc2V0UHJlZmVyZW5jZU1hcD17c2V0UHJlZmVyZW5jZU1hcH1cbiAgICAgICAgICAgICAgcHJlZmVyZW5jZT17XCJTdW1taXQgRWxldmF0aW9uXCJ9XG4gICAgICAgICAgICAgIHNldFJlc2V0PXtzZXRSZXNldH1cbiAgICAgICAgICAgICAgdmFsdWVKdW1wPXsxMDB9XG4gICAgICAgICAgICAvPlxuICAgICAgICAgIDwvdGQ+XG4gICAgICAgIDwvdHI+XG4gICAgICAgIDx0cj5cbiAgICAgICAgICA8dGQ+XG4gICAgICAgICAgICA8aDQ+VGVtcGVyYXR1cmU8L2g0PlxuICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgPHRkPlxuICAgICAgICAgICAgPFByZWZlcmVuY2VUaWNrZXJcbiAgICAgICAgICAgICAgcHJlZmVyZW5jZU1hcD17cHJlZmVyZW5jZU1hcH1cbiAgICAgICAgICAgICAgc2V0UHJlZmVyZW5jZU1hcD17c2V0UHJlZmVyZW5jZU1hcH1cbiAgICAgICAgICAgICAgcHJlZmVyZW5jZT17XCJUZW1wZXJhdHVyZVwifVxuICAgICAgICAgICAgICBzZXRSZXNldD17c2V0UmVzZXR9XG4gICAgICAgICAgICAgIHZhbHVlSnVtcD17MX1cbiAgICAgICAgICAgIC8+XG4gICAgICAgICAgPC90ZD5cbiAgICAgICAgICA8dGQgY2xhc3NOYW1lPVwic3BhY2VyRGF0dW1cIj48L3RkPlxuICAgICAgICAgIDx0ZD5cbiAgICAgICAgICAgIDxoND5XaW5kc3BlZWQ8L2g0PlxuICAgICAgICAgIDwvdGQ+XG4gICAgICAgICAgPHRkPlxuICAgICAgICAgICAgPFByZWZlcmVuY2VUaWNrZXJcbiAgICAgICAgICAgICAgcHJlZmVyZW5jZU1hcD17cHJlZmVyZW5jZU1hcH1cbiAgICAgICAgICAgICAgc2V0UHJlZmVyZW5jZU1hcD17c2V0UHJlZmVyZW5jZU1hcH1cbiAgICAgICAgICAgICAgcHJlZmVyZW5jZT17XCJXaW5kc3BlZWRcIn1cbiAgICAgICAgICAgICAgc2V0UmVzZXQ9e3NldFJlc2V0fVxuICAgICAgICAgICAgICB2YWx1ZUp1bXA9ezF9XG4gICAgICAgICAgICAvPlxuICAgICAgICAgIDwvdGQ+XG4gICAgICAgIDwvdHI+XG4gICAgICA8L3RhYmxlPlxuICAgICAgPGJ1dHRvblxuICAgICAgICBpZD1cInByZWZlcmVuY2VCdXR0b25cIlxuICAgICAgICBvbkNsaWNrPXsoKSA9PiBoYW5kbGVQcmVmU2VhcmNoKCl9XG4gICAgICAgIGFyaWEtbGFiZWw9XCJTZWFyY2ggcmVzb3J0cyBiYXNlZCBvbiBwcmVmZXJlbmNlc1wiXG4gICAgICA+XG4gICAgICAgIFNlYXJjaCBCeSBQcmVmZXJlbmNlc1xuICAgICAgPC9idXR0b24+XG4gICAgPC9kaXY+XG4gICk7XG59XG4iXSwiZmlsZSI6Ii9Vc2Vycy9hdXN0aW53aWxsaWFtcy9Eb2N1bWVudHMvU2Nob29sL3RoaXJkU2VtZXN0ZXIvQ1MzMi90ZXJtLXByb2plY3QtdGJ6aGFvLXRwZXp6YS1zbXNjaHVjaC1id2lsbGk0OC9Gcm9udGVuZC9za2kvc3JjL2NvbXBvbmVudHMvcHJlZnMvUHJlZmVyZW5jZXMudHN4In0=