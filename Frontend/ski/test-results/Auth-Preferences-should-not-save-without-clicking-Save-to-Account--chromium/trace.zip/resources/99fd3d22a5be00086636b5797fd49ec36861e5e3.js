import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/search/ControlledInput.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=36ac7ba8"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/search/ControlledInput.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
import "/src/styles/main.css";
export function ControlledInput({
  value,
  setValue,
  onKeyDown
}) {
  return /* @__PURE__ */ jsxDEV("input", { id: "searchInput", type: "text", className: "search-box", value, placeholder: "Enter resort name here...", onChange: (ev) => setValue(ev.target.value), "aria-label": "Search resorts", onKeyDown }, void 0, false, {
    fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/search/ControlledInput.tsx",
    lineNumber: 25,
    columnNumber: 10
  }, this);
}
_c = ControlledInput;
var _c;
$RefreshReg$(_c, "ControlledInput");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/search/ControlledInput.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBcUJFO0FBckJGLE9BQU87QUFBdUI7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBQUE7QUFBQTtBQUFBO0FBbUJ2QixnQkFBU0EsZ0JBQWdCO0FBQUEsRUFBRUM7QUFBQUEsRUFBT0M7QUFBQUEsRUFBVUM7QUFBZ0MsR0FBRztBQUNyRixTQUNDLHVCQUFDLFdBQ0EsSUFBRyxlQUNILE1BQUssUUFDTCxXQUFVLGNBQ1YsT0FDQSxhQUFZLDZCQUNaLFVBQVdDLFFBQU9GLFNBQVNFLEdBQUdDLE9BQU9KLEtBQUssR0FDMUMsY0FBVyxrQkFDWCxhQVJEO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FRc0I7QUFHeEI7QUFBQ0ssS0FiZU47QUFBZSxJQUFBTTtBQUFBQyxhQUFBRCxJQUFBIiwibmFtZXMiOlsiQ29udHJvbGxlZElucHV0IiwidmFsdWUiLCJzZXRWYWx1ZSIsIm9uS2V5RG93biIsImV2IiwidGFyZ2V0IiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJDb250cm9sbGVkSW5wdXQudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBcIi4uLy4uL3N0eWxlcy9tYWluLmNzc1wiO1xuaW1wb3J0IHsgRGlzcGF0Y2gsIFNldFN0YXRlQWN0aW9uIH0gZnJvbSBcInJlYWN0XCI7XG5cbi8qKlxuICogUHJvcGVydGllcyBmb3IgdGhlIENvbnRyb2xsZWRJbnB1dCBjb21wb25lbnQuXG4gKi9cbmludGVyZmFjZSBDb250cm9sbGVkSW5wdXRQcm9wcyB7XG5cdHZhbHVlOiBzdHJpbmc7XG5cdHNldFZhbHVlOiBEaXNwYXRjaDxTZXRTdGF0ZUFjdGlvbjxzdHJpbmc+Pjtcblx0b25LZXlEb3duOiBSZWFjdC5LZXlib2FyZEV2ZW50SGFuZGxlcjxIVE1MSW5wdXRFbGVtZW50Pjtcbn1cblxuLyoqXG4gKiBSZW5kZXJzIGEgdGV4dCBpbnB1dCBmaWVsZCB3aGljaCBpcyBjb250cm9sbGVkIGJ5IFJlYWN0IHN0YXRlLiBVcGRhdGVzIHRoZSBzdGF0ZVxuICogYmFzZWQgb24gdXNlciBpbnB1dCBhbmQgc3VwcG9ydHMga2V5Ym9hcmQgbmF2aWdhdGlvbi5cbiAqXG4gKiBAcGFyYW0ge0NvbnRyb2xsZWRJbnB1dFByb3BzfSBwcm9wcyAtIFByb3BzIGZvciB0aGUgQ29udHJvbGxlZElucHV0IGNvbXBvbmVudC5cbiAqIEByZXR1cm5zIHtSZWFjdC5SZWFjdEVsZW1lbnR9IEEgY29udHJvbGxlZCBpbnB1dCBlbGVtZW50IHdpdGggYSBzcGVjaWZpZWQgdmFsdWUgYW5kIGNoYW5nZSBoYW5kbGVyLlxuICovXG5leHBvcnQgZnVuY3Rpb24gQ29udHJvbGxlZElucHV0KHsgdmFsdWUsIHNldFZhbHVlLCBvbktleURvd24gfTogQ29udHJvbGxlZElucHV0UHJvcHMpIHtcblx0cmV0dXJuIChcblx0XHQ8aW5wdXRcblx0XHRcdGlkPVwic2VhcmNoSW5wdXRcIlxuXHRcdFx0dHlwZT1cInRleHRcIlxuXHRcdFx0Y2xhc3NOYW1lPVwic2VhcmNoLWJveFwiXG5cdFx0XHR2YWx1ZT17dmFsdWV9XG5cdFx0XHRwbGFjZWhvbGRlcj1cIkVudGVyIHJlc29ydCBuYW1lIGhlcmUuLi5cIlxuXHRcdFx0b25DaGFuZ2U9eyhldikgPT4gc2V0VmFsdWUoZXYudGFyZ2V0LnZhbHVlKX1cblx0XHRcdGFyaWEtbGFiZWw9XCJTZWFyY2ggcmVzb3J0c1wiXG5cdFx0XHRvbktleURvd249e29uS2V5RG93bn1cblx0XHQvPlxuXHQpO1xufVxuIl0sImZpbGUiOiIvVXNlcnMvYXVzdGlud2lsbGlhbXMvRG9jdW1lbnRzL1NjaG9vbC90aGlyZFNlbWVzdGVyL0NTMzIvdGVybS1wcm9qZWN0LXRiemhhby10cGV6emEtc21zY2h1Y2gtYndpbGxpNDgvRnJvbnRlbmQvc2tpL3NyYy9jb21wb25lbnRzL3NlYXJjaC9Db250cm9sbGVkSW5wdXQudHN4In0=