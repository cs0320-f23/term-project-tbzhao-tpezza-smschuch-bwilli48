import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/App.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=36ac7ba8"; const Fragment = __vite__cjsImport0_react_jsxDevRuntime["Fragment"]; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/App.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import __vite__cjsImport3_react from "/node_modules/.vite/deps/react.js?v=36ac7ba8"; const useState = __vite__cjsImport3_react["useState"]; const useEffect = __vite__cjsImport3_react["useEffect"];
import { useAuth0 } from "/node_modules/.vite/deps/@auth0_auth0-react.js?v=36ac7ba8";
import { Preferences } from "/src/components/prefs/Preferences.tsx";
import { ResortsList } from "/src/components/resorts/ResortsList.tsx";
import { Search } from "/src/components/search/Search.tsx";
import { Sort } from "/src/components/sort/Sort.tsx";
import LoginButton from "/src/components/auth/LoginButton.tsx";
import Profile from "/src/components/auth/Profile.tsx";
import "/src/styles/App.css";
import "/src/styles/main.css";
import { savePreferencesToLocalStorage, loadPreferencesFromLocalStorage } from "/src/components/utils/PreferenceUtils.ts";
import { getMockStartResorts, getStartResorts } from "/src/components/resorts/ResortClass.tsx";
function App() {
  _s();
  const [resortList, setResortList] = useState([]);
  const {
    isAuthenticated,
    user
  } = useAuth0();
  const [preferences, setPreferences] = useState(null);
  useEffect(() => {
    if (isAuthenticated && user?.sub) {
      const loadedPreferences = loadPreferencesFromLocalStorage(user.sub);
      setPreferences(loadedPreferences);
    }
    var output = getStartResorts();
    output.then((res) => {
      setResortList(res);
    });
  }, [isAuthenticated, user?.sub]);
  const handleSavePreferences = (newPreferences) => {
    if (user?.sub) {
      savePreferencesToLocalStorage(user.sub, newPreferences);
      setPreferences(newPreferences);
    }
  };
  const [mockMode, setMockMode] = useState(false);
  const [mockString, setMockString] = useState("Mock Mode: Off");
  const [mockID, setMockID] = useState("mockOffButton");
  function handleMockButton() {
    if (mockMode) {
      setMockMode(false);
      setMockString("Mock Mode: Off");
      setMockID("mockOffButton");
      var output = getStartResorts();
      output.then((res) => {
        setResortList(res);
      });
    } else {
      setMockMode(true);
      setMockString("Mock Mode: On");
      setMockID("mockOnButton");
      setResortList(getMockStartResorts);
    }
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "App", children: [
    /* @__PURE__ */ jsxDEV("header", { className: "App-header", children: /* @__PURE__ */ jsxDEV("h1", { children: "Alpine Advisor" }, void 0, false, {
      fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/App.tsx",
      lineNumber: 92,
      columnNumber: 9
    }, this) }, void 0, false, {
      fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/App.tsx",
      lineNumber: 91,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("button", { className: "search-button", id: mockID, onClick: () => handleMockButton(), "aria-label": mockMode ? "Disable mock mode" : "Enable mock mode", children: mockString }, void 0, false, {
      fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/App.tsx",
      lineNumber: 94,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("main", { children: [
      /* @__PURE__ */ jsxDEV("section", { className: "user-panel", children: isAuthenticated ? /* @__PURE__ */ jsxDEV(Fragment, { children: /* @__PURE__ */ jsxDEV(Profile, { className: "profile-container", "aria-label": "User profile" }, void 0, false, {
        fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/App.tsx",
        lineNumber: 100,
        columnNumber: 15
      }, this) }, void 0, false, {
        fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/App.tsx",
        lineNumber: 99,
        columnNumber: 30
      }, this) : /* @__PURE__ */ jsxDEV(LoginButton, { className: "login-button", "aria-label": "Login button" }, void 0, false, {
        fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/App.tsx",
        lineNumber: 101,
        columnNumber: 19
      }, this) }, void 0, false, {
        fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/App.tsx",
        lineNumber: 98,
        columnNumber: 9
      }, this),
      /* @__PURE__ */ jsxDEV("section", { className: "content-panel", children: /* @__PURE__ */ jsxDEV("div", { children: [
        /* @__PURE__ */ jsxDEV(Preferences, { preferences, onSavePreferences: handleSavePreferences, resortList, setResortList, mockMode }, void 0, false, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/App.tsx",
          lineNumber: 105,
          columnNumber: 13
        }, this),
        /* @__PURE__ */ jsxDEV("div", { className: "search-sort-resorts", children: [
          /* @__PURE__ */ jsxDEV("div", { className: "search-sort", children: [
            /* @__PURE__ */ jsxDEV("div", { className: "sort", children: /* @__PURE__ */ jsxDEV(Sort, { resortList, setResortList, mockMode }, void 0, false, {
              fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/App.tsx",
              lineNumber: 109,
              columnNumber: 19
            }, this) }, void 0, false, {
              fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/App.tsx",
              lineNumber: 108,
              columnNumber: 17
            }, this),
            /* @__PURE__ */ jsxDEV("div", { className: "search", children: /* @__PURE__ */ jsxDEV(Search, { resortList, setResortList, mockMode }, void 0, false, {
              fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/App.tsx",
              lineNumber: 112,
              columnNumber: 19
            }, this) }, void 0, false, {
              fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/App.tsx",
              lineNumber: 111,
              columnNumber: 17
            }, this)
          ] }, void 0, true, {
            fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/App.tsx",
            lineNumber: 107,
            columnNumber: 15
          }, this),
          /* @__PURE__ */ jsxDEV("div", { className: "resorts", children: /* @__PURE__ */ jsxDEV(ResortsList, { resortList, "aria-label": "List of resorts" }, void 0, false, {
            fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/App.tsx",
            lineNumber: 116,
            columnNumber: 17
          }, this) }, void 0, false, {
            fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/App.tsx",
            lineNumber: 115,
            columnNumber: 15
          }, this)
        ] }, void 0, true, {
          fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/App.tsx",
          lineNumber: 106,
          columnNumber: 13
        }, this)
      ] }, void 0, true, {
        fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/App.tsx",
        lineNumber: 104,
        columnNumber: 11
      }, this) }, void 0, false, {
        fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/App.tsx",
        lineNumber: 103,
        columnNumber: 9
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/App.tsx",
      lineNumber: 97,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/App.tsx",
    lineNumber: 90,
    columnNumber: 10
  }, this);
}
_s(App, "8DLE1UbTrDwBKO05DH9KeA0ikv0=", false, function() {
  return [useAuth0];
});
_c = App;
export default App;
var _c;
$RefreshReg$(_c, "App");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/App.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0dRLFNBYUksVUFiSjs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFsR1IsU0FBU0EsVUFBVUMsaUJBQWlCO0FBQ3BDLFNBQVNDLGdCQUFnQjtBQUN6QixTQUFTQyxtQkFBbUI7QUFDNUIsU0FBU0MsbUJBQW1CO0FBQzVCLFNBQVNDLGNBQWM7QUFDdkIsU0FBU0MsWUFBWTtBQUNyQixPQUFPQyxpQkFBaUI7QUFDeEIsT0FBT0MsYUFBYTtBQUNwQixPQUFPO0FBQ1AsT0FBTztBQUVQLFNBQ0VDLCtCQUNBQyx1Q0FDSztBQUNQLFNBQ0VDLHFCQUNBQyx1QkFLSztBQVFQLFNBQVNDLE1BQU07QUFBQUMsS0FBQTtBQUViLFFBQU0sQ0FBQ0MsWUFBWUMsYUFBYSxJQUFJaEIsU0FBbUIsRUFBRTtBQUd6RCxRQUFNO0FBQUEsSUFBRWlCO0FBQUFBLElBQWlCQztBQUFBQSxFQUFLLElBQUloQixTQUFTO0FBRzNDLFFBQU0sQ0FBQ2lCLGFBQWFDLGNBQWMsSUFBSXBCLFNBQWlDLElBQUk7QUFPM0VDLFlBQVUsTUFBTTtBQUNkLFFBQUlnQixtQkFBbUJDLE1BQU1HLEtBQUs7QUFDaEMsWUFBTUMsb0JBQW9CWixnQ0FBZ0NRLEtBQUtHLEdBQUc7QUFDbEVELHFCQUFlRSxpQkFBaUI7QUFBQSxJQUNsQztBQUNBLFFBQUlDLFNBQVNYLGdCQUFnQjtBQUM3QlcsV0FBT0MsS0FBTUMsU0FBUTtBQUNuQlQsb0JBQWNTLEdBQUc7QUFBQSxJQUNuQixDQUFDO0FBQUEsRUFDSCxHQUFHLENBQUNSLGlCQUFpQkMsTUFBTUcsR0FBRyxDQUFDO0FBTS9CLFFBQU1LLHdCQUF3QkEsQ0FBQ0MsbUJBQW9DO0FBQ2pFLFFBQUlULE1BQU1HLEtBQUs7QUFDYlosb0NBQThCUyxLQUFLRyxLQUFLTSxjQUFjO0FBQ3REUCxxQkFBZU8sY0FBYztBQUFBLElBQy9CO0FBQUEsRUFDRjtBQUdBLFFBQU0sQ0FBQ0MsVUFBVUMsV0FBVyxJQUFJN0IsU0FBa0IsS0FBSztBQUV2RCxRQUFNLENBQUM4QixZQUFZQyxhQUFhLElBQUkvQixTQUFpQixnQkFBZ0I7QUFFckUsUUFBTSxDQUFDZ0MsUUFBUUMsU0FBUyxJQUFJakMsU0FBaUIsZUFBZTtBQU01RCxXQUFTa0MsbUJBQW1CO0FBQzFCLFFBQUlOLFVBQVU7QUFDWkMsa0JBQVksS0FBSztBQUNqQkUsb0JBQWMsZ0JBQWdCO0FBQzlCRSxnQkFBVSxlQUFlO0FBQ3pCLFVBQUlWLFNBQVNYLGdCQUFnQjtBQUM3QlcsYUFBT0MsS0FBTUMsU0FBUTtBQUNuQlQsc0JBQWNTLEdBQUc7QUFBQSxNQUNuQixDQUFDO0FBQUEsSUFDSCxPQUFPO0FBQ0xJLGtCQUFZLElBQUk7QUFDaEJFLG9CQUFjLGVBQWU7QUFDN0JFLGdCQUFVLGNBQWM7QUFDeEJqQixvQkFBY0wsbUJBQW1CO0FBQUEsSUFDbkM7QUFBQSxFQUNGO0FBRUEsU0FDRSx1QkFBQyxTQUFJLFdBQVUsT0FDYjtBQUFBLDJCQUFDLFlBQU8sV0FBVSxjQUNoQixpQ0FBQyxRQUFHLDhCQUFKO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBa0IsS0FEcEI7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQUVBO0FBQUEsSUFDQSx1QkFBQyxZQUNDLFdBQVUsaUJBQ1YsSUFBSXFCLFFBQ0osU0FBUyxNQUFNRSxpQkFBaUIsR0FDaEMsY0FBWU4sV0FBVyxzQkFBc0Isb0JBRTVDRSx3QkFOSDtBQUFBO0FBQUE7QUFBQTtBQUFBLFdBT0E7QUFBQSxJQUNBLHVCQUFDLFVBQ0M7QUFBQSw2QkFBQyxhQUFRLFdBQVUsY0FDaEJiLDRCQUNDLG1DQUNFLGlDQUFDLFdBQ0MsV0FBVSxxQkFDVixjQUFXLGtCQUZiO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFFMkIsS0FIN0I7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQUtBLElBRUEsdUJBQUMsZUFBWSxXQUFVLGdCQUFlLGNBQVcsa0JBQWpEO0FBQUE7QUFBQTtBQUFBO0FBQUEsYUFBK0QsS0FUbkU7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQVdBO0FBQUEsTUFDQSx1QkFBQyxhQUFRLFdBQVUsaUJBQ2pCLGlDQUFDLFNBQ0M7QUFBQSwrQkFBQyxlQUNDLGFBQ0EsbUJBQW1CUyx1QkFDbkIsWUFDQSxlQUNBLFlBTEY7QUFBQTtBQUFBO0FBQUE7QUFBQSxlQUtxQjtBQUFBLFFBRXJCLHVCQUFDLFNBQUksV0FBVSx1QkFDYjtBQUFBLGlDQUFDLFNBQUksV0FBVSxlQUNiO0FBQUEsbUNBQUMsU0FBSSxXQUFVLFFBQ2IsaUNBQUMsUUFDQyxZQUNBLGVBQ0EsWUFIRjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQUdxQixLQUp2QjtBQUFBO0FBQUE7QUFBQTtBQUFBLG1CQU1BO0FBQUEsWUFDQSx1QkFBQyxTQUFJLFdBQVUsVUFDYixpQ0FBQyxVQUNDLFlBQ0EsZUFDQSxZQUhGO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBR3FCLEtBSnZCO0FBQUE7QUFBQTtBQUFBO0FBQUEsbUJBTUE7QUFBQSxlQWRGO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBZUE7QUFBQSxVQUNBLHVCQUFDLFNBQUksV0FBVSxXQUNiLGlDQUFDLGVBQ0MsWUFDQSxjQUFXLHFCQUZiO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBRThCLEtBSGhDO0FBQUE7QUFBQTtBQUFBO0FBQUEsaUJBS0E7QUFBQSxhQXRCRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGVBdUJBO0FBQUEsV0EvQkY7QUFBQTtBQUFBO0FBQUE7QUFBQSxhQWdDQSxLQWpDRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBa0NBO0FBQUEsU0EvQ0Y7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWdEQTtBQUFBLE9BNURGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0E2REE7QUFFSjtBQUFDWixHQWpJUUQsS0FBRztBQUFBLFVBS3dCWCxRQUFRO0FBQUE7QUFBQWlDLEtBTG5DdEI7QUFtSVQsZUFBZUE7QUFBSSxJQUFBc0I7QUFBQUMsYUFBQUQsSUFBQSIsIm5hbWVzIjpbInVzZVN0YXRlIiwidXNlRWZmZWN0IiwidXNlQXV0aDAiLCJQcmVmZXJlbmNlcyIsIlJlc29ydHNMaXN0IiwiU2VhcmNoIiwiU29ydCIsIkxvZ2luQnV0dG9uIiwiUHJvZmlsZSIsInNhdmVQcmVmZXJlbmNlc1RvTG9jYWxTdG9yYWdlIiwibG9hZFByZWZlcmVuY2VzRnJvbUxvY2FsU3RvcmFnZSIsImdldE1vY2tTdGFydFJlc29ydHMiLCJnZXRTdGFydFJlc29ydHMiLCJBcHAiLCJfcyIsInJlc29ydExpc3QiLCJzZXRSZXNvcnRMaXN0IiwiaXNBdXRoZW50aWNhdGVkIiwidXNlciIsInByZWZlcmVuY2VzIiwic2V0UHJlZmVyZW5jZXMiLCJzdWIiLCJsb2FkZWRQcmVmZXJlbmNlcyIsIm91dHB1dCIsInRoZW4iLCJyZXMiLCJoYW5kbGVTYXZlUHJlZmVyZW5jZXMiLCJuZXdQcmVmZXJlbmNlcyIsIm1vY2tNb2RlIiwic2V0TW9ja01vZGUiLCJtb2NrU3RyaW5nIiwic2V0TW9ja1N0cmluZyIsIm1vY2tJRCIsInNldE1vY2tJRCIsImhhbmRsZU1vY2tCdXR0b24iLCJfYyIsIiRSZWZyZXNoUmVnJCJdLCJzb3VyY2VzIjpbIkFwcC50c3giXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgdXNlU3RhdGUsIHVzZUVmZmVjdCB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgdXNlQXV0aDAgfSBmcm9tIFwiQGF1dGgwL2F1dGgwLXJlYWN0XCI7XG5pbXBvcnQgeyBQcmVmZXJlbmNlcyB9IGZyb20gXCIuL3ByZWZzL1ByZWZlcmVuY2VzXCI7XG5pbXBvcnQgeyBSZXNvcnRzTGlzdCB9IGZyb20gXCIuL3Jlc29ydHMvUmVzb3J0c0xpc3RcIjtcbmltcG9ydCB7IFNlYXJjaCB9IGZyb20gXCIuL3NlYXJjaC9TZWFyY2hcIjtcbmltcG9ydCB7IFNvcnQgfSBmcm9tIFwiLi9zb3J0L1NvcnRcIjtcbmltcG9ydCBMb2dpbkJ1dHRvbiBmcm9tIFwiLi9hdXRoL0xvZ2luQnV0dG9uXCI7XG5pbXBvcnQgUHJvZmlsZSBmcm9tIFwiLi9hdXRoL1Byb2ZpbGVcIjtcbmltcG9ydCBcIi4uL3N0eWxlcy9BcHAuY3NzXCI7XG5pbXBvcnQgXCIuLi9zdHlsZXMvbWFpbi5jc3NcIjtcbmltcG9ydCB7IFVzZXJQcmVmZXJlbmNlcyB9IGZyb20gXCIuL3ByZWZzL1ByZWZlcmVuY2VzXCI7XG5pbXBvcnQge1xuICBzYXZlUHJlZmVyZW5jZXNUb0xvY2FsU3RvcmFnZSxcbiAgbG9hZFByZWZlcmVuY2VzRnJvbUxvY2FsU3RvcmFnZSxcbn0gZnJvbSBcIi4vdXRpbHMvUHJlZmVyZW5jZVV0aWxzXCI7XG5pbXBvcnQge1xuICBnZXRNb2NrU3RhcnRSZXNvcnRzLFxuICBnZXRTdGFydFJlc29ydHMsXG4gIE1vY2tBLFxuICBNb2NrRCxcbiAgbW9ja1Jlc29ydHMsXG4gIFJlc29ydCxcbn0gZnJvbSBcIi4vcmVzb3J0cy9SZXNvcnRDbGFzc1wiO1xuXG4vKipcbiAqIFRoZSBgQXBwYCBjb21wb25lbnQgc2VydmVzIGFzIHRoZSBtYWluIGNvbnRhaW5lciBmb3IgdGhlIEFscGluZSBBZHZpc29yIGFwcGxpY2F0aW9uLlxuICogSXQgdXNlcyBBdXRoMCBmb3IgYXV0aGVudGljYXRpb24sIG1hbmFnZXMgc3RhdGUgZm9yIHJlc29ydCBkYXRhIGFuZCBtb2NrIG1vZGUsIGFuZFxuICogcmVuZGVycyB2YXJpb3VzIGNvbXBvbmVudHMgc3VjaCBhcyBgUHJlZmVyZW5jZXNgLCBgU2VhcmNoYCwgYFNvcnRgLCBgUmVzb3J0c0xpc3RgLFxuICogYExvZ2luQnV0dG9uYCwgYW5kIGBQcm9maWxlYC5cbiAqL1xuZnVuY3Rpb24gQXBwKCkge1xuICAvLyBNYW5hZ2VzIHN0YXRlIGZvciB0aGUgcmVzb3J0IGxpc3RcbiAgY29uc3QgW3Jlc29ydExpc3QsIHNldFJlc29ydExpc3RdID0gdXNlU3RhdGU8UmVzb3J0W10+KFtdKTtcblxuICAvLyBHZXRzIGF1dGhlbnRpY2F0aW9uIHN0YXR1cyBhbmQgdXNlciBpbmZvIGZyb20gQXV0aDBcbiAgY29uc3QgeyBpc0F1dGhlbnRpY2F0ZWQsIHVzZXIgfSA9IHVzZUF1dGgwKCk7XG5cbiAgLy8gTWFuYWdlcyBzdGF0ZSBmb3IgdXNlciBwcmVmZXJlbmNlc1xuICBjb25zdCBbcHJlZmVyZW5jZXMsIHNldFByZWZlcmVuY2VzXSA9IHVzZVN0YXRlPFVzZXJQcmVmZXJlbmNlcyB8IG51bGw+KG51bGwpO1xuXG4gIC8qKlxuICAgKiB1c2VFZmZlY3QgaG9vayB0byBsb2FkIHVzZXIgcHJlZmVyZW5jZXMgZnJvbSBsb2NhbCBzdG9yYWdlIHdoZW4gdGhlIHVzZXIgbG9ncyBpbi5cbiAgICogSXQgY2hlY2tzIGlmIHRoZSB1c2VyIGlzIGF1dGhlbnRpY2F0ZWQgYW5kIGlmIHNvLCBpdCBsb2FkcyBwcmVmZXJlbmNlcyBhc3NvY2lhdGVkXG4gICAqIHdpdGggdGhhdCB1c2VyIGFuZCBzZXRzIHRoZW0gaW4gc3RhdGUuXG4gICAqL1xuICB1c2VFZmZlY3QoKCkgPT4ge1xuICAgIGlmIChpc0F1dGhlbnRpY2F0ZWQgJiYgdXNlcj8uc3ViKSB7XG4gICAgICBjb25zdCBsb2FkZWRQcmVmZXJlbmNlcyA9IGxvYWRQcmVmZXJlbmNlc0Zyb21Mb2NhbFN0b3JhZ2UodXNlci5zdWIpO1xuICAgICAgc2V0UHJlZmVyZW5jZXMobG9hZGVkUHJlZmVyZW5jZXMpO1xuICAgIH1cbiAgICB2YXIgb3V0cHV0ID0gZ2V0U3RhcnRSZXNvcnRzKCk7XG4gICAgb3V0cHV0LnRoZW4oKHJlcykgPT4ge1xuICAgICAgc2V0UmVzb3J0TGlzdChyZXMpO1xuICAgIH0pO1xuICB9LCBbaXNBdXRoZW50aWNhdGVkLCB1c2VyPy5zdWJdKTtcblxuICAvKipcbiAgICogU2F2ZXMgbmV3IHVzZXIgcHJlZmVyZW5jZXMuIEZpcnN0IGNoZWNrcyBpZiB0aGUgdXNlciBpcyBhdXRoZW50aWNhdGVkIGFuZFxuICAgKiBpZiBzbywgc2F2ZXMgdGhlIG5ldyBwcmVmZXJlbmNlcyB0byBsb2NhbCBzdG9yYWdlIGFuZCB1cGRhdGVzIHRoZSBzdGF0ZS5cbiAgICovXG4gIGNvbnN0IGhhbmRsZVNhdmVQcmVmZXJlbmNlcyA9IChuZXdQcmVmZXJlbmNlczogVXNlclByZWZlcmVuY2VzKSA9PiB7XG4gICAgaWYgKHVzZXI/LnN1Yikge1xuICAgICAgc2F2ZVByZWZlcmVuY2VzVG9Mb2NhbFN0b3JhZ2UodXNlci5zdWIsIG5ld1ByZWZlcmVuY2VzKTtcbiAgICAgIHNldFByZWZlcmVuY2VzKG5ld1ByZWZlcmVuY2VzKTtcbiAgICB9XG4gIH07XG5cbiAgLy8gTWFuYWdlcyBzdGF0ZSBmb3IgbW9jayBtb2RlXG4gIGNvbnN0IFttb2NrTW9kZSwgc2V0TW9ja01vZGVdID0gdXNlU3RhdGU8Ym9vbGVhbj4oZmFsc2UpO1xuICAvLyBNYW5hZ2VzIHN0YXRlIGZvciB0aGUgbW9jayBpbmRpY2F0b3JcbiAgY29uc3QgW21vY2tTdHJpbmcsIHNldE1vY2tTdHJpbmddID0gdXNlU3RhdGU8c3RyaW5nPihcIk1vY2sgTW9kZTogT2ZmXCIpO1xuICAvLyBNYW5hZ2VzIHN0YXRlIGZvciB0aGUgbW9jayBJRFxuICBjb25zdCBbbW9ja0lELCBzZXRNb2NrSURdID0gdXNlU3RhdGU8c3RyaW5nPihcIm1vY2tPZmZCdXR0b25cIik7XG5cbiAgLyoqXG4gICAqIFRvZ2dsZXMgdGhlIG1vY2sgbW9kZSBzdGF0ZSBhbmQgdXBkYXRlcyB0aGUgcmVzb3J0IGxpc3QgYWNjb3JkaW5nbHkuXG4gICAqIFN3aXRjaGVzIGJldHdlZW4gcmVhbCBhbmQgbW9jayBkYXRhIGZvciByZXNvcnRzLlxuICAgKi9cbiAgZnVuY3Rpb24gaGFuZGxlTW9ja0J1dHRvbigpIHtcbiAgICBpZiAobW9ja01vZGUpIHtcbiAgICAgIHNldE1vY2tNb2RlKGZhbHNlKTtcbiAgICAgIHNldE1vY2tTdHJpbmcoXCJNb2NrIE1vZGU6IE9mZlwiKTtcbiAgICAgIHNldE1vY2tJRChcIm1vY2tPZmZCdXR0b25cIik7XG4gICAgICB2YXIgb3V0cHV0ID0gZ2V0U3RhcnRSZXNvcnRzKCk7XG4gICAgICBvdXRwdXQudGhlbigocmVzKSA9PiB7XG4gICAgICAgIHNldFJlc29ydExpc3QocmVzKTtcbiAgICAgIH0pO1xuICAgIH0gZWxzZSB7XG4gICAgICBzZXRNb2NrTW9kZSh0cnVlKTtcbiAgICAgIHNldE1vY2tTdHJpbmcoXCJNb2NrIE1vZGU6IE9uXCIpO1xuICAgICAgc2V0TW9ja0lEKFwibW9ja09uQnV0dG9uXCIpO1xuICAgICAgc2V0UmVzb3J0TGlzdChnZXRNb2NrU3RhcnRSZXNvcnRzKTtcbiAgICB9XG4gIH1cblxuICByZXR1cm4gKFxuICAgIDxkaXYgY2xhc3NOYW1lPVwiQXBwXCI+XG4gICAgICA8aGVhZGVyIGNsYXNzTmFtZT1cIkFwcC1oZWFkZXJcIj5cbiAgICAgICAgPGgxPkFscGluZSBBZHZpc29yPC9oMT5cbiAgICAgIDwvaGVhZGVyPlxuICAgICAgPGJ1dHRvblxuICAgICAgICBjbGFzc05hbWU9XCJzZWFyY2gtYnV0dG9uXCJcbiAgICAgICAgaWQ9e21vY2tJRH1cbiAgICAgICAgb25DbGljaz17KCkgPT4gaGFuZGxlTW9ja0J1dHRvbigpfVxuICAgICAgICBhcmlhLWxhYmVsPXttb2NrTW9kZSA/IFwiRGlzYWJsZSBtb2NrIG1vZGVcIiA6IFwiRW5hYmxlIG1vY2sgbW9kZVwifVxuICAgICAgPlxuICAgICAgICB7bW9ja1N0cmluZ31cbiAgICAgIDwvYnV0dG9uPlxuICAgICAgPG1haW4+XG4gICAgICAgIDxzZWN0aW9uIGNsYXNzTmFtZT1cInVzZXItcGFuZWxcIj5cbiAgICAgICAgICB7aXNBdXRoZW50aWNhdGVkID8gKFxuICAgICAgICAgICAgPD5cbiAgICAgICAgICAgICAgPFByb2ZpbGVcbiAgICAgICAgICAgICAgICBjbGFzc05hbWU9XCJwcm9maWxlLWNvbnRhaW5lclwiXG4gICAgICAgICAgICAgICAgYXJpYS1sYWJlbD1cIlVzZXIgcHJvZmlsZVwiXG4gICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICA8Lz5cbiAgICAgICAgICApIDogKFxuICAgICAgICAgICAgPExvZ2luQnV0dG9uIGNsYXNzTmFtZT1cImxvZ2luLWJ1dHRvblwiIGFyaWEtbGFiZWw9XCJMb2dpbiBidXR0b25cIiAvPlxuICAgICAgICAgICl9XG4gICAgICAgIDwvc2VjdGlvbj5cbiAgICAgICAgPHNlY3Rpb24gY2xhc3NOYW1lPVwiY29udGVudC1wYW5lbFwiPlxuICAgICAgICAgIDxkaXY+XG4gICAgICAgICAgICA8UHJlZmVyZW5jZXNcbiAgICAgICAgICAgICAgcHJlZmVyZW5jZXM9e3ByZWZlcmVuY2VzfVxuICAgICAgICAgICAgICBvblNhdmVQcmVmZXJlbmNlcz17aGFuZGxlU2F2ZVByZWZlcmVuY2VzfVxuICAgICAgICAgICAgICByZXNvcnRMaXN0PXtyZXNvcnRMaXN0fVxuICAgICAgICAgICAgICBzZXRSZXNvcnRMaXN0PXtzZXRSZXNvcnRMaXN0fVxuICAgICAgICAgICAgICBtb2NrTW9kZT17bW9ja01vZGV9XG4gICAgICAgICAgICAvPlxuICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzZWFyY2gtc29ydC1yZXNvcnRzXCI+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwic2VhcmNoLXNvcnRcIj5cbiAgICAgICAgICAgICAgICA8ZGl2IGNsYXNzTmFtZT1cInNvcnRcIj5cbiAgICAgICAgICAgICAgICAgIDxTb3J0XG4gICAgICAgICAgICAgICAgICAgIHJlc29ydExpc3Q9e3Jlc29ydExpc3R9XG4gICAgICAgICAgICAgICAgICAgIHNldFJlc29ydExpc3Q9e3NldFJlc29ydExpc3R9XG4gICAgICAgICAgICAgICAgICAgIG1vY2tNb2RlPXttb2NrTW9kZX1cbiAgICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgICAgPGRpdiBjbGFzc05hbWU9XCJzZWFyY2hcIj5cbiAgICAgICAgICAgICAgICAgIDxTZWFyY2hcbiAgICAgICAgICAgICAgICAgICAgcmVzb3J0TGlzdD17cmVzb3J0TGlzdH1cbiAgICAgICAgICAgICAgICAgICAgc2V0UmVzb3J0TGlzdD17c2V0UmVzb3J0TGlzdH1cbiAgICAgICAgICAgICAgICAgICAgbW9ja01vZGU9e21vY2tNb2RlfVxuICAgICAgICAgICAgICAgICAgLz5cbiAgICAgICAgICAgICAgICA8L2Rpdj5cbiAgICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgICAgIDxkaXYgY2xhc3NOYW1lPVwicmVzb3J0c1wiPlxuICAgICAgICAgICAgICAgIDxSZXNvcnRzTGlzdFxuICAgICAgICAgICAgICAgICAgcmVzb3J0TGlzdD17cmVzb3J0TGlzdH1cbiAgICAgICAgICAgICAgICAgIGFyaWEtbGFiZWw9XCJMaXN0IG9mIHJlc29ydHNcIlxuICAgICAgICAgICAgICAgIC8+XG4gICAgICAgICAgICAgIDwvZGl2PlxuICAgICAgICAgICAgPC9kaXY+XG4gICAgICAgICAgPC9kaXY+XG4gICAgICAgIDwvc2VjdGlvbj5cbiAgICAgIDwvbWFpbj5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cblxuZXhwb3J0IGRlZmF1bHQgQXBwO1xuIl0sImZpbGUiOiIvVXNlcnMvYXVzdGlud2lsbGlhbXMvRG9jdW1lbnRzL1NjaG9vbC90aGlyZFNlbWVzdGVyL0NTMzIvdGVybS1wcm9qZWN0LXRiemhhby10cGV6emEtc21zY2h1Y2gtYndpbGxpNDgvRnJvbnRlbmQvc2tpL3NyYy9jb21wb25lbnRzL0FwcC50c3gifQ==