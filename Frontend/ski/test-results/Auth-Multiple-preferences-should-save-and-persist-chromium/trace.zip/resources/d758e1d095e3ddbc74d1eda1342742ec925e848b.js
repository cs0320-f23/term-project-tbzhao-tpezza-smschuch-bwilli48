import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=36ac7ba8"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import __vite__cjsImport1_react from "/node_modules/.vite/deps/react.js?v=36ac7ba8"; const React = __vite__cjsImport1_react.__esModule ? __vite__cjsImport1_react.default : __vite__cjsImport1_react;
import __vite__cjsImport2_reactDom_client from "/node_modules/.vite/deps/react-dom_client.js?v=36ac7ba8"; const ReactDOM = __vite__cjsImport2_reactDom_client.__esModule ? __vite__cjsImport2_reactDom_client.default : __vite__cjsImport2_reactDom_client;
import "/src/styles/index.css";
import App from "/src/components/App.tsx";
import { Auth0Provider } from "/node_modules/.vite/deps/@auth0_auth0-react.js?v=36ac7ba8";
const root = ReactDOM.createRoot(document.getElementById("root"));
root.render(/* @__PURE__ */ jsxDEV(React.StrictMode, { children: /* @__PURE__ */ jsxDEV(Auth0Provider, { domain: "dev-7cpkmpuleq3yr3t6.us.auth0.com", clientId: "MmL9q8hkGq5BS9PfJM21uBDWAPrPkpDs", authorizationParams: {
  redirect_uri: window.location.origin
}, children: /* @__PURE__ */ jsxDEV(App, {}, void 0, false, {
  fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/index.tsx",
  lineNumber: 15,
  columnNumber: 4
}, this) }, void 0, false, {
  fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/index.tsx",
  lineNumber: 12,
  columnNumber: 3
}, this) }, void 0, false, {
  fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/index.tsx",
  lineNumber: 11,
  columnNumber: 13
}, this));

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBbUJHO0FBbkJILE9BQU9BLFdBQVc7QUFDbEIsT0FBT0MsY0FBYztBQUNyQixPQUFPO0FBQ1AsT0FBT0MsU0FBUztBQUNoQixTQUFTQyxxQkFBcUI7QUFLOUIsTUFBTUMsT0FBT0gsU0FBU0ksV0FBV0MsU0FBU0MsZUFBZSxNQUFNLENBQWdCO0FBQy9FSCxLQUFLSSxPQUNKLHVCQUFDLE1BQU0sWUFBTixFQUNBLGlDQUFDLGlCQUNBLFFBQU8scUNBQ1AsVUFBUyxvQ0FDVCxxQkFBcUI7QUFBQSxFQUNwQkMsY0FBY0MsT0FBT0MsU0FBU0M7QUFDL0IsR0FFQSxpQ0FBQyxTQUFEO0FBQUE7QUFBQTtBQUFBO0FBQUEsT0FBSSxLQVBMO0FBQUE7QUFBQTtBQUFBO0FBQUEsT0FRQSxLQVREO0FBQUE7QUFBQTtBQUFBO0FBQUEsT0FVQSxDQUNEIiwibmFtZXMiOlsiUmVhY3QiLCJSZWFjdERPTSIsIkFwcCIsIkF1dGgwUHJvdmlkZXIiLCJyb290IiwiY3JlYXRlUm9vdCIsImRvY3VtZW50IiwiZ2V0RWxlbWVudEJ5SWQiLCJyZW5kZXIiLCJyZWRpcmVjdF91cmkiLCJ3aW5kb3ciLCJsb2NhdGlvbiIsIm9yaWdpbiJdLCJzb3VyY2VzIjpbImluZGV4LnRzeCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgUmVhY3QgZnJvbSBcInJlYWN0XCI7XG5pbXBvcnQgUmVhY3RET00gZnJvbSBcInJlYWN0LWRvbS9jbGllbnRcIjtcbmltcG9ydCBcIi4vc3R5bGVzL2luZGV4LmNzc1wiO1xuaW1wb3J0IEFwcCBmcm9tIFwiLi9jb21wb25lbnRzL0FwcFwiO1xuaW1wb3J0IHsgQXV0aDBQcm92aWRlciB9IGZyb20gXCJAYXV0aDAvYXV0aDAtcmVhY3RcIjtcblxuLy8gVGltIHJlbW92ZWQgc29tZSBib2lsZXJwbGF0ZSB0byBrZWVwIHRoaW5ncyBzaW1wbGUuXG4vLyBXZSdyZSB1c2luZyBhbiBvbGRlciB2ZXJzaW9uIG9mIFJlYWN0IGhlcmUuXG5cbmNvbnN0IHJvb3QgPSBSZWFjdERPTS5jcmVhdGVSb290KGRvY3VtZW50LmdldEVsZW1lbnRCeUlkKFwicm9vdFwiKSBhcyBIVE1MRWxlbWVudCk7XG5yb290LnJlbmRlcihcblx0PFJlYWN0LlN0cmljdE1vZGU+XG5cdFx0PEF1dGgwUHJvdmlkZXJcblx0XHRcdGRvbWFpbj1cImRldi03Y3BrbXB1bGVxM3lyM3Q2LnVzLmF1dGgwLmNvbVwiXG5cdFx0XHRjbGllbnRJZD1cIk1tTDlxOGhrR3E1QlM5UGZKTTIxdUJEV0FQclBrcERzXCJcblx0XHRcdGF1dGhvcml6YXRpb25QYXJhbXM9e3tcblx0XHRcdFx0cmVkaXJlY3RfdXJpOiB3aW5kb3cubG9jYXRpb24ub3JpZ2luLFxuXHRcdFx0fX1cblx0XHQ+XG5cdFx0XHQ8QXBwIC8+XG5cdFx0PC9BdXRoMFByb3ZpZGVyPlxuXHQ8L1JlYWN0LlN0cmljdE1vZGU+XG4pO1xuIl0sImZpbGUiOiIvVXNlcnMvYXVzdGlud2lsbGlhbXMvRG9jdW1lbnRzL1NjaG9vbC90aGlyZFNlbWVzdGVyL0NTMzIvdGVybS1wcm9qZWN0LXRiemhhby10cGV6emEtc21zY2h1Y2gtYndpbGxpNDgvRnJvbnRlbmQvc2tpL3NyYy9pbmRleC50c3gifQ==