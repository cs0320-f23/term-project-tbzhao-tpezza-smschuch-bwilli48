import { createHotContext as __vite__createHotContext } from "/@vite/client";import.meta.hot = __vite__createHotContext("/src/components/search/Search.tsx");import __vite__cjsImport0_react_jsxDevRuntime from "/node_modules/.vite/deps/react_jsx-dev-runtime.js?v=36ac7ba8"; const jsxDEV = __vite__cjsImport0_react_jsxDevRuntime["jsxDEV"];
import RefreshRuntime from "/@react-refresh";
const inWebWorker = typeof WorkerGlobalScope !== "undefined" && self instanceof WorkerGlobalScope;
let prevRefreshReg;
let prevRefreshSig;
if (import.meta.hot && !inWebWorker) {
  if (!window.__vite_plugin_react_preamble_installed__) {
    throw new Error("@vitejs/plugin-react can't detect preamble. Something is wrong. See https://github.com/vitejs/vite-plugin-react/pull/11#discussion_r430879201");
  }
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    RefreshRuntime.register(type, "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/search/Search.tsx " + id);
  };
  window.$RefreshSig$ = RefreshRuntime.createSignatureFunctionForTransform;
}
var _s = $RefreshSig$();
import "/src/styles/main.css";
import __vite__cjsImport4_react from "/node_modules/.vite/deps/react.js?v=36ac7ba8"; const useState = __vite__cjsImport4_react["useState"];
import { ControlledInput } from "/src/components/search/ControlledInput.tsx";
import { ResortDropdown } from "/src/components/search/ResortsDropdown.tsx";
import { getMockSearchResort, getSearchResort, mockResortNames, resortNames } from "/src/components/resorts/ResortClass.tsx";
export function Search(props) {
  _s();
  const [showDropDown, setShowDropDown] = useState(false);
  const [selectResort, setSelectResort] = useState("");
  const [commandString, setCommandString] = useState("");
  var resorts = props.mockMode ? mockResortNames() : resortNames();
  const toggleDropDown = () => {
    setShowDropDown(!showDropDown);
  };
  const dismissHandler = (event) => {
    if (event.currentTarget === event.target) {
      setShowDropDown(false);
    }
  };
  const resortOptionsSelection = (resortOption) => {
    setSelectResort(resortOption);
  };
  function handleSearch(commandString2) {
    if (commandString2 !== "") {
      if (props.mockMode) {
        props.setResortList(getMockSearchResort(commandString2));
      } else {
        var output = getSearchResort(commandString2);
        output.then((res) => {
          props.setResortList([res]);
        });
      }
    }
    setCommandString("");
  }
  return /* @__PURE__ */ jsxDEV("div", { className: "search-container", "aria-label": "Resort search section", children: [
    /* @__PURE__ */ jsxDEV("h3", { className: "search-title", children: "Search for a specific resort:" }, void 0, false, {
      fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/search/Search.tsx",
      lineNumber: 75,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV(ControlledInput, { value: commandString, setValue: setCommandString, onKeyDown: (event) => {
      if (event.key === "Enter") {
        event.preventDefault();
        handleSearch(commandString);
      }
    } }, void 0, false, {
      fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/search/Search.tsx",
      lineNumber: 76,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("button", { className: "search-button", id: "searchButton", onClick: () => handleSearch(commandString), "aria-label": "Search for a resort", children: "Search" }, void 0, false, {
      fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/search/Search.tsx",
      lineNumber: 82,
      columnNumber: 7
    }, this),
    /* @__PURE__ */ jsxDEV("button", { id: "searchDropdown", className: `search-dropdown ${showDropDown ? "active" : ""}`, onClick: toggleDropDown, onBlur: dismissHandler, "aria-label": "Show or hide resort list dropdown", children: [
      selectResort ? "See resorts ..." : " See full list of resorts...",
      showDropDown && /* @__PURE__ */ jsxDEV(ResortDropdown, { resortOptions: resorts, showDropDown, toggleDropDown, resortOptionsSelection, setCommandString }, void 0, false, {
        fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/search/Search.tsx",
        lineNumber: 87,
        columnNumber: 26
      }, this)
    ] }, void 0, true, {
      fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/search/Search.tsx",
      lineNumber: 85,
      columnNumber: 7
    }, this)
  ] }, void 0, true, {
    fileName: "/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/search/Search.tsx",
    lineNumber: 74,
    columnNumber: 10
  }, this);
}
_s(Search, "MWG6vfGHnpn+8k15vYOqi1LjzPs=");
_c = Search;
var _c;
$RefreshReg$(_c, "Search");
if (import.meta.hot && !inWebWorker) {
  window.$RefreshReg$ = prevRefreshReg;
  window.$RefreshSig$ = prevRefreshSig;
  RefreshRuntime.__hmr_import(import.meta.url).then((currentExports) => {
    RefreshRuntime.registerExportsForReactRefresh("/Users/austinwilliams/Documents/School/thirdSemester/CS32/term-project-tbzhao-tpezza-smschuch-bwilli48/Frontend/ski/src/components/search/Search.tsx", currentExports);
    import.meta.hot.accept((nextExports) => {
      if (!nextExports)
        return;
      const invalidateMessage = RefreshRuntime.validateRefreshBoundaryAndEnqueueUpdate(currentExports, nextExports);
      if (invalidateMessage)
        import.meta.hot.invalidate(invalidateMessage);
    });
  });
}

//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJtYXBwaW5ncyI6IkFBa0ZNOzs7Ozs7Ozs7Ozs7Ozs7OztBQWxGTixPQUFPO0FBQ1AsU0FBbUNBLGdCQUFnQjtBQUNuRCxTQUFTQyx1QkFBdUI7QUFDaEMsU0FBU0Msc0JBQXNCO0FBQy9CLFNBQ0VDLHFCQUNBQyxpQkFDQUMsaUJBR0FDLG1CQUNLO0FBZUEsZ0JBQVNDLE9BQU9DLE9BQW9CO0FBQUFDLEtBQUE7QUFFekMsUUFBTSxDQUFDQyxjQUFjQyxlQUFlLElBQUlYLFNBQWtCLEtBQUs7QUFHL0QsUUFBTSxDQUFDWSxjQUFjQyxlQUFlLElBQUliLFNBQWlCLEVBQUU7QUFHM0QsUUFBTSxDQUFDYyxlQUFlQyxnQkFBZ0IsSUFBSWYsU0FBaUIsRUFBRTtBQUU3RCxNQUFJZ0IsVUFBb0JSLE1BQU1TLFdBQVdaLGdCQUFnQixJQUFJQyxZQUFZO0FBS3pFLFFBQU1ZLGlCQUFpQkEsTUFBTTtBQUMzQlAsb0JBQWdCLENBQUNELFlBQVk7QUFBQSxFQUMvQjtBQUtBLFFBQU1TLGlCQUFpQkEsQ0FBQ0MsVUFBcUQ7QUFDM0UsUUFBSUEsTUFBTUMsa0JBQWtCRCxNQUFNRSxRQUFRO0FBQ3hDWCxzQkFBZ0IsS0FBSztBQUFBLElBQ3ZCO0FBQUEsRUFDRjtBQU1BLFFBQU1ZLHlCQUF5QkEsQ0FBQ0MsaUJBQStCO0FBQzdEWCxvQkFBZ0JXLFlBQVk7QUFBQSxFQUM5QjtBQU1BLFdBQVNDLGFBQWFYLGdCQUF1QjtBQUMzQyxRQUFJQSxtQkFBa0IsSUFBSTtBQUN4QixVQUFJTixNQUFNUyxVQUFVO0FBQ2xCVCxjQUFNa0IsY0FBY3ZCLG9CQUFvQlcsY0FBYSxDQUFDO0FBQUEsTUFDeEQsT0FBTztBQUNMLFlBQUlhLFNBQVN2QixnQkFBZ0JVLGNBQWE7QUFDMUNhLGVBQU9DLEtBQU1DLFNBQVE7QUFDbkJyQixnQkFBTWtCLGNBQWMsQ0FBQ0csR0FBRyxDQUFDO0FBQUEsUUFDM0IsQ0FBQztBQUFBLE1BQ0g7QUFBQSxJQUNGO0FBQ0FkLHFCQUFpQixFQUFFO0FBQUEsRUFDckI7QUFFQSxTQUNFLHVCQUFDLFNBQUksV0FBVSxvQkFBbUIsY0FBVyx5QkFDM0M7QUFBQSwyQkFBQyxRQUFHLFdBQVUsZ0JBQWUsNkNBQTdCO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FBMEQ7QUFBQSxJQUMxRCx1QkFBQyxtQkFDQyxPQUFPRCxlQUNQLFVBQVVDLGtCQUNWLFdBQVlLLFdBQVU7QUFDcEIsVUFBSUEsTUFBTVUsUUFBUSxTQUFTO0FBQ3pCVixjQUFNVyxlQUFlO0FBQ3JCTixxQkFBYVgsYUFBYTtBQUFBLE1BQzVCO0FBQUEsSUFDRixLQVJGO0FBQUE7QUFBQTtBQUFBO0FBQUEsV0FRSTtBQUFBLElBRUosdUJBQUMsWUFDQyxXQUFVLGlCQUNWLElBQUcsZ0JBQ0gsU0FBUyxNQUFNVyxhQUFhWCxhQUFhLEdBQ3pDLGNBQVcsdUJBQXFCLHNCQUpsQztBQUFBO0FBQUE7QUFBQTtBQUFBLFdBT0E7QUFBQSxJQUNBLHVCQUFDLFlBQ0MsSUFBRyxrQkFDSCxXQUFZLG1CQUFrQkosZUFBZSxXQUFXLEVBQUcsSUFDM0QsU0FBU1EsZ0JBQ1QsUUFBUUMsZ0JBQ1IsY0FBVyxxQ0FFVlA7QUFBQUEscUJBQWUsb0JBQW9CO0FBQUEsTUFDbkNGLGdCQUNDLHVCQUFDLGtCQUNDLGVBQWVNLFNBQ2YsY0FDQSxnQkFDQSx3QkFDQSxvQkFMRjtBQUFBO0FBQUE7QUFBQTtBQUFBLGFBS3FDO0FBQUEsU0FkekM7QUFBQTtBQUFBO0FBQUE7QUFBQSxXQWlCQTtBQUFBLE9BckNGO0FBQUE7QUFBQTtBQUFBO0FBQUEsU0FzQ0E7QUFFSjtBQUFDUCxHQS9GZUYsUUFBTTtBQUFBeUIsS0FBTnpCO0FBQU0sSUFBQXlCO0FBQUFDLGFBQUFELElBQUEiLCJuYW1lcyI6WyJ1c2VTdGF0ZSIsIkNvbnRyb2xsZWRJbnB1dCIsIlJlc29ydERyb3Bkb3duIiwiZ2V0TW9ja1NlYXJjaFJlc29ydCIsImdldFNlYXJjaFJlc29ydCIsIm1vY2tSZXNvcnROYW1lcyIsInJlc29ydE5hbWVzIiwiU2VhcmNoIiwicHJvcHMiLCJfcyIsInNob3dEcm9wRG93biIsInNldFNob3dEcm9wRG93biIsInNlbGVjdFJlc29ydCIsInNldFNlbGVjdFJlc29ydCIsImNvbW1hbmRTdHJpbmciLCJzZXRDb21tYW5kU3RyaW5nIiwicmVzb3J0cyIsIm1vY2tNb2RlIiwidG9nZ2xlRHJvcERvd24iLCJkaXNtaXNzSGFuZGxlciIsImV2ZW50IiwiY3VycmVudFRhcmdldCIsInRhcmdldCIsInJlc29ydE9wdGlvbnNTZWxlY3Rpb24iLCJyZXNvcnRPcHRpb24iLCJoYW5kbGVTZWFyY2giLCJzZXRSZXNvcnRMaXN0Iiwib3V0cHV0IiwidGhlbiIsInJlcyIsImtleSIsInByZXZlbnREZWZhdWx0IiwiX2MiLCIkUmVmcmVzaFJlZyQiXSwic291cmNlcyI6WyJTZWFyY2gudHN4Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBcIi4uLy4uL3N0eWxlcy9tYWluLmNzc1wiO1xuaW1wb3J0IHsgRGlzcGF0Y2gsIFNldFN0YXRlQWN0aW9uLCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xuaW1wb3J0IHsgQ29udHJvbGxlZElucHV0IH0gZnJvbSBcIi4vQ29udHJvbGxlZElucHV0XCI7XG5pbXBvcnQgeyBSZXNvcnREcm9wZG93biB9IGZyb20gXCIuL1Jlc29ydHNEcm9wZG93blwiO1xuaW1wb3J0IHtcbiAgZ2V0TW9ja1NlYXJjaFJlc29ydCxcbiAgZ2V0U2VhcmNoUmVzb3J0LFxuICBtb2NrUmVzb3J0TmFtZXMsXG4gIG1vY2tSZXNvcnRzU2VhcmNoLFxuICBSZXNvcnQsXG4gIHJlc29ydE5hbWVzLFxufSBmcm9tIFwiLi4vcmVzb3J0cy9SZXNvcnRDbGFzc1wiO1xuXG4vKipcbiAqIFByb3BlcnRpZXMgZm9yIHRoZSBTZWFyY2ggY29tcG9uZW50LlxuICovXG5pbnRlcmZhY2UgU2VhcmNoUHJvcHMge1xuICByZXNvcnRMaXN0OiBSZXNvcnRbXTtcbiAgc2V0UmVzb3J0TGlzdDogRGlzcGF0Y2g8U2V0U3RhdGVBY3Rpb248UmVzb3J0W10+PjtcbiAgbW9ja01vZGU6IGJvb2xlYW47XG59XG5cbi8qKlxuICogUHJvdmlkZXMgYW4gaW50ZXJmYWNlIGZvciBzZWFyY2hpbmcgcmVzb3J0cyBieSBuYW1lLiBJbmNsdWRlcyBhIHRleHQgaW5wdXQgZm9yXG4gKiBlbnRlcmluZyBzZWFyY2ggY29tbWFuZHMsIGEgc2VhcmNoIGJ1dHRvbiwgYW5kIGEgZHJvcGRvd24gbWVudSB0aGF0IGxpc3RzIHJlc29ydHMuXG4gKi9cbmV4cG9ydCBmdW5jdGlvbiBTZWFyY2gocHJvcHM6IFNlYXJjaFByb3BzKSB7XG4gIC8vIFN0YXRlIHRoYXQgbWFuYWdlcyB3aGV0aGVyIHRoZSBzZWUgcmVzb3J0cyBkcm9wZG93biBpcyBzaG93blxuICBjb25zdCBbc2hvd0Ryb3BEb3duLCBzZXRTaG93RHJvcERvd25dID0gdXNlU3RhdGU8Ym9vbGVhbj4oZmFsc2UpO1xuXG4gIC8vIFN0YXRlIHRoYXQgbWFuYWdlcyB0aGUgc2VhcmNoIGJveC5cbiAgY29uc3QgW3NlbGVjdFJlc29ydCwgc2V0U2VsZWN0UmVzb3J0XSA9IHVzZVN0YXRlPHN0cmluZz4oXCJcIik7XG5cbiAgLy8gU3RhdGUgdGhlIG1hbmFnZXMgdGhlIGNvbW1hbmQgc3RyaW5nXG4gIGNvbnN0IFtjb21tYW5kU3RyaW5nLCBzZXRDb21tYW5kU3RyaW5nXSA9IHVzZVN0YXRlPHN0cmluZz4oXCJcIik7XG5cbiAgdmFyIHJlc29ydHM6IHN0cmluZ1tdID0gcHJvcHMubW9ja01vZGUgPyBtb2NrUmVzb3J0TmFtZXMoKSA6IHJlc29ydE5hbWVzKCk7XG5cbiAgLyoqXG4gICAqIFRvZ2dsZXMgdGhlIHZpc2liaWxpdHkgb2YgdGhlIGRyb3Bkb3duIG1lbnUuXG4gICAqL1xuICBjb25zdCB0b2dnbGVEcm9wRG93biA9ICgpID0+IHtcbiAgICBzZXRTaG93RHJvcERvd24oIXNob3dEcm9wRG93bik7XG4gIH07XG5cbiAgLyoqXG4gICAqIEhhbmRsZXMgY2xvc2luZyB0aGUgZHJvcGRvd24gbWVudSBpZiBhbiBvdXRzaWRlIGNsaWNrIGlzIGRldGVjdGVkLlxuICAgKi9cbiAgY29uc3QgZGlzbWlzc0hhbmRsZXIgPSAoZXZlbnQ6IFJlYWN0LkZvY3VzRXZlbnQ8SFRNTEJ1dHRvbkVsZW1lbnQ+KTogdm9pZCA9PiB7XG4gICAgaWYgKGV2ZW50LmN1cnJlbnRUYXJnZXQgPT09IGV2ZW50LnRhcmdldCkge1xuICAgICAgc2V0U2hvd0Ryb3BEb3duKGZhbHNlKTtcbiAgICB9XG4gIH07XG5cbiAgLyoqXG4gICAqIFNldHMgdGhlIGN1cnJlbnRseSBzZWxlY3RlZCByZXNvcnQgZnJvbSB0aGUgZHJvcGRvd24uXG4gICAqIEBwYXJhbSB7c3RyaW5nfSByZXNvcnRPcHRpb24gLSBUaGUgcmVzb3J0IG9wdGlvbiB0aGF0IHdhcyBzZWxlY3RlZC5cbiAgICovXG4gIGNvbnN0IHJlc29ydE9wdGlvbnNTZWxlY3Rpb24gPSAocmVzb3J0T3B0aW9uOiBzdHJpbmcpOiB2b2lkID0+IHtcbiAgICBzZXRTZWxlY3RSZXNvcnQocmVzb3J0T3B0aW9uKTtcbiAgfTtcblxuICAvKipcbiAgICogSGFuZGxlcyBhIHNlYXJjaCBidXR0b24gY2xpY2sgYnkgdXBkYXRpbmcgdGhlIHJlc29ydCBsaXN0IGFjY29yZGluZ2x5LlxuICAgKiBAcGFyYW0ge3N0cmluZ30gY29tbWFuZFN0cmluZyAtIFRoZSByZXNvcnQgdG8gc2VhcmNoIGZvci5cbiAgICovXG4gIGZ1bmN0aW9uIGhhbmRsZVNlYXJjaChjb21tYW5kU3RyaW5nOiBzdHJpbmcpIHtcbiAgICBpZiAoY29tbWFuZFN0cmluZyAhPT0gXCJcIikge1xuICAgICAgaWYgKHByb3BzLm1vY2tNb2RlKSB7XG4gICAgICAgIHByb3BzLnNldFJlc29ydExpc3QoZ2V0TW9ja1NlYXJjaFJlc29ydChjb21tYW5kU3RyaW5nKSk7XG4gICAgICB9IGVsc2Uge1xuICAgICAgICB2YXIgb3V0cHV0ID0gZ2V0U2VhcmNoUmVzb3J0KGNvbW1hbmRTdHJpbmcpO1xuICAgICAgICBvdXRwdXQudGhlbigocmVzKSA9PiB7XG4gICAgICAgICAgcHJvcHMuc2V0UmVzb3J0TGlzdChbcmVzXSk7XG4gICAgICAgIH0pO1xuICAgICAgfVxuICAgIH1cbiAgICBzZXRDb21tYW5kU3RyaW5nKFwiXCIpO1xuICB9XG5cbiAgcmV0dXJuIChcbiAgICA8ZGl2IGNsYXNzTmFtZT1cInNlYXJjaC1jb250YWluZXJcIiBhcmlhLWxhYmVsPVwiUmVzb3J0IHNlYXJjaCBzZWN0aW9uXCI+XG4gICAgICA8aDMgY2xhc3NOYW1lPVwic2VhcmNoLXRpdGxlXCI+U2VhcmNoIGZvciBhIHNwZWNpZmljIHJlc29ydDo8L2gzPlxuICAgICAgPENvbnRyb2xsZWRJbnB1dFxuICAgICAgICB2YWx1ZT17Y29tbWFuZFN0cmluZ31cbiAgICAgICAgc2V0VmFsdWU9e3NldENvbW1hbmRTdHJpbmd9XG4gICAgICAgIG9uS2V5RG93bj17KGV2ZW50KSA9PiB7XG4gICAgICAgICAgaWYgKGV2ZW50LmtleSA9PT0gXCJFbnRlclwiKSB7XG4gICAgICAgICAgICBldmVudC5wcmV2ZW50RGVmYXVsdCgpO1xuICAgICAgICAgICAgaGFuZGxlU2VhcmNoKGNvbW1hbmRTdHJpbmcpO1xuICAgICAgICAgIH1cbiAgICAgICAgfX1cbiAgICAgIC8+XG4gICAgICA8YnV0dG9uXG4gICAgICAgIGNsYXNzTmFtZT1cInNlYXJjaC1idXR0b25cIlxuICAgICAgICBpZD1cInNlYXJjaEJ1dHRvblwiXG4gICAgICAgIG9uQ2xpY2s9eygpID0+IGhhbmRsZVNlYXJjaChjb21tYW5kU3RyaW5nKX1cbiAgICAgICAgYXJpYS1sYWJlbD1cIlNlYXJjaCBmb3IgYSByZXNvcnRcIlxuICAgICAgPlxuICAgICAgICBTZWFyY2hcbiAgICAgIDwvYnV0dG9uPlxuICAgICAgPGJ1dHRvblxuICAgICAgICBpZD1cInNlYXJjaERyb3Bkb3duXCJcbiAgICAgICAgY2xhc3NOYW1lPXtgc2VhcmNoLWRyb3Bkb3duICR7c2hvd0Ryb3BEb3duID8gXCJhY3RpdmVcIiA6IFwiXCJ9YH1cbiAgICAgICAgb25DbGljaz17dG9nZ2xlRHJvcERvd259XG4gICAgICAgIG9uQmx1cj17ZGlzbWlzc0hhbmRsZXJ9XG4gICAgICAgIGFyaWEtbGFiZWw9XCJTaG93IG9yIGhpZGUgcmVzb3J0IGxpc3QgZHJvcGRvd25cIlxuICAgICAgPlxuICAgICAgICB7c2VsZWN0UmVzb3J0ID8gXCJTZWUgcmVzb3J0cyAuLi5cIiA6IFwiIFNlZSBmdWxsIGxpc3Qgb2YgcmVzb3J0cy4uLlwifVxuICAgICAgICB7c2hvd0Ryb3BEb3duICYmIChcbiAgICAgICAgICA8UmVzb3J0RHJvcGRvd25cbiAgICAgICAgICAgIHJlc29ydE9wdGlvbnM9e3Jlc29ydHN9XG4gICAgICAgICAgICBzaG93RHJvcERvd249e3Nob3dEcm9wRG93bn1cbiAgICAgICAgICAgIHRvZ2dsZURyb3BEb3duPXt0b2dnbGVEcm9wRG93bn1cbiAgICAgICAgICAgIHJlc29ydE9wdGlvbnNTZWxlY3Rpb249e3Jlc29ydE9wdGlvbnNTZWxlY3Rpb259XG4gICAgICAgICAgICBzZXRDb21tYW5kU3RyaW5nPXtzZXRDb21tYW5kU3RyaW5nfVxuICAgICAgICAgIC8+XG4gICAgICAgICl9XG4gICAgICA8L2J1dHRvbj5cbiAgICA8L2Rpdj5cbiAgKTtcbn1cbiJdLCJmaWxlIjoiL1VzZXJzL2F1c3RpbndpbGxpYW1zL0RvY3VtZW50cy9TY2hvb2wvdGhpcmRTZW1lc3Rlci9DUzMyL3Rlcm0tcHJvamVjdC10YnpoYW8tdHBlenphLXNtc2NodWNoLWJ3aWxsaTQ4L0Zyb250ZW5kL3NraS9zcmMvY29tcG9uZW50cy9zZWFyY2gvU2VhcmNoLnRzeCJ9